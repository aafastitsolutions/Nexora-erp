# Jurnal Modificari MiniCRM

## 2026-03-30

### Identitate si infrastructura
- Numele proiectului a fost aliniat la `MiniCRM` in `package.json` si `package-lock.json`.
- Brandingul tehnic ramas pe vechiul nume a fost actualizat in `server.js`.
- Aplicatia a fost publicata pe `https://minicrm.qr-lab.ro` prin `nginx` si `Cloudflare Tunnel`.
- Serviciul systemd activ a fost migrat de la `contracts-app` la `minicrm`.
- Directorul aplicatiei a fost redenumit din `/home/server/contracts-app` in `/home/server/minicrm`.
- Automatizarea de backup a fost activata prin `minicrm-backup.timer`.

### Curatare si siguranta proiect
- Au fost mutate fisierele reziduale si backupurile istorice din radacina in `_project_archive`.
- A fost verificata integritatea bazelor SQLite principale.
- Au fost reparate migrarile din `db.js` pentru a crea schema reala folosita de aplicatie.
- Au fost adaugate tabelele si coloanele lipsa pentru zona ANAF:
  - `anaf_connections`
  - `anaf_inbox`
  - `anaf_oauth_logs`
  - coloane noi in `facturi` pentru trasabilitatea e-Factura
  - coloana `details` in `anaf_messages`

### Hardening aplicatie
- Sesiunile au fost intarite:
  - `trust proxy`
  - cookie dedicat `minicrm.sid`
  - `httpOnly`
  - `sameSite`
  - `secure: auto`
  - regenerare sesiune la login
- Logout-ul sterge explicit cookie-ul de sesiune.

### Refactorizare cod
- Configuratia si helper-ele comune au fost extrase in:
  - `lib/app-config.js`
  - `lib/helpers.js`
  - `lib/bootstrap.js`
  - `lib/anaf.js`
  - `lib/anaf-efactura.js`
- Rutele au fost extrase din monolitul `server.js` in module dedicate:
  - `routes/auth-routes.js`
  - `routes/anaf-routes.js`
  - `routes/anaf-oauth-routes.js`
  - `routes/dashboard-routes.js`
  - `routes/quotes-routes.js`
  - `routes/facturi-routes.js`
  - `routes/contracts-routes.js`
  - `routes/clients-routes.js`

### ANAF / OAuth / e-Factura
- Redirect URI activ in aplicatie:
  - `https://minicrm.qr-lab.ro/oauth/anaf/callback`
- A fost implementat fluxul OAuth ANAF:
  - start autorizare
  - callback
  - salvare token-uri in `anaf_connections`
  - refresh automat al token-ului
  - jurnalizare evenimente OAuth in `anaf_oauth_logs`
- A fost implementata integrarea initiala e-Factura cu endpointurile ANAF:
  - upload XML factura
  - verificare status mesaj
  - descarcare raspuns SPV atunci cand este disponibil
- In UI facturii sunt afisate acum:
  - status e-Factura
  - index incarcare
  - id descarcare
  - ultima verificare
  - ultima eroare
  - link catre arhiva raspunsului SPV, cand exista

### Backupuri create manual pentru siguranta
- Backup SQLite:
  - fisier: `/home/server/minicrm/backups/sqlite/database-2026-03-30T15-10-05Z.db`
  - SHA256: `4ecd5ec9f27fcf8e4ae58066d9c50cf12fe86dfe2c234b05bedb642560795e82`
- Snapshot complet aplicatie:
  - fisier: `/home/server/minicrm/backups/minicrm-full-2026-03-30T15-10-05Z.tar.gz`
  - SHA256: `0bc5853055e4945aefd6286159dd03346e4545e84b7794f9aeaac8e31f072502`
  - continut: cod sursa, baza de date, documente generate, configurari locale, fisiere operationale
  - excluse din arhiva: `node_modules`, `backups`

### Operatiuni finale dupa migrare
- A fost eliminat serviciul vechi `contracts-app` din `systemd`, inclusiv fisierul de backup asociat.
- Configuratia activa `systemd` foloseste acum exclusiv:
  - `/etc/systemd/system/minicrm.service`
  - `/etc/systemd/system/minicrm-backup.service`
  - `/etc/systemd/system/minicrm-backup.timer`
- A fost confirmat ca directorul vechi `/home/server/contracts-app` nu mai exista pe server.
- A fost creat un backup SQLite suplimentar dupa curatarea finala:
  - fisier: `/home/server/minicrm/backups/sqlite/database-2026-03-30T16-57-55Z.db`
  - SHA256: `4ecd5ec9f27fcf8e4ae58066d9c50cf12fe86dfe2c234b05bedb642560795e82`
  - moment UTC: `2026-03-30T16:57:55Z`

### Verificari efectuate
- Verificare sintaxa:
  - `node --check server.js`
  - `node --check db.js`
  - `node --check` pentru modulele si rutele nou create
- Verificare disponibilitate aplicatie:
  - raspuns `200 OK` pe `https://minicrm.qr-lab.ro/login`
- Verificare backup:
  - fisierele de backup exista in `backups/` si `backups/sqlite/`
  - checksum-urile au fost calculate si notate mai sus

### Observatii operationale
- Fluxul complet ANAF nu poate fi testat end-to-end pana la activarea certificatului digital calificat in SPV.
- In momentul activarii certificatului, ordinea de test recomandata este:
  1. `Conecteaza contul ANAF`
  2. creeaza factura de test
  3. `Trimite e-Factura`
  4. `Verifica status SPV`
  5. verifica aparitia confirmarii si a raspunsului descarcat din ANAF
