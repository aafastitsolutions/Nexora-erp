export function registerDashboardRoutes(app, { db, requireAuth, todayISO, escapeHtml, fmtMoney, crmShellStart, crmShellEnd }) {
  app.get("/dashboard", requireAuth, (req, res) => {
    const rows = db.prepare(`
      SELECT c.id, c.contract_number, c.created_at, c.price, c.duration,
             cl.name AS client_name, cl.cui AS client_cui,
             c.pdf_path
      FROM contracts c
      JOIN clients cl ON cl.id = c.client_id
      WHERE IFNULL(c.origin,'DIRECT') <> 'QUOTE'
      ORDER BY c.id DESC
      LIMIT 200
    `).all();

    const tasks = db.prepare(`
      SELECT a.id, a.subject, a.note, a.due_at, a.created_at,
             cl.id AS client_id, cl.name AS client_name
      FROM activities a
      JOIN clients cl ON cl.id = a.client_id
      WHERE a.type='task' AND a.done=0
      ORDER BY (a.due_at IS NULL) ASC, a.due_at ASC, a.id DESC
      LIMIT 20
    `).all();

    const totalClients = db.prepare(`SELECT COUNT(*) AS n FROM clients`).get()?.n || 0;
    const totalQuotesOpen = db.prepare(`
      SELECT COUNT(*) AS n
      FROM quotes
      WHERE status IN ('DRAFT','SENT')
    `).get()?.n || 0;
    const totalContracts = db.prepare(`SELECT COUNT(*) AS n FROM contracts`).get()?.n || 0;
    const totalInvoicesOpen = db.prepare(`
      SELECT COUNT(*) AS n
      FROM facturi
      WHERE status IN ('CIORNA','TRIMISA','INTARZIATA')
    `).get()?.n || 0;

    const today = todayISO();
    const overdue = tasks.filter((t) => t.due_at && String(t.due_at) < today).length;

    const htmlTasks = tasks.map((t) => `
      <tr>
        <td>${t.due_at ? escapeHtml(t.due_at) : `<span class="crm-muted">—</span>`} ${t.due_at && String(t.due_at) < today ? `<span class="crm-badge crm-badge-red" style="margin-left:8px">Overdue</span>` : ``}</td>
        <td><a href="/client/${t.client_id}">${escapeHtml(t.client_name || "")}</a></td>
        <td>
          <div style="font-weight:700">${escapeHtml(t.subject || "")}</div>
          <div class="crm-muted" style="margin-top:4px">${escapeHtml(t.note || "")}</div>
        </td>
        <td><a href="/client/${t.client_id}">Open</a></td>
      </tr>
    `).join("");

    const htmlRows = rows.map((r) => `
      <tr>
        <td><a href="/contract/${r.id}">${escapeHtml(r.contract_number || "")}</a></td>
        <td>
          <div style="font-weight:700">${escapeHtml(r.client_name || "")}</div>
          <div class="crm-muted" style="margin-top:4px">${escapeHtml(r.client_cui || "")}</div>
        </td>
        <td class="crm-right">${escapeHtml(fmtMoney(r.price))}</td>
        <td>${escapeHtml(r.duration || "")}</td>
        <td>${escapeHtml(r.created_at || "")}</td>
        <td>${r.pdf_path ? `<a href="/${encodeURI(r.pdf_path)}" target="_blank">PDF</a>` : `<span class="crm-muted">—</span>`}</td>
      </tr>
    `).join("");

    const userEmail = req.session.user.email;

    res.type("html").send(`
<!doctype html>
<html>
<head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<meta charset="utf-8">
<title>Dashboard</title>
</head>
${crmShellStart("dashboard", "Dashboard", "Overview rapid pentru activitatea curentă.", userEmail, req.session.user.module_permissions)}

  <div class="crm-kpis" style="margin-bottom:18px">
    <div class="crm-kpi">
      <div class="crm-kpi-label">Clienți</div>
      <div class="crm-kpi-value">${escapeHtml(String(totalClients))}</div>
    </div>
    <div class="crm-kpi">
      <div class="crm-kpi-label">Quotes active</div>
      <div class="crm-kpi-value">${escapeHtml(String(totalQuotesOpen))}</div>
    </div>
    <div class="crm-kpi">
      <div class="crm-kpi-label">Contracte</div>
      <div class="crm-kpi-value">${escapeHtml(String(totalContracts))}</div>
    </div>
    <div class="crm-kpi">
      <div class="crm-kpi-label">Facturi deschise</div>
      <div class="crm-kpi-value">${escapeHtml(String(totalInvoicesOpen))}</div>
    </div>
  </div>

  <div class="crm-grid-2" style="overflow:visible">
    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap;margin-bottom:14px">
        <div>
          <h3 style="margin:0;font-size:20px">Open tasks</h3>
          <div class="crm-muted" style="margin-top:6px">Total: <b>${tasks.length}</b> · Overdue: <b style="color:#be123c">${overdue}</b></div>
        </div>
        <div class="crm-muted" style="font-size:13px">Tasks se adaugă din Client → Activities</div>
      </div>

      <div class="crm-table-wrap">
        <table class="crm-table">
          <thead>
            <tr>
              <th>Due</th>
              <th>Client</th>
              <th>Task</th>
              <th></th>
            </tr>
          </thead>
          <tbody>${htmlTasks || `<tr><td colspan="4"><em>Nu există task-uri deschise.</em></td></tr>`}</tbody>
        
</table>

<table style="width:100%;border-collapse:collapse;margin-top:10px;font-size:10px">
  <tr>
    <td style="border:1px solid #000;padding:6px;width:40%">
      
      <div style="margin-top:6px">cu chitanța nr. ______ din ______</div>
    </td>
    <td style="border:1px solid #000;padding:6px;width:40%">
      Diferență de primit<br>
      <div style="margin-top:6px">cu dispoziția nr. ______ din ______</div>
    </td>
    <td style="border:1px solid #000;padding:6px;width:20%">
      Semnătura
    </td>
  </tr>
</table>

<table style="width:100%;border-collapse:collapse;margin-top:6px;font-size:10px">
  <tr>
    <td style="border:1px solid #000;padding:6px;text-align:center">Control financiar preventiv</td>
    <td style="border:1px solid #000;padding:6px;text-align:center">Verificat decont</td>
    <td style="border:1px solid #000;padding:6px;text-align:center">Compartiment financiar</td>
    <td style="border:1px solid #000;padding:6px;text-align:center">Titular avans</td>
  </tr>
  <tr>
    <td style="border:1px solid #000;height:40px"></td>
    <td style="border:1px solid #000"></td>
    <td style="border:1px solid #000"></td>
    <td style="border:1px solid #000"></td>
  </tr>
</table>

      </div>
    </section>

    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap;margin-bottom:14px">
        <div>
          <h3 style="margin:0;font-size:20px">Contracte recente</h3>
          <div class="crm-muted" style="margin-top:6px">Ultimele contracte directe din sistem.</div>
        </div>
      </div>

      <div class="crm-table-wrap">
        <table class="crm-table">
          <thead>
            <tr>
              <th>Contract</th>
              <th>Client</th>
              <th class="crm-right">Preț</th>
              <th>Durată</th>
              <th>Creat</th>
              <th>PDF</th>
            </tr>
          </thead>
          <tbody>${htmlRows || `<tr><td colspan="6"><em>Nu există contracte.</em></td></tr>`}</tbody>
        </table>
      </div>
    </section>

  </div>


${crmShellEnd()}
</html>`);
  });
}
