export function registerAuthRoutes(app, { verifyUser }) {
  app.get("/login", (req, res) => {
    if (req.session?.user) return res.redirect("/dashboard");
    res.type("html").send(`
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<style>
  *{box-sizing:border-box}
  body{
    margin:0;
    min-height:100vh;
    display:flex;
    align-items:flex-start;
    justify-content:center;
    padding-top:8vh;
    font-family:system-ui,Arial,sans-serif;
    background:linear-gradient(135deg,#0f172a,#1e3a8a,#38bdf8);
    background-size:200% 200%;
    animation:bgShift 10s ease infinite;
  }
  @keyframes bgShift{
    0%{background-position:0% 50%}
    50%{background-position:100% 50%}
    100%{background-position:0% 50%}
  }
  @keyframes cardIn{
    from{opacity:0;transform:translateY(18px) scale(.98)}
    to{opacity:1;transform:translateY(0) scale(1)}
  }
  .login-shell{
    position:relative;

    width:100%;
    max-width:420px;
    padding:24px;
  }
  .login-shell::before{
    content:"";
    position:absolute;
    inset:10% -8% auto -8%;
    height:220px;
    background:radial-gradient(circle, rgba(255,255,255,.16), rgba(255,255,255,0) 70%);
    filter:blur(10px);
    pointer-events:none;
  }
  .box::before{
    content:"";
    position:absolute;
    inset:-1px;
    background:linear-gradient(135deg,rgba(255,255,255,.30),rgba(255,255,255,.06),rgba(255,255,255,.18));
    border-radius:20px;
    pointer-events:none;
    opacity:.9;
  }
  .box{

    border:1px solid rgba(255,255,255,.22);
    border-radius:20px;
    padding:28px;
    background:rgba(255,255,255,.14);
    backdrop-filter:blur(14px);
    -webkit-backdrop-filter:blur(14px);
    box-shadow:0 24px 80px rgba(2,6,23,.34), inset 0 1px 0 rgba(255,255,255,.10);
    animation:cardIn .55s ease;
    position:relative;
    overflow:hidden;
  }
  h2{
    margin:0 0 18px;
    text-align:center;
    color:#fff;
    font-size:28px;
    letter-spacing:.3px;
    text-shadow:0 2px 12px rgba(15,23,42,.25);
  }
  label{
    display:block;
    margin:0 0 6px;
    color:#e5e7eb;
    font-size:13px;
    font-weight:600;
  }
  input{
    width:100%;
    padding:12px 14px;
    margin:0 0 14px;
    border:1px solid rgba(255,255,255,.24);
    border-radius:12px;
    background:rgba(255,255,255,.96);
    outline:none;
    font-size:14px;
  }
  input:focus{
    border-color:#93c5fd;
    box-shadow:0 0 0 3px rgba(147,197,253,.25);
  }
  button{
    width:100%;
    padding:12px 14px;
    border:0;
    border-radius:12px;
    background:linear-gradient(135deg,#111827,#2563eb);
    color:#fff;
    font-weight:700;
    font-size:14px;
    cursor:pointer;
    box-shadow:0 10px 24px rgba(37,99,235,.30);
    transition:transform .15s ease, box-shadow .15s ease, opacity .15s ease, filter .15s ease;
  }
  button:hover{
    transform:translateY(-1px);
    box-shadow:0 14px 28px rgba(37,99,235,.38);
    filter:brightness(1.03);
  }
  button:active{
    transform:translateY(0);
  }
  .bg-logo{
    position:fixed;
    inset:0;
    display:flex;
    align-items:center;
    justify-content:center;
    pointer-events:none;
    user-select:none;
    font-size:clamp(72px,16vw,220px);
    font-weight:800;
    letter-spacing:4px;
    color:rgba(255,255,255,.14);
    text-transform:uppercase;
    text-shadow:0 10px 34px rgba(15,23,42,.22);
    animation:bgLogoFloat 7s ease-in-out infinite;
  }
  @keyframes bgLogoFloat{
    0%{transform:translateY(0);opacity:.08}
    50%{transform:translateY(10px);opacity:.12}
    100%{transform:translateY(0);opacity:.08}
  }
  }
</style>
</head>
<body>
  <div class="bg-logo" id="bgLogo">MiniCRM</div>
  <div class="login-shell">
    <h2>MiniCRM Login</h2>
    <div class="box">
      <form method="post" action="/login">
        <label>Email</label>
        <input name="email" type="email" required />
        <label>Password</label>
        <input name="password" type="password" required />
        <button type="submit">Login</button>
      </form>
    </div>
  </div>
<script>
  const bgLogo = document.getElementById("bgLogo");
  document.addEventListener("mousemove", (e) => {
    const x = (e.clientX / window.innerWidth - 0.5) * 18;
    const y = (e.clientY / window.innerHeight - 0.5) * 12;
    bgLogo.style.transform = "translate(" + x + "px," + (y + 4) + "px)";
  });
</script>
</body>
</html>`);
  });

  app.post("/login", (req, res) => {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "");
    if (!email || !password) {
      return res.status(400).type("html").send("<p style='font-family:system-ui'>Email și parola sunt obligatorii. <a href='/login'>Înapoi</a></p>");
    }

    const u = verifyUser(email, password);
    if (!u) {
      return res.status(401).type("html").send("<p style='font-family:system-ui'>Login invalid. <a href='/login'>Înapoi</a></p>");
    }

    req.session.regenerate((err) => {
      if (err) {
        console.error("Session regenerate failed:", err);
        return res.status(500).type("html").send("<p style='font-family:system-ui'>Eroare internă. <a href='/login'>Înapoi</a></p>");
      }

      req.session.user = { id: u.id, email: u.email, role: u.role, module_permissions: u.module_permissions };
      return res.redirect("/dashboard");
    });
  });

  app.post("/logout", (req, res) => {
    req.session?.destroy(() => {
      res.clearCookie("minicrm.sid");
      res.redirect("/login");
    });
  });
}
