// db.js (ESM)
import path from "path";
import Database from "better-sqlite3";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const DB_PATH = process.env.DB_PATH || path.join(__dirname, "database.db");
export const db = new Database(DB_PATH);

function hasColumn(tableName, columnName) {
  const columns = db.prepare(`PRAGMA table_info(${tableName})`).all();
  return columns.some((column) => column.name === columnName);
}

function ensureColumn(tableName, columnName, definition) {
  if (!hasColumn(tableName, columnName)) {
    db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${definition}`);
  }
}

export function migrate() {
  db.pragma("journal_mode = WAL");

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'admin',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS clients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      cui TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      address TEXT,
      reg_com TEXT,
      caen TEXT,
      vat INTEGER DEFAULT 0,
      inactive INTEGER DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS contracts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contract_number TEXT NOT NULL UNIQUE,
      year INTEGER NOT NULL,
      seq INTEGER NOT NULL,
      client_id INTEGER NOT NULL,
      service_description TEXT NOT NULL,
      price REAL NOT NULL,
      duration TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      pdf_path TEXT,
      FOREIGN KEY (client_id) REFERENCES clients(id)
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT,
      name TEXT NOT NULL,
      unit TEXT DEFAULT 'buc',
      price REAL NOT NULL DEFAULT 0,
      tva_percent REAL NOT NULL DEFAULT 19,
      kind TEXT NOT NULL DEFAULT 'SERVICIU',
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      email TEXT,
      phone TEXT,
      position TEXT,
      is_primary INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS activities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client_id INTEGER NOT NULL,
      contact_id INTEGER,
      type TEXT NOT NULL,
      subject TEXT,
      note TEXT,
      due_at TEXT,
      done INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      employee_id INTEGER,
      FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
      FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS quotes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      quote_number TEXT NOT NULL UNIQUE,
      year INTEGER NOT NULL,
      seq INTEGER NOT NULL,
      client_id INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'DRAFT',
      title TEXT,
      notes TEXT,
      currency TEXT NOT NULL DEFAULT 'RON',
      subtotal REAL NOT NULL DEFAULT 0,
      vat_rate REAL NOT NULL DEFAULT 0,
      vat_amount REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      valid_until TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      pdf_path TEXT,
      contract_id INTEGER,
      FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS quote_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      quote_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      qty REAL NOT NULL DEFAULT 1,
      unit TEXT,
      unit_price REAL NOT NULL DEFAULT 0,
      line_total REAL NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS facturi (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      factura_nr TEXT NOT NULL UNIQUE,
      an INTEGER NOT NULL,
      seq INTEGER NOT NULL,
      client_id INTEGER NOT NULL,
      contract_id INTEGER,
      quote_id INTEGER,
      status TEXT NOT NULL DEFAULT 'CIORNA',
      moneda TEXT NOT NULL DEFAULT 'RON',
      subtotal REAL NOT NULL DEFAULT 0,
      tva_procent REAL NOT NULL DEFAULT 0.19,
      tva_valoare REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      data_emitere TEXT NOT NULL DEFAULT (date('now')),
      scadenta TEXT,
      observatii TEXT,
      pdf_path TEXT,
      efactura_status TEXT,
      efactura_message_id TEXT,
      efactura_xml_path TEXT,
      efactura_last_error TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      employee_id INTEGER,
      FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS facturi_linii (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      factura_id INTEGER NOT NULL,
      denumire TEXT NOT NULL,
      cantitate REAL NOT NULL DEFAULT 1,
      unitate TEXT,
      pret_unitar REAL NOT NULL DEFAULT 0,
      total_linie REAL NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (factura_id) REFERENCES facturi(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );

    CREATE TABLE IF NOT EXISTS tipizate_docs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      category TEXT,
      file_name TEXT NOT NULL,
      file_path TEXT NOT NULL,
      mime_type TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS anaf_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id INTEGER,
      message_id TEXT,
      factura_id INTEGER,
      direction TEXT,
      status TEXT,
      payload TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS anaf_connections (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      environment TEXT NOT NULL DEFAULT 'test',
      access_token TEXT,
      refresh_token TEXT,
      token_type TEXT,
      scope TEXT,
      expires_at TEXT,
      refresh_expires_at TEXT,
      serial_certificate TEXT,
      raw_response TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS anaf_inbox (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      supplier_cui TEXT,
      invoice_number TEXT,
      xml_path TEXT,
      pdf_path TEXT,
      received_at TEXT,
      processed INTEGER NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS anaf_oauth_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_type TEXT NOT NULL,
      status TEXT,
      details TEXT,
      query_string TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS employees (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT,
      phone TEXT,
      position TEXT,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_clients_cui ON clients(cui);
    CREATE INDEX IF NOT EXISTS idx_contracts_client_id ON contracts(client_id);
    CREATE INDEX IF NOT EXISTS idx_contracts_year_seq ON contracts(year, seq);
    CREATE INDEX IF NOT EXISTS idx_products_name ON products(name);
    CREATE INDEX IF NOT EXISTS idx_products_code ON products(code);
    CREATE INDEX IF NOT EXISTS idx_products_active ON products(active);
    CREATE INDEX IF NOT EXISTS idx_contacts_client_id ON contacts(client_id);
    CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);
    CREATE INDEX IF NOT EXISTS idx_contacts_phone ON contacts(phone);
    CREATE INDEX IF NOT EXISTS idx_activities_client_id ON activities(client_id);
    CREATE INDEX IF NOT EXISTS idx_activities_contact_id ON activities(contact_id);
    CREATE INDEX IF NOT EXISTS idx_activities_type ON activities(type);
    CREATE INDEX IF NOT EXISTS idx_activities_done ON activities(done);
    CREATE INDEX IF NOT EXISTS idx_quotes_client_id ON quotes(client_id);
    CREATE INDEX IF NOT EXISTS idx_quotes_year_seq ON quotes(year, seq);
    CREATE INDEX IF NOT EXISTS idx_quotes_status ON quotes(status);
    CREATE INDEX IF NOT EXISTS idx_quote_items_quote_id ON quote_items(quote_id);
    CREATE INDEX IF NOT EXISTS idx_facturi_client_id ON facturi(client_id);
    CREATE INDEX IF NOT EXISTS idx_facturi_an_seq ON facturi(an, seq);
    CREATE INDEX IF NOT EXISTS idx_facturi_status ON facturi(status);
    CREATE INDEX IF NOT EXISTS idx_facturi_linii_factura_id ON facturi_linii(factura_id);
    CREATE INDEX IF NOT EXISTS idx_anaf_connections_environment ON anaf_connections(environment);
    CREATE INDEX IF NOT EXISTS idx_anaf_inbox_received_at ON anaf_inbox(received_at);
  `);

  ensureColumn("users", "module_permissions", "TEXT");

  ensureColumn("clients", "email", "TEXT");
  ensureColumn("clients", "phone", "TEXT");
  ensureColumn("clients", "client_status", "TEXT DEFAULT 'verde'");
  ensureColumn("clients", "notes", "TEXT");

  ensureColumn("contracts", "origin", "TEXT DEFAULT 'DIRECT'");
  ensureColumn("contracts", "employee_id", "INTEGER");

  ensureColumn("activities", "employee_id", "INTEGER");
  ensureColumn("facturi", "employee_id", "INTEGER");
  ensureColumn("facturi", "efactura_upload_index", "TEXT");
  ensureColumn("facturi", "efactura_download_id", "TEXT");
  ensureColumn("facturi", "efactura_response_zip_path", "TEXT");
  ensureColumn("facturi", "efactura_last_checked_at", "TEXT");
  ensureColumn("anaf_connections", "scope", "TEXT");
  ensureColumn("anaf_connections", "expires_at", "TEXT");
  ensureColumn("anaf_connections", "refresh_expires_at", "TEXT");
  ensureColumn("anaf_connections", "serial_certificate", "TEXT");
  ensureColumn("anaf_connections", "raw_response", "TEXT");
  ensureColumn("anaf_connections", "updated_at", "TEXT DEFAULT CURRENT_TIMESTAMP");
  ensureColumn("anaf_messages", "details", "TEXT");
  db.exec("CREATE INDEX IF NOT EXISTS idx_anaf_oauth_logs_created_at ON anaf_oauth_logs(created_at DESC)");
}
