// auth.js (ESM)
import bcrypt from "bcrypt";
import { db } from "./db.js";

export function requireAuth(req, res, next) {
  if (req.session && req.session.user) return next();
  return res.redirect("/login");
}

export function requireRole(...roles) {
  return (req, res, next) => {
    const user = req.session?.user;
    if (!user) return res.redirect("/login");
    if (!roles.includes(user.role)) return res.status(403).send("Forbidden");
    next();
  };
}

export function seedAdminFromEnv() {
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;

  if (!email || !password) return { ok: false, reason: "ADMIN_EMAIL/ADMIN_PASSWORD missing" };

  const existing = db.prepare("SELECT id,email,role FROM users WHERE email=?").get(email);
  if (existing) return { ok: true, created: false, email };

  const hash = bcrypt.hashSync(password, 12);
  db.prepare("INSERT INTO users (email, password_hash, role) VALUES (?,?,?)")
    .run(email, hash, "admin");

  return { ok: true, created: true, email };
}

export function verifyUser(email, password) {
  const u = db.prepare("SELECT id,email,password_hash,role,module_permissions FROM users WHERE email=?").get(email);
  if (!u) return null;
  const ok = bcrypt.compareSync(password, u.password_hash);
  if (!ok) return null;

  let module_permissions = [];
  try {
    module_permissions = JSON.parse(u.module_permissions || "[]");
    if (!Array.isArray(module_permissions)) module_permissions = [];
  } catch (e) {
    module_permissions = [];
  }

  return { id: u.id, email: u.email, role: u.role, module_permissions };
}


export function requireModule(moduleKey) {
  return (req, res, next) => {

    const user = req.session?.user;
    if (!user) return res.redirect("/login");

    const role = String(user.role || "").toLowerCase();

    try {
      const modules = globalThis.ROLE_MODULES?.[role] || [];
      if (!modules.includes(moduleKey)) {
        return res.status(403).send("Forbidden");
      }
    } catch (e) {
      return res.status(403).send("Forbidden");
    }

    next();
  };
}

