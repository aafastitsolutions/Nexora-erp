// db.js (ESM)
import path from "path";
import Database from "better-sqlite3";
import { fileURLToPath } from "url";
import { ALL_MODULE_KEYS, DEFAULT_PLAN_DEFINITIONS } from "./lib/app-config.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const DB_PATH = process.env.DB_PATH || path.join(__dirname, "database.db");
export const db = new Database(DB_PATH);

function hasColumn(tableName, columnName) {
  const columns = db.prepare(`PRAGMA table_info(${tableName})`).all();
  return columns.some((column) => column.name === columnName);
}

function ensureColumn(tableName, columnName, definition) {
  if (!hasColumn(tableName, columnName)) {
    db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${definition}`);
  }
}

export function migrate() {
  db.pragma("journal_mode = WAL");

  db.exec(`
    CREATE TABLE IF NOT EXISTS companies (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      cui TEXT,
      rc TEXT,
      address TEXT,
      bank TEXT,
      iban TEXT,
      representative TEXT,
      stripe_customer_id TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      max_users INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS plans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      billing_period TEXT NOT NULL DEFAULT 'monthly',
      price_monthly REAL NOT NULL DEFAULT 0,
      max_users INTEGER NOT NULL DEFAULT 1,
      module_keys TEXT NOT NULL DEFAULT '[]',
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS company_subscriptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      company_id INTEGER NOT NULL,
      plan_id INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      seats_included INTEGER NOT NULL DEFAULT 1,
      seats_used INTEGER NOT NULL DEFAULT 0,
      module_overrides TEXT NOT NULL DEFAULT '[]',
      stripe_subscription_id TEXT,
      stripe_checkout_session_id TEXT,
      stripe_price_id TEXT,
      billing_currency TEXT DEFAULT 'eur',
      billing_email TEXT,
      current_period_end TEXT,
      last_payment_status TEXT,
      starts_at TEXT NOT NULL DEFAULT (datetime('now')),
      ends_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (company_id) REFERENCES companies(id),
      FOREIGN KEY (plan_id) REFERENCES plans(id)
    );

    CREATE TABLE IF NOT EXISTS company_admin_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      company_id INTEGER NOT NULL,
      actor_user_id INTEGER,
      actor_email TEXT,
      event_type TEXT NOT NULL,
      status_from TEXT,
      status_to TEXT,
      reason TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (company_id) REFERENCES companies(id),
      FOREIGN KEY (actor_user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS billing_payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      company_id INTEGER NOT NULL,
      company_subscription_id INTEGER,
      source TEXT NOT NULL DEFAULT 'stripe',
      provider_event_type TEXT,
      payment_kind TEXT NOT NULL DEFAULT 'subscription',
      status TEXT NOT NULL DEFAULT 'initiated',
      amount REAL NOT NULL DEFAULT 0,
      currency TEXT DEFAULT 'eur',
      payer_name TEXT,
      payer_email TEXT,
      reference_code TEXT,
      stripe_checkout_session_id TEXT,
      stripe_subscription_id TEXT,
      stripe_invoice_id TEXT,
      stripe_payment_intent_id TEXT,
      paid_at TEXT,
      failure_reason TEXT,
      notes TEXT,
      metadata TEXT,
      created_by_user_id INTEGER,
      created_by_email TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (company_id) REFERENCES companies(id),
      FOREIGN KEY (company_subscription_id) REFERENCES company_subscriptions(id),
      FOREIGN KEY (created_by_user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'admin',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS clients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      cui TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      address TEXT,
      reg_com TEXT,
      caen TEXT,
      vat INTEGER DEFAULT 0,
      inactive INTEGER DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS contracts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      contract_number TEXT NOT NULL UNIQUE,
      year INTEGER NOT NULL,
      seq INTEGER NOT NULL,
      client_id INTEGER NOT NULL,
      service_description TEXT NOT NULL,
      price REAL NOT NULL,
      duration TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      pdf_path TEXT,
      FOREIGN KEY (client_id) REFERENCES clients(id)
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT,
      name TEXT NOT NULL,
      unit TEXT DEFAULT 'buc',
      price REAL NOT NULL DEFAULT 0,
      tva_percent REAL NOT NULL DEFAULT 19,
      kind TEXT NOT NULL DEFAULT 'SERVICIU',
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      email TEXT,
      phone TEXT,
      position TEXT,
      is_primary INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS activities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client_id INTEGER NOT NULL,
      contact_id INTEGER,
      type TEXT NOT NULL,
      subject TEXT,
      note TEXT,
      due_at TEXT,
      done INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      employee_id INTEGER,
      FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE,
      FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS quotes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      quote_number TEXT NOT NULL UNIQUE,
      year INTEGER NOT NULL,
      seq INTEGER NOT NULL,
      client_id INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'DRAFT',
      title TEXT,
      notes TEXT,
      currency TEXT NOT NULL DEFAULT 'RON',
      subtotal REAL NOT NULL DEFAULT 0,
      vat_rate REAL NOT NULL DEFAULT 0,
      vat_amount REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      valid_until TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      pdf_path TEXT,
      contract_id INTEGER,
      FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS quote_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      quote_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      qty REAL NOT NULL DEFAULT 1,
      unit TEXT,
      unit_price REAL NOT NULL DEFAULT 0,
      line_total REAL NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (quote_id) REFERENCES quotes(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS facturi (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      factura_nr TEXT NOT NULL UNIQUE,
      an INTEGER NOT NULL,
      seq INTEGER NOT NULL,
      client_id INTEGER NOT NULL,
      contract_id INTEGER,
      quote_id INTEGER,
      status TEXT NOT NULL DEFAULT 'CIORNA',
      moneda TEXT NOT NULL DEFAULT 'RON',
      subtotal REAL NOT NULL DEFAULT 0,
      tva_procent REAL NOT NULL DEFAULT 0.19,
      tva_valoare REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      data_emitere TEXT NOT NULL DEFAULT (date('now')),
      scadenta TEXT,
      observatii TEXT,
      pdf_path TEXT,
      efactura_status TEXT,
      efactura_message_id TEXT,
      efactura_xml_path TEXT,
      efactura_last_error TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      employee_id INTEGER,
      FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS facturi_linii (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      factura_id INTEGER NOT NULL,
      denumire TEXT NOT NULL,
      cantitate REAL NOT NULL DEFAULT 1,
      unitate TEXT,
      pret_unitar REAL NOT NULL DEFAULT 0,
      total_linie REAL NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (factura_id) REFERENCES facturi(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value TEXT
    );

    CREATE TABLE IF NOT EXISTS tipizate_docs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      category TEXT,
      file_name TEXT NOT NULL,
      file_path TEXT NOT NULL,
      mime_type TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS anaf_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      account_id INTEGER,
      message_id TEXT,
      factura_id INTEGER,
      direction TEXT,
      status TEXT,
      payload TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS anaf_connections (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      environment TEXT NOT NULL DEFAULT 'test',
      access_token TEXT,
      refresh_token TEXT,
      token_type TEXT,
      scope TEXT,
      expires_at TEXT,
      refresh_expires_at TEXT,
      serial_certificate TEXT,
      raw_response TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS anaf_inbox (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      supplier_cui TEXT,
      invoice_number TEXT,
      xml_path TEXT,
      pdf_path TEXT,
      received_at TEXT,
      processed INTEGER NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS anaf_oauth_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_type TEXT NOT NULL,
      status TEXT,
      details TEXT,
      query_string TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS employees (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT,
      phone TEXT,
      position TEXT,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS accounting_expenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      company_id INTEGER NOT NULL,
      expense_type TEXT NOT NULL DEFAULT 'FACTURA',
      category TEXT,
      supplier_name TEXT NOT NULL,
      supplier_cui TEXT,
      doc_number TEXT,
      issue_date TEXT NOT NULL DEFAULT (date('now')),
      due_date TEXT,
      payment_status TEXT NOT NULL DEFAULT 'NEPLATITA',
      deductible_percent REAL NOT NULL DEFAULT 100,
      currency TEXT NOT NULL DEFAULT 'RON',
      subtotal REAL NOT NULL DEFAULT 0,
      vat_amount REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      notes TEXT,
      attachment_path TEXT,
      created_by_email TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS accounting_declarations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      company_id INTEGER NOT NULL,
      declaration_type TEXT NOT NULL,
      period_label TEXT,
      period_start TEXT,
      period_end TEXT,
      due_date TEXT,
      status TEXT NOT NULL DEFAULT 'PREGATITA',
      submission_channel TEXT NOT NULL DEFAULT 'MANUAL_SPV',
      reference_number TEXT,
      attachment_path TEXT,
      receipt_path TEXT,
      notes TEXT,
      created_by_email TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS consumption_vouchers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      company_id INTEGER NOT NULL,
      voucher_number TEXT NOT NULL,
      issue_date TEXT NOT NULL DEFAULT (date('now')),
      department TEXT,
      issued_to TEXT,
      notes TEXT,
      created_by_email TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS consumption_voucher_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      voucher_id INTEGER NOT NULL,
      product_id INTEGER,
      product_name TEXT NOT NULL,
      qty REAL NOT NULL DEFAULT 1,
      unit TEXT,
      unit_cost REAL NOT NULL DEFAULT 0,
      line_total REAL NOT NULL DEFAULT 0,
      notes TEXT,
      company_id INTEGER,
      FOREIGN KEY (voucher_id) REFERENCES consumption_vouchers(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_clients_cui ON clients(cui);
    CREATE INDEX IF NOT EXISTS idx_contracts_client_id ON contracts(client_id);
    CREATE INDEX IF NOT EXISTS idx_contracts_year_seq ON contracts(year, seq);
    CREATE INDEX IF NOT EXISTS idx_products_name ON products(name);
    CREATE INDEX IF NOT EXISTS idx_products_code ON products(code);
    CREATE INDEX IF NOT EXISTS idx_products_active ON products(active);
    CREATE INDEX IF NOT EXISTS idx_contacts_client_id ON contacts(client_id);
    CREATE INDEX IF NOT EXISTS idx_contacts_email ON contacts(email);
    CREATE INDEX IF NOT EXISTS idx_contacts_phone ON contacts(phone);
    CREATE INDEX IF NOT EXISTS idx_activities_client_id ON activities(client_id);
    CREATE INDEX IF NOT EXISTS idx_activities_contact_id ON activities(contact_id);
    CREATE INDEX IF NOT EXISTS idx_activities_type ON activities(type);
    CREATE INDEX IF NOT EXISTS idx_activities_done ON activities(done);
    CREATE INDEX IF NOT EXISTS idx_quotes_client_id ON quotes(client_id);
    CREATE INDEX IF NOT EXISTS idx_quotes_year_seq ON quotes(year, seq);
    CREATE INDEX IF NOT EXISTS idx_quotes_status ON quotes(status);
    CREATE INDEX IF NOT EXISTS idx_quote_items_quote_id ON quote_items(quote_id);
    CREATE INDEX IF NOT EXISTS idx_facturi_client_id ON facturi(client_id);
    CREATE INDEX IF NOT EXISTS idx_facturi_an_seq ON facturi(an, seq);
    CREATE INDEX IF NOT EXISTS idx_facturi_status ON facturi(status);
    CREATE INDEX IF NOT EXISTS idx_facturi_linii_factura_id ON facturi_linii(factura_id);
    CREATE INDEX IF NOT EXISTS idx_anaf_connections_environment ON anaf_connections(environment);
    CREATE INDEX IF NOT EXISTS idx_anaf_inbox_received_at ON anaf_inbox(received_at);
  `);

  ensureColumn("users", "module_permissions", "TEXT");
  ensureColumn("users", "company_id", "INTEGER");
  ensureColumn("users", "status", "TEXT DEFAULT 'active'");
  ensureColumn("users", "is_company_admin", "INTEGER NOT NULL DEFAULT 0");
  ensureColumn("companies", "stripe_customer_id", "TEXT");
  ensureColumn("companies", "suspension_reason", "TEXT");
  ensureColumn("companies", "suspended_at", "TEXT");
  ensureColumn("companies", "suspended_by_email", "TEXT");
  ensureColumn("company_subscriptions", "stripe_subscription_id", "TEXT");
  ensureColumn("company_subscriptions", "stripe_checkout_session_id", "TEXT");
  ensureColumn("company_subscriptions", "stripe_price_id", "TEXT");
  ensureColumn("company_subscriptions", "billing_currency", "TEXT DEFAULT 'eur'");
  ensureColumn("company_subscriptions", "billing_email", "TEXT");
  ensureColumn("company_subscriptions", "current_period_end", "TEXT");
  ensureColumn("company_subscriptions", "last_payment_status", "TEXT");
  ensureColumn("billing_payments", "provider_event_type", "TEXT");
  ensureColumn("billing_payments", "payment_kind", "TEXT NOT NULL DEFAULT 'subscription'");
  ensureColumn("billing_payments", "payer_name", "TEXT");
  ensureColumn("billing_payments", "payer_email", "TEXT");
  ensureColumn("billing_payments", "reference_code", "TEXT");
  ensureColumn("billing_payments", "stripe_checkout_session_id", "TEXT");
  ensureColumn("billing_payments", "stripe_subscription_id", "TEXT");
  ensureColumn("billing_payments", "stripe_invoice_id", "TEXT");
  ensureColumn("billing_payments", "stripe_payment_intent_id", "TEXT");
  ensureColumn("billing_payments", "paid_at", "TEXT");
  ensureColumn("billing_payments", "failure_reason", "TEXT");
  ensureColumn("billing_payments", "notes", "TEXT");
  ensureColumn("billing_payments", "metadata", "TEXT");
  ensureColumn("billing_payments", "created_by_user_id", "INTEGER");
  ensureColumn("billing_payments", "created_by_email", "TEXT");
  ensureColumn("billing_payments", "generated_factura_id", "INTEGER");
  ensureColumn("billing_payments", "invoice_generation_status", "TEXT");
  ensureColumn("billing_payments", "invoice_generated_at", "TEXT");

  const legacyClientsUniqueIndex = db.prepare(`PRAGMA index_list('clients')`).all()
    .some((index) => index.name === "sqlite_autoindex_clients_1");

  if (legacyClientsUniqueIndex) {
    db.exec(`
      PRAGMA foreign_keys=off;
      BEGIN TRANSACTION;
      ALTER TABLE clients RENAME TO clients_legacy_unique;
      CREATE TABLE clients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cui TEXT NOT NULL,
        name TEXT NOT NULL,
        address TEXT,
        reg_com TEXT,
        caen TEXT,
        vat INTEGER DEFAULT 0,
        inactive INTEGER DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        email TEXT,
        phone TEXT,
        client_status TEXT DEFAULT 'verde',
        notes TEXT,
        company_id INTEGER
      );
      INSERT INTO clients (id, cui, name, address, reg_com, caen, vat, inactive, created_at, email, phone, client_status, notes, company_id)
      SELECT id, cui, name, address, reg_com, caen, vat, inactive, created_at, email, phone, client_status, notes, company_id
      FROM clients_legacy_unique;
      DROP TABLE clients_legacy_unique;
      COMMIT;
      PRAGMA foreign_keys=on;
    `);
  }

  ensureColumn("clients", "email", "TEXT");
  ensureColumn("clients", "phone", "TEXT");
  ensureColumn("clients", "client_status", "TEXT DEFAULT 'verde'");
  ensureColumn("clients", "notes", "TEXT");
  ensureColumn("clients", "company_id", "INTEGER");

  ensureColumn("contracts", "origin", "TEXT DEFAULT 'DIRECT'");
  ensureColumn("contracts", "employee_id", "INTEGER");
  ensureColumn("contracts", "company_id", "INTEGER");

  ensureColumn("products", "company_id", "INTEGER");
  ensureColumn("contacts", "company_id", "INTEGER");
  ensureColumn("activities", "employee_id", "INTEGER");
  ensureColumn("activities", "company_id", "INTEGER");
  ensureColumn("quotes", "company_id", "INTEGER");
  ensureColumn("quote_items", "company_id", "INTEGER");
  ensureColumn("facturi", "employee_id", "INTEGER");
  ensureColumn("facturi", "company_id", "INTEGER");
  ensureColumn("facturi_linii", "company_id", "INTEGER");
  ensureColumn("tipizate_docs", "company_id", "INTEGER");
  ensureColumn("employees", "company_id", "INTEGER");
  ensureColumn("anaf_messages", "company_id", "INTEGER");
  ensureColumn("anaf_connections", "company_id", "INTEGER");
  ensureColumn("anaf_inbox", "company_id", "INTEGER");
  ensureColumn("anaf_oauth_logs", "company_id", "INTEGER");
  ensureColumn("accounting_expenses", "company_id", "INTEGER");
  ensureColumn("accounting_expenses", "expense_type", "TEXT NOT NULL DEFAULT 'FACTURA'");
  ensureColumn("accounting_expenses", "category", "TEXT");
  ensureColumn("accounting_expenses", "supplier_name", "TEXT NOT NULL DEFAULT ''");
  ensureColumn("accounting_expenses", "supplier_cui", "TEXT");
  ensureColumn("accounting_expenses", "doc_number", "TEXT");
  ensureColumn("accounting_expenses", "issue_date", "TEXT");
  ensureColumn("accounting_expenses", "due_date", "TEXT");
  ensureColumn("accounting_expenses", "payment_status", "TEXT NOT NULL DEFAULT 'NEPLATITA'");
  ensureColumn("accounting_expenses", "deductible_percent", "REAL NOT NULL DEFAULT 100");
  ensureColumn("accounting_expenses", "currency", "TEXT NOT NULL DEFAULT 'RON'");
  ensureColumn("accounting_expenses", "subtotal", "REAL NOT NULL DEFAULT 0");
  ensureColumn("accounting_expenses", "vat_amount", "REAL NOT NULL DEFAULT 0");
  ensureColumn("accounting_expenses", "total", "REAL NOT NULL DEFAULT 0");
  ensureColumn("accounting_expenses", "notes", "TEXT");
  ensureColumn("accounting_expenses", "attachment_path", "TEXT");
  ensureColumn("accounting_expenses", "created_by_email", "TEXT");
  ensureColumn("accounting_expenses", "updated_at", "TEXT NOT NULL DEFAULT (datetime('now'))");
  ensureColumn("accounting_declarations", "company_id", "INTEGER");
  ensureColumn("accounting_declarations", "declaration_type", "TEXT NOT NULL DEFAULT 'D112'");
  ensureColumn("accounting_declarations", "period_label", "TEXT");
  ensureColumn("accounting_declarations", "period_start", "TEXT");
  ensureColumn("accounting_declarations", "period_end", "TEXT");
  ensureColumn("accounting_declarations", "due_date", "TEXT");
  ensureColumn("accounting_declarations", "status", "TEXT NOT NULL DEFAULT 'PREGATITA'");
  ensureColumn("accounting_declarations", "submission_channel", "TEXT NOT NULL DEFAULT 'MANUAL_SPV'");
  ensureColumn("accounting_declarations", "reference_number", "TEXT");
  ensureColumn("accounting_declarations", "attachment_path", "TEXT");
  ensureColumn("accounting_declarations", "receipt_path", "TEXT");
  ensureColumn("accounting_declarations", "notes", "TEXT");
  ensureColumn("accounting_declarations", "created_by_email", "TEXT");
  ensureColumn("accounting_declarations", "updated_at", "TEXT NOT NULL DEFAULT (datetime('now'))");
  ensureColumn("consumption_vouchers", "company_id", "INTEGER");
  ensureColumn("consumption_vouchers", "voucher_number", "TEXT");
  ensureColumn("consumption_vouchers", "issue_date", "TEXT");
  ensureColumn("consumption_vouchers", "department", "TEXT");
  ensureColumn("consumption_vouchers", "issued_to", "TEXT");
  ensureColumn("consumption_vouchers", "notes", "TEXT");
  ensureColumn("consumption_vouchers", "created_by_email", "TEXT");
  ensureColumn("consumption_voucher_items", "product_id", "INTEGER");
  ensureColumn("consumption_voucher_items", "product_name", "TEXT NOT NULL DEFAULT ''");
  ensureColumn("consumption_voucher_items", "qty", "REAL NOT NULL DEFAULT 1");
  ensureColumn("consumption_voucher_items", "unit", "TEXT");
  ensureColumn("consumption_voucher_items", "unit_cost", "REAL NOT NULL DEFAULT 0");
  ensureColumn("consumption_voucher_items", "line_total", "REAL NOT NULL DEFAULT 0");
  ensureColumn("consumption_voucher_items", "notes", "TEXT");
  ensureColumn("consumption_voucher_items", "company_id", "INTEGER");
  ensureColumn("facturi", "efactura_upload_index", "TEXT");
  ensureColumn("facturi", "efactura_download_id", "TEXT");
  ensureColumn("facturi", "efactura_response_zip_path", "TEXT");
  ensureColumn("facturi", "efactura_last_checked_at", "TEXT");
  ensureColumn("anaf_connections", "scope", "TEXT");
  ensureColumn("anaf_connections", "expires_at", "TEXT");
  ensureColumn("anaf_connections", "refresh_expires_at", "TEXT");
  ensureColumn("anaf_connections", "serial_certificate", "TEXT");
  ensureColumn("anaf_connections", "raw_response", "TEXT");
  ensureColumn("anaf_connections", "updated_at", "TEXT DEFAULT CURRENT_TIMESTAMP");
  ensureColumn("anaf_messages", "details", "TEXT");
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_anaf_oauth_logs_created_at ON anaf_oauth_logs(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_anaf_connections_company_id ON anaf_connections(company_id);
    CREATE INDEX IF NOT EXISTS idx_anaf_inbox_company_id ON anaf_inbox(company_id);
    CREATE INDEX IF NOT EXISTS idx_anaf_messages_company_id ON anaf_messages(company_id);
    CREATE INDEX IF NOT EXISTS idx_anaf_oauth_logs_company_id ON anaf_oauth_logs(company_id);
    CREATE INDEX IF NOT EXISTS idx_company_admin_events_company_id ON company_admin_events(company_id);
    CREATE INDEX IF NOT EXISTS idx_company_admin_events_created_at ON company_admin_events(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_billing_payments_company_id ON billing_payments(company_id);
    CREATE INDEX IF NOT EXISTS idx_billing_payments_status ON billing_payments(status);
    CREATE INDEX IF NOT EXISTS idx_billing_payments_source ON billing_payments(source);
    CREATE INDEX IF NOT EXISTS idx_billing_payments_created_at ON billing_payments(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_billing_payments_stripe_checkout_session_id ON billing_payments(stripe_checkout_session_id);
    CREATE INDEX IF NOT EXISTS idx_billing_payments_stripe_subscription_id ON billing_payments(stripe_subscription_id);
    CREATE INDEX IF NOT EXISTS idx_billing_payments_stripe_invoice_id ON billing_payments(stripe_invoice_id);
    CREATE INDEX IF NOT EXISTS idx_billing_payments_stripe_payment_intent_id ON billing_payments(stripe_payment_intent_id);
    CREATE INDEX IF NOT EXISTS idx_companies_stripe_customer_id ON companies(stripe_customer_id);
    CREATE INDEX IF NOT EXISTS idx_company_subscriptions_stripe_subscription_id ON company_subscriptions(stripe_subscription_id);
    CREATE INDEX IF NOT EXISTS idx_users_company_id ON users(company_id);
    CREATE INDEX IF NOT EXISTS idx_company_subscriptions_company_id ON company_subscriptions(company_id);
    CREATE INDEX IF NOT EXISTS idx_company_subscriptions_status ON company_subscriptions(status);
    CREATE INDEX IF NOT EXISTS idx_clients_cui ON clients(cui);
    CREATE INDEX IF NOT EXISTS idx_clients_company_id ON clients(company_id);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_clients_company_cui_unique ON clients(company_id, cui);
    CREATE INDEX IF NOT EXISTS idx_accounting_expenses_company_id ON accounting_expenses(company_id);
    CREATE INDEX IF NOT EXISTS idx_accounting_expenses_issue_date ON accounting_expenses(issue_date DESC);
    CREATE INDEX IF NOT EXISTS idx_accounting_expenses_payment_status ON accounting_expenses(payment_status);
    CREATE INDEX IF NOT EXISTS idx_accounting_declarations_company_id ON accounting_declarations(company_id);
    CREATE INDEX IF NOT EXISTS idx_accounting_declarations_due_date ON accounting_declarations(due_date DESC);
    CREATE INDEX IF NOT EXISTS idx_accounting_declarations_status ON accounting_declarations(status);
    CREATE INDEX IF NOT EXISTS idx_consumption_vouchers_company_id ON consumption_vouchers(company_id);
    CREATE INDEX IF NOT EXISTS idx_consumption_vouchers_issue_date ON consumption_vouchers(issue_date DESC);
    CREATE INDEX IF NOT EXISTS idx_consumption_voucher_items_voucher_id ON consumption_voucher_items(voucher_id);
  `);

  for (const plan of DEFAULT_PLAN_DEFINITIONS) {
    db.prepare(`
      INSERT INTO plans (code, name, billing_period, price_monthly, max_users, module_keys, status)
      VALUES (?, ?, ?, ?, ?, ?, 'active')
      ON CONFLICT(code) DO UPDATE SET
        name=excluded.name,
        billing_period=excluded.billing_period,
        price_monthly=excluded.price_monthly,
        max_users=excluded.max_users,
        module_keys=excluded.module_keys,
        status='active',
        updated_at=datetime('now')
    `).run(
      plan.code,
      plan.name,
      plan.billing_period,
      plan.price_monthly,
      plan.max_users,
      JSON.stringify(plan.module_keys)
    );
  }

  const companyName = String(
    db.prepare(`SELECT value FROM app_settings WHERE key='company_name'`).get()?.value ||
    "Companie implicită"
  ).trim();
  const companyCui = String(db.prepare(`SELECT value FROM app_settings WHERE key='company_cui'`).get()?.value || "").trim();
  const companyRc = String(db.prepare(`SELECT value FROM app_settings WHERE key='company_rc'`).get()?.value || "").trim();
  const companyAddress = String(db.prepare(`SELECT value FROM app_settings WHERE key='company_address'`).get()?.value || "").trim();
  const companyBank = String(db.prepare(`SELECT value FROM app_settings WHERE key='company_bank'`).get()?.value || "").trim();
  const companyIban = String(db.prepare(`SELECT value FROM app_settings WHERE key='company_iban'`).get()?.value || "").trim();
  const companyRepresentative = String(db.prepare(`SELECT value FROM app_settings WHERE key='company_rep'`).get()?.value || "").trim();
  const companySlug = companyName
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "") || "companie";

  let company = db.prepare(`SELECT id FROM companies ORDER BY id LIMIT 1`).get();
  if (!company) {
    db.prepare(`
      INSERT INTO companies (name, slug, cui, rc, address, bank, iban, representative, status, max_users)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)
    `).run(
      companyName,
      companySlug,
      companyCui,
      companyRc,
      companyAddress,
      companyBank,
      companyIban,
      companyRepresentative,
      10
    );
    company = db.prepare(`SELECT id FROM companies ORDER BY id LIMIT 1`).get();
  } else {
    db.prepare(`
      UPDATE companies
      SET name=?, cui=?, rc=?, address=?, bank=?, iban=?, representative=?, updated_at=datetime('now')
      WHERE id=?
    `).run(
      companyName,
      companyCui,
      companyRc,
      companyAddress,
      companyBank,
      companyIban,
      companyRepresentative,
      company.id
    );
  }

  if (company?.id) {
    db.prepare(`
      UPDATE users
      SET company_id=?,
          is_company_admin=CASE WHEN LOWER(role)='admin' THEN 1 ELSE is_company_admin END,
          status=COALESCE(NULLIF(status, ''), 'active')
      WHERE company_id IS NULL
    `).run(company.id);

    const userCount = db.prepare(`SELECT COUNT(*) AS n FROM users WHERE company_id=?`).get(company.id)?.n || 0;
    const subscription = db.prepare(`
      SELECT id
      FROM company_subscriptions
      WHERE company_id=?
      ORDER BY id DESC
      LIMIT 1
    `).get(company.id);

    if (!subscription) {
      const enterprisePlan = db.prepare(`SELECT id, max_users FROM plans WHERE code='enterprise'`).get();
      if (enterprisePlan) {
        db.prepare(`
          INSERT INTO company_subscriptions (company_id, plan_id, status, seats_included, seats_used, module_overrides)
          VALUES (?, ?, 'active', ?, ?, ?)
        `).run(
          company.id,
          enterprisePlan.id,
          Math.max(enterprisePlan.max_users || 10, userCount || 1),
          userCount,
          JSON.stringify(ALL_MODULE_KEYS)
        );
      }
    } else {
      db.prepare(`
        UPDATE company_subscriptions
        SET seats_used=?,
            updated_at=datetime('now')
        WHERE id=?
      `).run(userCount, subscription.id);
    }

    db.prepare(`
      UPDATE companies
      SET max_users=COALESCE((
        SELECT seats_included
        FROM company_subscriptions
        WHERE company_id=companies.id
        ORDER BY id DESC
        LIMIT 1
      ), max_users),
      updated_at=datetime('now')
      WHERE id=?
    `).run(company.id);

    db.exec(`
      UPDATE clients SET company_id=${company.id} WHERE company_id IS NULL;
      UPDATE contracts SET company_id=${company.id} WHERE company_id IS NULL;
      UPDATE products SET company_id=${company.id} WHERE company_id IS NULL;
      UPDATE quotes SET company_id=${company.id} WHERE company_id IS NULL;
      UPDATE facturi SET company_id=${company.id} WHERE company_id IS NULL;
      UPDATE tipizate_docs SET company_id=${company.id} WHERE company_id IS NULL;
      UPDATE employees SET company_id=${company.id} WHERE company_id IS NULL;
      UPDATE anaf_messages SET company_id=${company.id} WHERE company_id IS NULL;
      UPDATE anaf_connections SET company_id=${company.id} WHERE company_id IS NULL;
      UPDATE anaf_inbox SET company_id=${company.id} WHERE company_id IS NULL;
      UPDATE anaf_oauth_logs SET company_id=${company.id} WHERE company_id IS NULL;
    `);

    db.exec(`
      UPDATE contacts
      SET company_id = (
        SELECT clients.company_id FROM clients WHERE clients.id = contacts.client_id
      )
      WHERE company_id IS NULL;

      UPDATE activities
      SET company_id = (
        SELECT clients.company_id FROM clients WHERE clients.id = activities.client_id
      )
      WHERE company_id IS NULL;

      UPDATE quote_items
      SET company_id = (
        SELECT quotes.company_id FROM quotes WHERE quotes.id = quote_items.quote_id
      )
      WHERE company_id IS NULL;

      UPDATE facturi_linii
      SET company_id = (
        SELECT facturi.company_id FROM facturi WHERE facturi.id = facturi_linii.factura_id
      )
      WHERE company_id IS NULL;
    `);
  }
}
