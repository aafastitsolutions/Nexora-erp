import express from "express";
import dotenv from "dotenv";
dotenv.config();
import Mustache from "mustache";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { renderPdfBuffer } from "./pdf.js";

import { fetchAnafCompany } from "./lib/anaf.js";
import { anafCheckUploadStatus, anafDownloadMessage, anafUploadFactura } from "./lib/anaf-efactura.js";
import { COMPANY, MODULE_DEFINITIONS, MODULE_GROUPS, ROLE_MODULES, registerRoleModules } from "./lib/app-config.js";
import { createTransporter, initApplication, loadTemplates, setupAppMiddleware } from "./lib/bootstrap.js";
import { maybeGenerateBillingInvoice } from "./lib/billing-invoices.js";
import { escapeHtml, fmt2, fmtMoney, hasModuleAccess, normalizeCui, todayISO } from "./lib/helpers.js";
import { registerAccountingRoutes } from "./routes/accounting-routes.js";
import { registerAnafRoutes } from "./routes/anaf-routes.js";
import { registerAnafOAuthRoutes } from "./routes/anaf-oauth-routes.js";
import { registerAuthRoutes } from "./routes/auth-routes.js";
import { registerBillingRoutes, registerBillingWebhook } from "./routes/billing-routes.js";
import { registerClientsRoutes } from "./routes/clients-routes.js";
import { registerContractsRoutes } from "./routes/contracts-routes.js";
import { registerDashboardRoutes } from "./routes/dashboard-routes.js";
import { registerFacturiRoutes } from "./routes/facturi-routes.js";
import { registerQuotesRoutes } from "./routes/quotes-routes.js";
import { db, migrate } from "./db.js";
import bcrypt from "bcrypt";
import { requireAuth, requireRole, requireModule, requireSuperAdmin, seedAdminFromEnv, verifyUser, verifyUserAttempt } from "./auth.js";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const isProduction = process.env.NODE_ENV === "production";
const sessionSecret = process.env.SESSION_SECRET || "dev-secret-change-me";
const transporter = createTransporter();

registerRoleModules();
initApplication({ app, isProduction, sessionSecret, migrate, seedAdminFromEnv });
registerBillingWebhook(app, { db });
setupAppMiddleware({ app, dirname: __dirname, sessionSecret });
registerAnafRoutes(app, { fetchAnafCompany, normalizeCui });
registerAnafOAuthRoutes(app, { db, getSetting, requireAuth, setSetting });
registerAuthRoutes(app, { db, verifyUser, verifyUserAttempt });
registerBillingRoutes(app, { db, requireAuth, requireRole, getSetting, refreshSessionCompanyAccess });
registerDashboardRoutes(app, { db, requireAuth, todayISO, escapeHtml, fmtMoney, crmShellStart, crmShellEnd });

const { templateHtml, invoiceTemplateHtml, quoteTemplateHtml, uiHtml } = loadTemplates(__dirname);
registerQuotesRoutes(app, {
  COMPANY,
  Mustache,
  __dirname,
  db,
  escapeHtml,
  fmtMoney,
  hasModuleAccess,
  nextQuoteNumber,
  quoteTemplateHtml,
  recalcQuoteTotals,
  renderPdfBuffer,
  requireAuth,
  templateHtml,
  todayISO,
  crmShellStart,
  crmShellEnd,
  path,
  fs
});
registerFacturiRoutes(app, {
  COMPANY,
  Mustache,
  __dirname,
  crmShellEnd,
  crmShellStart,
  db,
  escapeHtml,
  ensureFacturaXmlGenerated,
  anafCheckUploadStatus,
  anafDownloadMessage,
  anafUploadFactura,
  fetchAnafCompany,
  fmt2,
  fmtMoney,
  fs,
  getInvoiceLogoDataUri,
  getInvoiceTheme,
  getSetting,
  invoiceTemplateHtml,
  nextFacturaNumber,
  normalizeCui,
  path,
  recalcFacturaTotals,
  renderPdfBuffer,
  requireAuth,
  transporter
});
registerContractsRoutes(app, {
  COMPANY,
  Mustache,
  __dirname,
  crmShellEnd,
  crmShellStart,
  db,
  escapeHtml,
  fs,
  path,
  renderPdfBuffer,
  requireAuth,
  templateHtml,
  todayISO
});
registerClientsRoutes(app, {
  crmShellEnd,
  crmShellStart,
  db,
  escapeHtml,
  fetchAnafCompany,
  normalizeCui,
  requireAuth
});

function nextQuoteNumber(){
  const year = new Date().getFullYear();

  const row = db.prepare(`
    SELECT seq
    FROM quotes
    WHERE year=?
    ORDER BY seq DESC
    LIMIT 1
  `).get(year);

  const seq = (row?.seq || 0) + 1;
  const num = "Q-" + year + "-" + String(seq).padStart(4,"0");

  return { year, seq, quote_number:num };
}


function nextFacturaNumber(){
  const an = new Date().getFullYear();

  const row = db.prepare(`
    SELECT seq
    FROM facturi
    WHERE an=?
    ORDER BY seq DESC
    LIMIT 1
  `).get(an);

  const seq = (row?.seq || 0) + 1;
  const factura_nr = "INV-" + an + "-" + String(seq).padStart(4,"0");

  return { an, seq, factura_nr };
}


// =========================
// Quotes / Offers (v1)
// =========================

function recalcQuoteTotals(quote_id){
  const items = db.prepare(`
    SELECT id, qty, unit_price
    FROM quote_items
    WHERE quote_id=?
  `).all(quote_id);

  let subtotal = 0;
  for (const it of items) {
    const q = Number(it.qty ?? 0);
    const p = Number(it.unit_price ?? 0);
    const line = (Number.isFinite(q) ? q : 0) * (Number.isFinite(p) ? p : 0);
    subtotal += line;
    db.prepare("UPDATE quote_items SET line_total=? WHERE id=?").run(line, it.id);
  }

  const qrow = db.prepare("SELECT vat_rate FROM quotes WHERE id=?").get(quote_id);
  const vat_rate = Number(qrow?.vat_rate ?? 0);
  const vat_amount = subtotal * (Number.isFinite(vat_rate) ? vat_rate : 0);
  const total = subtotal + vat_amount;

  db.prepare(`
    UPDATE quotes
    SET subtotal=?, vat_amount=?, total=?
    WHERE id=?
  `).run(subtotal, vat_amount, total, quote_id);

  return { subtotal, vat_rate, vat_amount, total };
}

app.get("/export/contracts.csv", requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT c.id, c.contract_number, c.created_at, c.year, c.seq,
           c.service_description, c.price, c.duration, c.pdf_path,
           cl.cui AS client_cui, cl.name AS client_name
    FROM contracts c
    JOIN clients cl ON cl.id = c.client_id
    ORDER BY c.id DESC
    LIMIT 5000
  `).all();

  function csvEscape(v){
    const s = String(v ?? "");
    if (/[",\n\r;]/.test(s)) return '"' + s.replaceAll('"','""') + '"';
    return s;
  }

  const header = [
    "id","contract_number","created_at","year","seq",
    "client_cui","client_name",
    "service_description","price","duration","pdf_path"
  ].join(",");

  const lines = rows.map(r => [
    r.id, r.contract_number, r.created_at, r.year, r.seq,
    r.client_cui, r.client_name,
    r.service_description, r.price, r.duration, r.pdf_path
  ].map(csvEscape).join(","));

  const csv = [header, ...lines].join("\n");

  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", "attachment; filename=contracts.csv");
  res.send(csv);
});


function uiShellStyles(){
  return `
  <style>
    :root{
      --bg:#eff3f8;
      --bg-accent:rgba(15,23,42,.08);
      --panel:rgba(255,255,255,.88);
      --panel-2:#f8fafc;
      --line:rgba(148,163,184,.22);
      --line-2:rgba(148,163,184,.34);
      --text:#0f172a;
      --muted:#64748b;
      --nav:#0f172a;
      --nav-2:#172033;
      --nav-line:rgba(255,255,255,.08);
      --nav-text:#cbd5e1;
      --nav-muted:#7f8ea3;
      --nav-active-bg:linear-gradient(135deg,#2463eb,#1637a3);
      --nav-active-text:#ffffff;
      --primary:#2563eb;
      --primary-2:#1d4ed8;
      --success:#15803d;
      --danger:#be123c;
      --warning:#b45309;
      --radius:22px;
      --shadow:0 20px 60px rgba(15,23,42,.10);
      --shadow-soft:0 10px 30px rgba(15,23,42,.07);
      --topbar:rgba(255,255,255,.78);
      --topbar-border:rgba(255,255,255,.7);
      --kpi-bg:linear-gradient(180deg,rgba(255,255,255,.96) 0%, rgba(248,250,252,.88) 100%);
      --table-head:#f8fafc;
      --hover:#f8fbff;
      --theme-ring:rgba(37,99,235,.18);
      --hero-start:#1e293b;
      --hero-mid:#1d4ed8;
      --hero-end:#38bdf8;
    }

    body.crm-body[data-theme="ivory-gold"]{
      --bg:#f6f0e4;
      --bg-accent:rgba(146,109,44,.12);
      --panel:rgba(255,250,244,.9);
      --panel-2:#fffaf0;
      --line:rgba(146,109,44,.18);
      --line-2:rgba(146,109,44,.28);
      --text:#332316;
      --muted:#7a6146;
      --nav:#2f2218;
      --nav-2:#473324;
      --nav-line:rgba(255,242,218,.10);
      --nav-text:#f1dfc2;
      --nav-muted:#bea37d;
      --nav-active-bg:linear-gradient(135deg,#b88a44,#8d6420);
      --primary:#9f6d25;
      --primary-2:#80541b;
      --success:#3d7a3d;
      --danger:#a23b34;
      --warning:#9b5d00;
      --topbar:rgba(255,248,239,.75);
      --topbar-border:rgba(255,245,226,.72);
      --kpi-bg:linear-gradient(180deg,rgba(255,251,246,.98) 0%, rgba(252,245,233,.92) 100%);
      --table-head:#f8eee0;
      --hover:#fff8ef;
      --theme-ring:rgba(184,138,68,.18);
      --hero-start:#4a3118;
      --hero-mid:#9f6d25;
      --hero-end:#d9b36a;
    }

    body.crm-body[data-theme="forest-ledger"]{
      --bg:#e8f2ec;
      --bg-accent:rgba(29,78,59,.10);
      --panel:rgba(250,255,252,.9);
      --panel-2:#f4fbf7;
      --line:rgba(58,110,88,.18);
      --line-2:rgba(58,110,88,.28);
      --text:#163127;
      --muted:#537567;
      --nav:#11251d;
      --nav-2:#193429;
      --nav-line:rgba(214,255,235,.08);
      --nav-text:#d4efe1;
      --nav-muted:#86a899;
      --nav-active-bg:linear-gradient(135deg,#1f7a55,#14523a);
      --primary:#1e7b57;
      --primary-2:#155a40;
      --success:#146c43;
      --danger:#a22c48;
      --warning:#a16207;
      --topbar:rgba(245,255,250,.76);
      --topbar-border:rgba(232,247,239,.7);
      --kpi-bg:linear-gradient(180deg,rgba(250,255,252,.98) 0%, rgba(239,248,243,.92) 100%);
      --table-head:#eef8f1;
      --hover:#f4fcf7;
      --theme-ring:rgba(30,123,87,.18);
      --hero-start:#123126;
      --hero-mid:#1e7b57;
      --hero-end:#4ecb95;
    }

    body.crm-body[data-theme="midnight-neon"]{
      --bg:#0a1020;
      --bg-accent:rgba(0,229,255,.12);
      --panel:rgba(14,21,42,.82);
      --panel-2:#101935;
      --line:rgba(82,109,173,.28);
      --line-2:rgba(82,109,173,.38);
      --text:#e5eefb;
      --muted:#95a7c6;
      --nav:#060b17;
      --nav-2:#0c1428;
      --nav-line:rgba(96,165,250,.10);
      --nav-text:#c2d7ff;
      --nav-muted:#6881ad;
      --nav-active-bg:linear-gradient(135deg,#00c2ff,#3b82f6);
      --primary:#22c1ff;
      --primary-2:#1095cb;
      --success:#34d399;
      --danger:#fb7185;
      --warning:#fbbf24;
      --topbar:rgba(10,16,32,.62);
      --topbar-border:rgba(38,56,102,.8);
      --kpi-bg:linear-gradient(180deg,rgba(16,25,53,.94) 0%, rgba(10,16,32,.84) 100%);
      --table-head:#101935;
      --hover:#121d3a;
      --theme-ring:rgba(34,193,255,.18);
      --hero-start:#07111f;
      --hero-mid:#0f4fa8;
      --hero-end:#22c1ff;
    }

    *{box-sizing:border-box}
    html,body{margin:0;padding:0}
    body.crm-body{
      font-family:"Plus Jakarta Sans","Segoe UI",sans-serif;
      background:var(--bg);
      color:var(--text);
      position:relative;
      overflow-x:hidden;
    }

    body.crm-body::before,
    body.crm-body::after{
      content:"";
      position:fixed;
      inset:auto;
      border-radius:999px;
      pointer-events:none;
      z-index:0;
      filter:blur(12px);
    }

    body.crm-body::before{
      width:440px;
      height:440px;
      top:-120px;
      right:-120px;
      background:radial-gradient(circle,var(--bg-accent) 0%, rgba(255,255,255,0) 70%);
    }

    body.crm-body::after{
      width:380px;
      height:380px;
      left:-140px;
      bottom:-120px;
      background:radial-gradient(circle,var(--theme-ring) 0%, rgba(255,255,255,0) 72%);
    }

    .crm-layout{
      min-height:100vh;
      display:grid;
      grid-template-columns:260px minmax(0,1fr);
      position:relative;
      z-index:1;
    }

    .crm-sidebar{
      background:
        radial-gradient(circle at top right, rgba(255,255,255,.08), transparent 34%),
        linear-gradient(180deg,var(--nav) 0%, var(--nav-2) 100%);
      color:var(--nav-text);
      padding:22px 18px;
      border-right:1px solid var(--nav-line);
      position:sticky;
      top:0;
      height:100vh;
      overflow:auto;
    }

    .crm-brand{
      display:flex;
      align-items:center;
      gap:12px;
      margin-bottom:22px;
      padding:6px 4px 18px 4px;
      border-bottom:1px solid var(--nav-line);
    }

    .crm-brand-copy{
      min-width:0;
    }

    .crm-brand-badge{
      width:42px;
      height:42px;
      border-radius:14px;
      background:linear-gradient(135deg,#3b82f6,#1d4ed8);
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-weight:800;
      box-shadow:0 10px 25px rgba(37,99,235,.35);
      flex:0 0 auto;
    }

    .crm-brand-title{
      color:#fff;
      font-size:16px;
      font-weight:800;
      line-height:1.15;
      margin:0;
    }

    .crm-brand-sub{
      color:#94a3b8;
      font-size:12px;
      margin-top:3px;
    }

    .crm-nav{
      display:flex;
      flex-direction:column;
      gap:8px;
      margin-top:10px;
    }

    .crm-nav-section{
      margin:18px 8px 8px 8px;
      font-size:11px;
      font-weight:700;
      letter-spacing:.08em;
      text-transform:uppercase;
      color:var(--nav-muted);
    }

    .crm-nav-group{
      border:1px solid rgba(255,255,255,.05);
      background:rgba(255,255,255,.03);
      border-radius:18px;
      padding:10px;
      box-shadow:inset 0 1px 0 rgba(255,255,255,.02);
    }

    .crm-nav-group-head{
      display:flex;
      justify-content:space-between;
      align-items:flex-start;
      gap:10px;
      padding:4px 6px 8px 6px;
    }

    .crm-nav-group-title{
      font-size:14px;
      font-weight:800;
      color:#fff;
    }

    .crm-nav-group-sub{
      margin-top:2px;
      color:var(--nav-muted);
      font-size:11px;
      line-height:1.35;
    }

    .crm-nav-pill{
      flex:0 0 auto;
      padding:4px 9px;
      border-radius:999px;
      font-size:10px;
      font-weight:800;
      letter-spacing:.06em;
      text-transform:uppercase;
      color:#fff;
      background:rgba(255,255,255,.08);
    }

    .crm-nav a{
      text-decoration:none;
      color:var(--nav-text);
      display:flex;
      align-items:center;
      gap:10px;
      padding:11px 12px;
      border-radius:14px;
      border:1px solid transparent;
      transition:all .16s ease;
      font-weight:600;
    }

    .crm-nav-icon{
      width:18px;
      height:18px;
      flex:0 0 auto;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      color:currentColor;
      opacity:.95;
    }

    .crm-nav-icon svg{
      width:18px;
      height:18px;
      stroke:currentColor;
      fill:none;
      stroke-width:1.9;
      stroke-linecap:round;
      stroke-linejoin:round;
    }

    .crm-nav a:hover{
      background:rgba(255,255,255,.06);
      color:#fff;
      border-color:rgba(255,255,255,.06);
    }

    .crm-nav a.active{
      background:var(--nav-active-bg);
      color:var(--nav-active-text);
      box-shadow:0 8px 22px rgba(37,99,235,.35);
    }

    .crm-nav-subnav{
      margin:-2px 0 4px 14px;
      padding-left:12px;
      border-left:1px solid rgba(255,255,255,.10);
      display:flex;
      flex-direction:column;
      gap:6px;
    }

    .crm-nav-subnav-title{
      margin:6px 0 0 14px;
      padding-left:12px;
      color:#e2e8f0;
      font-size:12px;
      font-weight:800;
      letter-spacing:.04em;
      text-transform:uppercase;
    }

    .crm-nav-subnav a{
      padding:9px 12px;
      font-size:13px;
      border-radius:12px;
      background:rgba(255,255,255,.02);
    }

    .crm-sidebar-footer{
      margin-top:18px;
      padding-top:16px;
      border-top:1px solid var(--nav-line);
    }

    .crm-sidebar-footer-title{
      margin:0 8px 10px 8px;
      font-size:11px;
      font-weight:700;
      letter-spacing:.08em;
      text-transform:uppercase;
      color:var(--nav-muted);
    }

    .crm-sidebar .crm-theme-switcher{
      margin:0 6px;
      display:grid;
      grid-template-columns:1fr;
      gap:8px;
    }

    .crm-sidebar .crm-theme-chip{
      width:100%;
      justify-content:flex-start;
      background:rgba(255,255,255,.04);
      border-color:rgba(255,255,255,.08);
      color:var(--nav-text);
    }

    .crm-sidebar .crm-theme-chip:hover{
      background:rgba(255,255,255,.08);
      color:#fff;
    }

    .crm-sidebar-meta{
      margin:14px 6px 0 6px;
      display:grid;
      gap:8px;
    }

    .crm-sidebar-meta-chip{
      display:grid;
      gap:4px;
      padding:10px 12px;
      border-radius:14px;
      border:1px solid rgba(255,255,255,.08);
      background:rgba(255,255,255,.05);
      color:var(--nav-text);
    }

    .crm-sidebar-meta-chip strong{
      font-size:11px;
      letter-spacing:.08em;
      text-transform:uppercase;
      color:var(--nav-muted);
      font-weight:800;
    }

    .crm-sidebar-meta-chip span{
      font-size:13px;
      font-weight:700;
      color:#fff;
      word-break:break-word;
    }

    .crm-main{
      min-width:0;
      padding:24px;
    }

    .login-shell::before{
    content:"";
    position:absolute;
    inset:10% -8% auto -8%;
    height:220px;
    background:radial-gradient(circle, rgba(255,255,255,.16), rgba(255,255,255,0) 70%);
    filter:blur(10px);
    pointer-events:none;
    }

    .crm-topbar{
      display:flex;
      justify-content:space-between;
      align-items:flex-start;
      gap:16px;
      margin-bottom:20px;
      background:var(--topbar);
      backdrop-filter:blur(8px);
      border:1px solid var(--topbar-border);
      border-radius:24px;
      padding:18px 20px;
      box-shadow:var(--shadow);
    }

    .crm-topbar.crm-topbar-compact{
      flex-direction:column;
      justify-content:flex-start;
      align-items:flex-end;
      gap:8px;
      margin-bottom:12px;
      padding:0;
      background:transparent;
      border:none;
      box-shadow:none;
      backdrop-filter:none;
    }

    .crm-topbar-meta{
      display:flex;
      flex-direction:column;
      align-items:flex-end;
      gap:6px;
      width:auto;
      max-width:100%;
    }

    .crm-topbar-meta-row{
      display:flex;
      gap:6px;
      flex-wrap:wrap;
      justify-content:flex-end;
    }

    .crm-topbar-chip{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:7px 11px;
      border-radius:14px;
      border:1px solid rgba(148,163,184,.22);
      background:rgba(255,255,255,.78);
      box-shadow:0 8px 20px rgba(15,23,42,.05);
      font-size:12px;
      color:#0f172a;
      max-width:100%;
    }

    .crm-topbar-chip strong{
      font-size:11px;
      letter-spacing:.08em;
      text-transform:uppercase;
      color:#6b7280;
      font-weight:800;
    }

    .crm-topbar-chip span{
      font-weight:600;
      color:#1f2937;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
      max-width:260px;
    }

    .crm-topbar-chip-status-active{
      background:rgba(240,253,244,.95);
      border-color:rgba(134,239,172,.55);
    }

    .crm-topbar-chip-status-trial{
      background:rgba(239,246,255,.95);
      border-color:rgba(147,197,253,.5);
    }

    .crm-topbar-chip-status-past_due{
      background:rgba(255,251,235,.96);
      border-color:rgba(252,211,77,.55);
    }

    .crm-page-kicker{
      color:var(--muted);
      font-size:12px;
      font-weight:700;
      text-transform:uppercase;
      letter-spacing:.08em;
      margin:0 0 8px 0;
    }

    .crm-page-title{
      margin:0;
      font-size:30px;
      line-height:1.1;
      font-weight:800;
      color:var(--text);
    }

    .crm-page-subtitle{
      margin-top:6px;
      color:var(--muted);
      font-size:14px;
    }

    .crm-user{
      color:var(--muted);
      font-size:13px;
      margin-top:6px;
    }

    .crm-actions{
      display:flex;
      gap:10px;
      align-items:center;
      flex-wrap:wrap;
    }

    .crm-content{
      min-width:0;
    }

    .crm-card{
      background:var(--panel);
      border:1px solid var(--line);
      border-radius:var(--radius);
      box-shadow:var(--shadow-soft);
      backdrop-filter:blur(8px);
      padding:20px;
    }

    .crm-card + .crm-card{ margin-top:18px; }

    .crm-grid{
      display:grid;
      gap:18px;
    }

    .crm-grid-2{
      display:grid;
      grid-template-columns:repeat(2,minmax(0,1fr));
      gap:18px;
    }

    .crm-kpis{
      display:grid;
      grid-template-columns:repeat(4,minmax(0,1fr));
      gap:16px;
    }

    .crm-kpi{
      background:var(--kpi-bg);
      border:1px solid var(--line);
      border-radius:20px;
      padding:18px;
      box-shadow:var(--shadow-soft);
    }

    .crm-kpi-label{
      color:var(--muted);
      font-size:13px;
      font-weight:600;
      margin-bottom:8px;
    }

    .crm-kpi-value{
      font-size:28px;
      font-weight:800;
      color:var(--text);
      line-height:1;
    }

    .crm-hero-grid{
      display:grid;
      grid-template-columns:1.35fr .95fr;
      gap:0;
    }

    .crm-hero-panel{
      padding:28px;
      background:linear-gradient(135deg,var(--hero-start) 0%,var(--hero-mid) 54%,var(--hero-end) 100%);
      color:#fff;
    }

    .crm-hero-side{
      padding:28px;
      background:linear-gradient(180deg,rgba(255,255,255,.96) 0%, rgba(248,250,252,.92) 100%);
      border-left:1px solid var(--line);
    }

    .crm-hero-metrics{
      display:grid;
      grid-template-columns:repeat(3,minmax(0,1fr));
      gap:12px;
      margin-top:22px;
    }

    .crm-table-wrap{
      background:var(--panel);
      border:1px solid var(--line);
      border-radius:18px;
      overflow:hidden;
      box-shadow:var(--shadow-soft);
    }

    table.crm-table{
      width:100%;
      border-collapse:collapse;
      background:transparent;
    }

    .crm-table th,
    .crm-table td{
      padding:14px 16px;
      border-bottom:1px solid #eef2f7;
      text-align:left;
      vertical-align:top;
    }

    .crm-table th{
      background:var(--table-head);
      color:var(--muted);
      font-size:12px;
      text-transform:uppercase;
      letter-spacing:.05em;
      font-weight:800;
    }

    .crm-table tbody tr:hover td{
      background:var(--hover);
    }

    .crm-input,
    .crm-select,
    .crm-textarea{
      width:100%;
      padding:11px 13px;
      border:1px solid var(--line-2);
      border-radius:12px;
      background:rgba(255,255,255,.88);
      color:var(--text);
      outline:none;
      transition:border-color .15s ease, box-shadow .15s ease, background .15s ease;
    }

    body.crm-body[data-theme="midnight-neon"] .crm-input,
    body.crm-body[data-theme="midnight-neon"] .crm-select,
    body.crm-body[data-theme="midnight-neon"] .crm-textarea{
      background:rgba(10,16,32,.82);
      color:var(--text);
    }

    .crm-input:focus,
    .crm-select:focus,
    .crm-textarea:focus{
      border-color:#93c5fd;
      box-shadow:0 0 0 4px rgba(37,99,235,.12);
    }

    .crm-label{
      display:block;
      margin-bottom:8px;
      font-weight:700;
      color:#334155;
      font-size:14px;
    }

    .crm-btn{
      appearance:none;
      border:none;
      background:var(--primary);
      color:#fff;
      padding:10px 14px;
      border-radius:12px;
      font-weight:700;
      cursor:pointer;
      box-shadow:0 8px 18px rgba(37,99,235,.18);
      transition:transform .12s ease, box-shadow .12s ease, background .12s ease;
    }

    .crm-btn:hover{
      background:var(--primary-2);
      transform:translateY(-1px);
      box-shadow:0 12px 24px rgba(37,99,235,.22);
    }

    .crm-btn-secondary{
      background:rgba(148,163,184,.18);
      color:var(--text);
      box-shadow:none;
      border:1px solid var(--line);
    }

    .crm-btn-secondary:hover{
      background:rgba(148,163,184,.28);
      box-shadow:none;
    }

    .crm-btn-danger{
      background:#fff1f2;
      color:var(--danger);
      border:1px solid #fecdd3;
      box-shadow:none;
    }

    .crm-btn-danger:hover{
      background:#ffe4e6;
      box-shadow:none;
    }

    .crm-icon-btn{
      appearance:none;
      border:1px solid var(--line);
      background:var(--panel);
      color:var(--text);
      width:42px;
      height:42px;
      border-radius:14px;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      cursor:pointer;
      box-shadow:var(--shadow-soft);
      transition:transform .12s ease, border-color .12s ease, background .12s ease;
    }

    .crm-icon-btn:hover{
      transform:translateY(-1px);
      border-color:var(--primary);
    }

    .crm-icon-btn svg{
      width:18px;
      height:18px;
      stroke:currentColor;
      fill:none;
      stroke-width:2;
      stroke-linecap:round;
      stroke-linejoin:round;
    }

    .crm-badge{
      display:inline-flex;
      align-items:center;
      gap:6px;
      padding:6px 10px;
      border-radius:999px;
      font-size:12px;
      font-weight:800;
      border:1px solid transparent;
    }

    .crm-badge-neutral{background:#f1f5f9;color:#334155;border-color:#e2e8f0}
    .crm-badge-blue{background:#dbeafe;color:#1d4ed8;border-color:#bfdbfe}
    .crm-badge-green{background:#dcfce7;color:#166534;border-color:#bbf7d0}
    .crm-badge-amber{background:#fef3c7;color:#92400e;border-color:#fde68a}
    .crm-badge-red{background:#ffe4e6;color:#be123c;border-color:#fecdd3}

    .crm-muted{color:var(--muted)}
    .crm-right{text-align:right}
    .crm-stack{display:flex;flex-direction:column;gap:18px}
    .crm-row{display:flex;gap:12px;flex-wrap:wrap;align-items:end}

    .crm-mobile-nav{
      display:none;
      margin:0 0 16px 0;
      padding:14px;
      background:linear-gradient(180deg,var(--nav) 0%, var(--nav-2) 100%);
      border-radius:22px;
      box-shadow:var(--shadow);
    }

    .crm-mobile-nav .crm-nav{
      gap:8px;
    }

    .crm-mobile-nav a{
      color:#cbd5e1;
    }

    .crm-mobile-nav a.active{
      background:#2563eb;
      color:#fff;
    }

    .crm-theme-switcher{
      display:flex;
      gap:10px;
      flex-wrap:wrap;
      justify-content:flex-end;
      margin-bottom:12px;
    }

    .crm-card .crm-theme-switcher{
      justify-content:flex-start;
      margin-bottom:0;
    }

    .crm-theme-chip{
      appearance:none;
      border:1px solid var(--line);
      background:var(--panel);
      color:var(--text);
      border-radius:999px;
      padding:8px 10px;
      display:flex;
      align-items:center;
      gap:8px;
      cursor:pointer;
      font:inherit;
      font-size:12px;
      font-weight:800;
      box-shadow:var(--shadow-soft);
      transition:transform .14s ease, border-color .14s ease, box-shadow .14s ease;
    }

    .crm-theme-chip:hover{
      transform:translateY(-1px);
      border-color:var(--primary);
    }

    .crm-theme-chip.active{
      border-color:var(--primary);
      box-shadow:0 0 0 4px var(--theme-ring);
    }

    .crm-theme-dot{
      width:12px;
      height:12px;
      border-radius:999px;
      flex:0 0 auto;
      box-shadow:inset 0 0 0 1px rgba(255,255,255,.22);
    }

    body.crm-body[data-sidebar="collapsed"] .crm-layout{
      grid-template-columns:96px minmax(0,1fr);
    }

    body.crm-body[data-sidebar="collapsed"] .crm-sidebar{
      padding-left:12px;
      padding-right:12px;
    }

    body.crm-body[data-sidebar="collapsed"] .crm-brand{
      justify-content:center;
    }

    body.crm-body[data-sidebar="collapsed"] .crm-brand-copy,
    body.crm-body[data-sidebar="collapsed"] .crm-nav-section,
    body.crm-body[data-sidebar="collapsed"] .crm-nav-group-head,
    body.crm-body[data-sidebar="collapsed"] .crm-nav-subnav{
      display:none;
    }

    body.crm-body[data-sidebar="collapsed"] .crm-nav-group{
      padding:6px;
      background:transparent;
      border-color:transparent;
      box-shadow:none;
    }

    body.crm-body[data-sidebar="collapsed"] .crm-nav a{
      justify-content:center;
      padding:12px;
    }

    body.crm-body[data-sidebar="collapsed"] .crm-nav a span:last-child{
      display:none;
    }

    .top{margin-bottom:0 !important}

    @media (max-width: 1100px){
      .crm-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}
      .crm-grid-2{grid-template-columns:1fr}
      .crm-hero-grid{grid-template-columns:1fr}
      .crm-hero-side{border-left:none;border-top:1px solid var(--line)}
      .crm-layout{grid-template-columns:1fr}
      .crm-sidebar{display:none}
      .crm-mobile-nav{display:block}
      .crm-main{padding:16px}
      .crm-topbar{padding:16px}
      .crm-page-title{font-size:24px}
      .crm-theme-switcher{justify-content:flex-start}
    }

    @media (max-width: 720px){
      .crm-kpis{grid-template-columns:1fr}
      .crm-hero-metrics{grid-template-columns:1fr}
      .crm-topbar{
        flex-direction:column;
        align-items:stretch;
      }
      .crm-actions{
        width:100%;
      }
      .crm-theme-switcher{
        gap:8px;
      }
      .crm-theme-chip{
        width:100%;
        justify-content:flex-start;
      }
    }
  </style>`;
}

function crmThemeSwitcher(){
  const themes = [
    ["executive-slate", "Executive", "linear-gradient(135deg,#2563eb,#0f172a)"],
    ["ivory-gold", "Ivory Gold", "linear-gradient(135deg,#d4a85b,#6f4a18)"],
    ["forest-ledger", "Forest", "linear-gradient(135deg,#1f7a55,#0f2f24)"],
    ["midnight-neon", "Midnight", "linear-gradient(135deg,#22c1ff,#111827)"]
  ];
  return `
    <div class="crm-theme-switcher" aria-label="Theme switcher">
      ${themes.map(([key, label, swatch]) => `
        <button class="crm-theme-chip" type="button" data-crm-theme="${key}">
          <span class="crm-theme-dot" style="background:${swatch}"></span>
          <span>${label}</span>
        </button>
      `).join("")}
    </div>
  `;
}

function crmMenuIcon(name){
  const icons = {
    dashboard: `<svg viewBox="0 0 24 24"><path d="M4 5h7v6H4z"/><path d="M13 5h7v10h-7z"/><path d="M4 13h7v6H4z"/><path d="M13 17h7v2h-7z"/></svg>`,
    clients: `<svg viewBox="0 0 24 24"><path d="M16 19a4 4 0 0 0-8 0"/><circle cx="12" cy="9" r="3"/><path d="M5 19a3 3 0 0 1 3-3"/><path d="M19 19a3 3 0 0 0-3-3"/></svg>`,
    quotes: `<svg viewBox="0 0 24 24"><path d="M7 4h10l3 3v13H7z"/><path d="M17 4v4h4"/><path d="M10 12h7"/><path d="M10 16h5"/></svg>`,
    contracts: `<svg viewBox="0 0 24 24"><path d="M8 3h8l4 4v14H8z"/><path d="M16 3v4h4"/><path d="M11 13h6"/><path d="M11 17h6"/><path d="M11 9h2"/></svg>`,
    form: `<svg viewBox="0 0 24 24"><path d="M4 6h10"/><path d="M4 12h16"/><path d="M4 18h9"/><path d="M18 17l2 2 3-4"/></svg>`,
    produse: `<svg viewBox="0 0 24 24"><path d="M4 7l8-4 8 4-8 4z"/><path d="M4 7v10l8 4 8-4V7"/><path d="M12 11v10"/></svg>`,
    facturi: `<svg viewBox="0 0 24 24"><path d="M7 3h10v18l-3-2-2 2-2-2-3 2z"/><path d="M9 8h6"/><path d="M9 12h6"/><path d="M9 16h4"/></svg>`,
    accounting: `<svg viewBox="0 0 24 24"><path d="M4 5h16v14H4z"/><path d="M8 9h8"/><path d="M8 13h5"/><path d="M15 13h1"/><path d="M8 17h8"/></svg>`,
    tipizate: `<svg viewBox="0 0 24 24"><path d="M6 4h9l3 3v13H6z"/><path d="M15 4v4h4"/><path d="M9 12h6"/><path d="M9 16h4"/></svg>`,
    employees: `<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3"/><path d="M4 19a5 5 0 0 1 10 0"/><path d="M16 8h4"/><path d="M18 6v4"/></svg>`,
    accounts: `<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3"/><path d="M5 20a7 7 0 0 1 14 0"/><path d="M19 8h1"/><path d="M18.5 5.5l.7.7"/><path d="M18.5 10.5l.7-.7"/></svg>`,
    setari: `<svg viewBox="0 0 24 24"><path d="M12 8.5A3.5 3.5 0 1 0 12 15.5A3.5 3.5 0 1 0 12 8.5z"/><path d="M19.4 15a1 1 0 0 0 .2 1.1l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1 1 0 0 0-1.1-.2 1 1 0 0 0-.6.9V20a2 2 0 1 1-4 0v-.2a1 1 0 0 0-.6-.9 1 1 0 0 0-1.1.2l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1 1 0 0 0 .2-1.1 1 1 0 0 0-.9-.6H4a2 2 0 1 1 0-4h.2a1 1 0 0 0 .9-.6 1 1 0 0 0-.2-1.1l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1 1 0 0 0 1.1.2 1 1 0 0 0 .6-.9V4a2 2 0 1 1 4 0v.2a1 1 0 0 0 .6.9 1 1 0 0 0 1.1-.2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1 1 0 0 0-.2 1.1 1 1 0 0 0 .9.6H20a2 2 0 1 1 0 4h-.2a1 1 0 0 0-.9.6z"/></svg>`,
    superadmin: `<svg viewBox="0 0 24 24"><path d="M3 10l9-6 9 6v10H3z"/><path d="M8 14h8"/><path d="M8 18h5"/><path d="M12 4v16"/></svg>`,
    anaf: `<svg viewBox="0 0 24 24"><path d="M4 5h16v14H4z"/><path d="M8 9h8"/><path d="M8 13h8"/><path d="M8 17h5"/></svg>`
  };
  return icons[name] || icons.dashboard;
}

function crmNavLinks(active, userModules=[], userEmail=""){
  function item(href, label, key, iconKey, extraStyle="", extraClass=""){
    const isActive = String(active||"") === String(key||"");
    const classes = [isActive ? "active" : "", extraClass].filter(Boolean).join(" ");
    return `<a href="${href}" class="${classes}" style="${extraStyle}" title="${label}"><span class="crm-nav-icon">${crmMenuIcon(iconKey)}</span><span>${label}</span></a>`;
  }
  function navGroup(title, subtitle, pill, itemsHtml){
    return `
      <section class="crm-nav-group">
        <div class="crm-nav-group-head">
          <div>
            <div class="crm-nav-group-title">${title}</div>
            <div class="crm-nav-group-sub">${subtitle}</div>
          </div>
          <div class="crm-nav-pill">${pill}</div>
        </div>
        <nav class="crm-nav">${itemsHtml}</nav>
      </section>
    `;
  }

  const activeKey = String(active || "");
  const contractsOpen = ["contracts","form"].includes(activeKey);
  const settingsOpen = ["setari","accounting-spv"].includes(activeKey);
  const accountingOpen = [
    "accounting",
    "accounting-home",
    "accounting-expenses",
    "accounting-declarations",
    "accounting-consumption",
    "accounting-receivables",
    "accounting-spv",
    "accounting-spv-inbox",
    "accounting-spv-outbox",
    "accounting-reconciliation"
  ].includes(activeKey);
  const isSuperAdmin = String(process.env.SUPER_ADMIN_EMAILS || process.env.ADMIN_EMAIL || "")
    .split(",")
    .map((value) => value.trim().toLowerCase())
    .filter(Boolean)
    .includes(String(userEmail || "").trim().toLowerCase());
  const moduleSet = new Set((userModules || []).map(String));
  const isAccountingWorkspace = moduleSet.has("accounting")
    && !moduleSet.has("clients")
    && !moduleSet.has("quotes")
    && !moduleSet.has("produse");

  if (isAccountingWorkspace) {
    const dashboardItems = [
      hasModuleAccess(userModules,"accounting") ? item("/accounting","Dashboard contabil","accounting-home","accounting") : ""
    ].join("");

    const accountingItems = [
      hasModuleAccess(userModules,"accounting") ? item("/accounting/declarations","Declarații ANAF","accounting-declarations","accounting") : "",
      hasModuleAccess(userModules,"accounting") ? item("/accounting/expenses","Cheltuieli","accounting-expenses","accounting") : "",
      hasModuleAccess(userModules,"accounting") ? item("/accounting/consumption","Bonuri de consum","accounting-consumption","accounting") : "",
      hasModuleAccess(userModules,"facturi") ? item("/facturi","Facturi emise","facturi","facturi") : "",
      hasModuleAccess(userModules,"facturi") ? item("/accounting/receivables","Facturi de urmărit","accounting-receivables","facturi") : "",
      hasModuleAccess(userModules,"accounting") ? item("/accounting#reconciliere","Reconciliere plăți","accounting-reconciliation","accounting") : "",
      hasModuleAccess(userModules,"accounting") ? `<div class="crm-nav-subnav-title">ANAF & SPV</div>` : "",
      hasModuleAccess(userModules,"accounting") ? `
        <div class="crm-nav-subnav">
          <a href="/anaf/status" class="${activeKey === "accounting-spv" ? "active" : ""}" title="Status ANAF"><span class="crm-nav-icon">${crmMenuIcon("anaf")}</span><span>Status conexiune</span></a>
          <a href="/anaf/inbox" class="${activeKey === "accounting-spv-inbox" ? "active" : ""}" title="Inbox e-Factura"><span class="crm-nav-icon">${crmMenuIcon("anaf")}</span><span>Inbox e-Factura</span></a>
          <a href="/anaf/outbox" class="${activeKey === "accounting-spv-outbox" ? "active" : ""}" title="Outbox e-Factura"><span class="crm-nav-icon">${crmMenuIcon("anaf")}</span><span>Outbox e-Factura</span></a>
        </div>
      ` : ""
    ].join("");

    return `
      <div class="crm-nav-section">Accounting</div>
      ${dashboardItems ? navGroup("Tablou contabil", "Dashboarduri doar pentru vizualizare și monitorizare.", "VIEW", dashboardItems) : ""}
      ${accountingItems ? navGroup("Zone de lucru", "Operațiuni zilnice pentru contabilitate, ANAF și registre interne.", "WORK", accountingItems) : ""}
    `;
  }

  const crmItems = [
    hasModuleAccess(userModules,"dashboard") ? item("/dashboard","Dashboard","dashboard","dashboard") : "",
    hasModuleAccess(userModules,"clients") ? item("/clients","Clienți","clients","clients") : "",
    hasModuleAccess(userModules,"quotes") ? item("/quotes","Oferte","quotes","quotes") : "",
    hasModuleAccess(userModules,"contracts") ? item("/contracte","Contracte","contracts","contracts") : "",
    contractsOpen ? `
      <div class="crm-nav-subnav">
        ${item("/","Form contract","form","form")}
      </div>
    ` : ""
  ].join("");

  const erpItems = [
    hasModuleAccess(userModules,"produse") ? item("/produse","Produse / Servicii","produse","produse") : "",
    hasModuleAccess(userModules,"facturi") ? item("/facturi","Facturi","facturi","facturi") : "",
    hasModuleAccess(userModules,"accounting") ? item("/accounting","Contabilitate","accounting","accounting") : "",
    hasModuleAccess(userModules,"tipizate") ? item("/tipizate","Tipizate","tipizate","tipizate") : "",
    hasModuleAccess(userModules,"employees") ? item("/employees","Angajați","employees","employees") : ""
  ].join("");

  const adminItems = [
    hasModuleAccess(userModules,"accounts") ? item("/accounts","Utilizatori","accounts","accounts") : "",
    hasModuleAccess(userModules,"setari") ? item("/setari","Setări","setari","setari") : "",
    isSuperAdmin ? item("/super-admin/companies","Companii","superadmin","superadmin") : "",
    isSuperAdmin ? item("/super-admin/payments","Plăți","superadmin-payments","facturi") : "",
    settingsOpen && hasModuleAccess(userModules,"setari") ? `
      <div class="crm-nav-subnav">
        <a href="/anaf/status" title="Status ANAF"><span class="crm-nav-icon">${crmMenuIcon("anaf")}</span><span>Status ANAF</span></a>
        <a href="/anaf/inbox" title="Inbox e-Factura"><span class="crm-nav-icon">${crmMenuIcon("anaf")}</span><span>Inbox e-Factura</span></a>
        <a href="/anaf/outbox" title="Outbox e-Factura"><span class="crm-nav-icon">${crmMenuIcon("anaf")}</span><span>Outbox e-Factura</span></a>
      </div>
    ` : ""
  ].join("");

  return `
    <div class="crm-nav-section">Workspace</div>
    ${crmItems ? navGroup("CRM", "Lead-uri, relații comerciale și documente de vânzare.", "CRM", crmItems) : ""}
    ${erpItems ? `<div class="crm-nav-section">Operations</div>${navGroup("ERP", "Catalog, facturare, tipizate și echipă internă.", "ERP", erpItems)}` : ""}
    ${adminItems ? `<div class="crm-nav-section">Control</div>${navGroup("Admin / Config", "Utilizatori, configurări și integrarea ANAF.", "ADMIN", adminItems)}` : ""}
  `;
}

function crmShellStart(active, title, subtitle="", userEmail="", userModules=[], companyStatus="", companyName=""){
  const isAccountingDashboardShell = String(active || "") === "accounting-home";
  const normalizedStatus = String(companyStatus || "").toLowerCase();
  const compactStatusLabel = normalizedStatus === "active"
    ? "Abonament activ"
    : normalizedStatus === "trial"
      ? "Cont în trial"
      : normalizedStatus === "past_due"
        ? "Plată restantă"
        : normalizedStatus
          ? normalizedStatus
          : "Fără status";
  const bannerConfig = normalizedStatus === "trial"
    ? {
        tone: "rgba(30,64,175,.18)",
        border: "rgba(96,165,250,.48)",
        title: "Cont în trial",
        message: `${companyName ? escapeHtml(companyName) : "Compania"} este în perioada de test. Verifică planul și activează abonamentul înainte de expirare.`
      }
    : normalizedStatus === "past_due"
      ? {
          tone: "rgba(146,64,14,.18)",
          border: "rgba(251,191,36,.48)",
          title: "Abonament restant",
          message: `${companyName ? escapeHtml(companyName) : "Compania"} are abonamentul în status past due. Verifică plata și evită suspendarea accesului.`
        }
      : normalizedStatus === "active"
        ? {
            tone: "rgba(22,101,52,.16)",
            border: "rgba(74,222,128,.42)",
            title: "Abonament activ",
            message: `${companyName ? escapeHtml(companyName) : "Compania"} are acces activ. Workspace-ul rulează normal și toate modulele aprobate sunt disponibile.`
          }
        : null;
  const statusBanner = bannerConfig && !isAccountingDashboardShell ? `
        <div style="margin:0 0 18px 0;padding:18px 20px;border-radius:20px;border:1px solid ${bannerConfig.border};background:${bannerConfig.tone};box-shadow:0 10px 30px rgba(15,23,42,.06)">
          <div style="font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin-bottom:8px">Subscription Status</div>
          <div style="font-size:20px;font-weight:800;margin-bottom:6px">${bannerConfig.title}</div>
          <div class="crm-muted" style="font-size:14px;line-height:1.6">${bannerConfig.message}</div>
        </div>
  ` : "";
  const sidebarMeta = isAccountingDashboardShell ? `
        <div class="crm-sidebar-meta">
          ${userEmail ? `<div class="crm-sidebar-meta-chip"><strong>Cont</strong><span>${escapeHtml(userEmail)}</span></div>` : ``}
          <div class="crm-sidebar-meta-chip"><strong>Status</strong><span>${escapeHtml(compactStatusLabel)}</span></div>
        </div>
  ` : "";
  return `
  ${uiShellStyles()}
  <body class="crm-body" data-shell="${escapeHtml(String(active || ""))}">
    <div class="crm-layout">
      <aside class="crm-sidebar">
        <div class="crm-brand">
          <div class="crm-brand-badge">Q</div>
          <div>
            <div class="crm-brand-title">QR-LAB MiniCRM</div>
            <div class="crm-brand-sub">Internal business workspace</div>
          </div>
        </div>
        ${crmNavLinks(active, userModules, userEmail)}
        <div class="crm-sidebar-footer">
          <div class="crm-sidebar-footer-title">Temă</div>
          ${crmThemeSwitcher()}
          ${sidebarMeta}
        </div>
      </aside>

      <main class="crm-main">
        <div class="crm-mobile-nav">
          ${crmNavLinks(active, userModules, userEmail)}
        </div>

        <div class="crm-topbar ${isAccountingDashboardShell ? "crm-topbar-compact" : ""}">
          ${isAccountingDashboardShell ? `` : `
          <div>
            <div class="crm-page-kicker">MiniCRM</div>
            <h1 class="crm-page-title">${escapeHtml(title || "Dashboard")}</h1>
            <div class="crm-page-subtitle">${escapeHtml(subtitle || "")}</div>
            ${userEmail ? `<div class="crm-user">Logat: ${escapeHtml(userEmail)}</div>` : ``}
          </div>
          `}
          <div class="crm-actions">
            <button class="crm-icon-btn" type="button" data-sidebar-toggle aria-label="Comută meniul lateral" title="Comută meniul lateral">
              <svg viewBox="0 0 24 24"><path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h16"/></svg>
            </button>
            <form method="post" action="/logout" style="margin:0">
              <button class="crm-btn crm-btn-secondary" type="submit">Logout</button>
            </form>
          </div>
        </div>

        <div class="crm-content">
          ${statusBanner}
  `;
}

function crmShellEnd(){
  return `
        </div>
      </main>
    </div>
    <script>
      (function(){
        const storageKey = "minicrm-theme";
        const sidebarKey = "minicrm-sidebar";
        const defaultTheme = "executive-slate";
        const body = document.body;
        const buttons = Array.from(document.querySelectorAll("[data-crm-theme]"));
        const sidebarToggle = document.querySelector("[data-sidebar-toggle]");

        function applyTheme(theme){
          const nextTheme = theme || defaultTheme;
          body.dataset.theme = nextTheme;
          buttons.forEach((button) => {
            button.classList.toggle("active", button.getAttribute("data-crm-theme") === nextTheme);
          });
        }

        const savedTheme = localStorage.getItem(storageKey) || defaultTheme;
        applyTheme(savedTheme);

        buttons.forEach((button) => {
          button.addEventListener("click", () => {
            const theme = button.getAttribute("data-crm-theme") || defaultTheme;
            localStorage.setItem(storageKey, theme);
            applyTheme(theme);
          });
        });

        function applySidebar(mode){
          body.dataset.sidebar = mode === "collapsed" ? "collapsed" : "expanded";
        }

        applySidebar(localStorage.getItem(sidebarKey) || "expanded");

        if(sidebarToggle){
          sidebarToggle.addEventListener("click", () => {
            const nextMode = body.dataset.sidebar === "collapsed" ? "expanded" : "collapsed";
            localStorage.setItem(sidebarKey, nextMode);
            applySidebar(nextMode);
          });
        }
      })();
    </script>
  </body>`;
}

function topMenu(active){
  return `
  <div style="margin:0 0 18px 0;padding:16px 18px;border:1px solid #e5e7eb;border-radius:18px;background:linear-gradient(180deg,#0f172a 0%,#111827 100%);box-shadow:0 10px 30px rgba(15,23,42,.10)">
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      ${[
        ["/dashboard","Dashboard","dashboard"],
        ["/clients","Clients","clients"],
        ["/quotes","Quotes","quotes"],
        ["/produse","Produse","produse"],
        ["/contracte","Contracte","contracts"],
        ["/facturi","Facturi","facturi"],
        ["/setari","Setări","setari"],
        ["/","Form contract","form"]
      ].map(([href,label,key])=>{
        const isActive = String(active||"") === String(key||"");
        const style = isActive
          ? "background:#2563eb;color:#fff;border:1px solid #3b82f6;box-shadow:0 8px 18px rgba(37,99,235,.35)"
          : "background:rgba(255,255,255,.04);color:#cbd5e1;border:1px solid rgba(255,255,255,.08)";
        return `<a href="${href}" style="text-decoration:none;padding:10px 14px;border-radius:12px;display:inline-flex;align-items:center;gap:6px;transition:all .15s ease;font-weight:700;${style}">${label}</a>`;
      }).join("")}
    </div>
  </div>`;
}


app.get("/produse", requireAuth, (req, res) => {
  const companyId = Number(req.session.user.company_id || 0);
  const rows = db.prepare(`
    SELECT id, code, name, unit, price, tva_percent, kind, active, created_at
    FROM products
    WHERE company_id=?
    ORDER BY active DESC, name COLLATE NOCASE ASC, id DESC
    LIMIT 500
  `).all(companyId);

  const htmlRows = rows.map(r => `
    <tr>
      <td>${escapeHtml(r.code || "") || `<span class="crm-muted">—</span>`}</td>
      <td>
        <div style="font-weight:800">${escapeHtml(r.name || "")}</div>
      </td>
      <td>${escapeHtml(r.kind || "")}</td>
      <td>${escapeHtml(r.unit || "") || `<span class="crm-muted">—</span>`}</td>
      <td class="crm-right">${escapeHtml(String(Number(r.price || 0).toFixed(2)))}</td>
      <td class="crm-right">${escapeHtml(String(r.tva_percent ?? 0))}%</td>
      <td>${Number(r.active) ? `<span class="crm-badge crm-badge-green">activ</span>` : `<span class="crm-badge crm-badge-neutral">inactiv</span>`}</td>
      <td>${escapeHtml(r.created_at || "") || `<span class="crm-muted">—</span>`}</td>
      <td>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <a href="/produse/${r.id}/edit" style="text-decoration:none">
            <button class="crm-btn crm-btn-secondary" type="button">Editează</button>
          </a>
          <form method="post" action="/produse/${r.id}/toggle" style="margin:0">
            <button class="crm-btn ${Number(r.active) ? "crm-btn-danger" : ""}" type="submit">${Number(r.active) ? "Dezactivează" : "Activează"}</button>
          </form>
        </div>
      </td>
    </tr>
  `).join("");

  res.type("html").send(`
<!doctype html>
<html>
<head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<meta charset="utf-8">
<title>Produse</title>
</head>
${crmShellStart("produse", "Produse / Servicii", "Catalog intern pentru linii de quote și factură.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

  <div class="crm-grid-2" style="overflow:visible" style="margin-bottom:18px">
    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <div style="margin-bottom:14px">
        <h3 style="margin:0;font-size:20px">Adaugă produs / serviciu</h3>
        <div class="crm-muted" style="margin-top:6px">Definește produse și servicii reutilizabile în documente.</div>
      </div>

      <form method="post" action="/produse/create" class="crm-stack">
        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Cod</label>
            <input class="crm-input" name="code" placeholder="ex: SVC-001">
          </div>
          <div>
            <label class="crm-label">Denumire</label>
            <input class="crm-input" name="name" required placeholder="ex: Mentenanță lunară">
          </div>
        </div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Tip</label>
            <select class="crm-select" name="kind">
              <option value="SERVICIU">SERVICIU</option>
              <option value="PRODUS">PRODUS</option>
            </select>
          </div>
          <div>
            <label class="crm-label">UM</label>
            <input class="crm-input" name="unit" value="buc" placeholder="buc / ora / abon">
          </div>
        </div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Preț</label>
            <input class="crm-input" name="price" value="0" placeholder="0.00">
          </div>
          <div>
            <label class="crm-label">TVA %</label>
            <input class="crm-input" name="tva_percent" value="19" placeholder="19">
          </div>
        </div>

        <div>
          <label class="crm-label">Activ</label>
          <select class="crm-select" name="active">
            <option value="1">DA</option>
            <option value="0">NU</option>
          </select>
        </div>

        <div>
          <button class="crm-btn" type="submit">Salvează produsul</button>
        </div>
      </form>
    </section>

    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <div style="margin-bottom:14px">
        <h3 style="margin:0;font-size:20px">Sumar</h3>
        <div class="crm-muted" style="margin-top:6px">Vedere rapidă a catalogului de produse.</div>
      </div>

      <div class="crm-kpis" style="grid-template-columns:repeat(2,minmax(0,1fr));gap:14px">
        <div class="crm-kpi">
          <div class="crm-kpi-label">Total produse</div>
          <div class="crm-kpi-value">${escapeHtml(String(rows.length))}</div>
        </div>
        <div class="crm-kpi">
          <div class="crm-kpi-label">Active</div>
          <div class="crm-kpi-value">${escapeHtml(String(rows.filter(x => Number(x.active)).length))}</div>
        </div>
      </div>
    </section>
  </div>

  <section class="crm-card" style="position:sticky;top:20px;z-index:10">
    <div style="margin-bottom:14px">
      <h3 style="margin:0;font-size:20px">Listă produse</h3>
      <div class="crm-muted" style="margin-top:6px">Ultimele 500 produse / servicii.</div>
    </div>

    <div class="crm-table-wrap">
      <table class="crm-table">
        <thead>
          <tr>
            <th>Cod</th>
            <th>Denumire</th>
            <th>Tip</th>
            <th>UM</th>
            <th class="crm-right">Preț</th>
            <th class="crm-right">TVA</th>
            <th>Activ</th>
            <th>Creat la</th>
            <th>Acțiuni</th>
          </tr>
        </thead>
        <tbody>
          ${htmlRows || '<tr><td colspan="9"><em>Nu există produse.</em></td></tr>'}
        </tbody>
      </table>
    </div>
  </section>

${crmShellEnd()}
</html>`);
});

app.post("/produse/:id/toggle", requireAuth, (req, res) => {
  const companyId = Number(req.session.user.company_id || 0);
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).send("Bad id");

  const row = db.prepare("SELECT id, active FROM products WHERE id=? AND company_id=?").get(id, companyId);
  if (!row) return res.status(404).send("Produs inexistent");

  const nextActive = Number(row.active) ? 0 : 1;
  db.prepare("UPDATE products SET active=? WHERE id=? AND company_id=?").run(nextActive, id, companyId);

  return res.redirect("/produse");
});


app.get("/produse/:id/edit", requireAuth, (req, res) => {
  const companyId = Number(req.session.user.company_id || 0);
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).send("Bad id");

  const row = db.prepare(`
    SELECT id, code, name, unit, price, tva_percent, kind, active, created_at
    FROM products
    WHERE id=? AND company_id=?
  `).get(id, companyId);

  if (!row) return res.status(404).send("Produs inexistent");

  res.type("html").send(`
<!doctype html>
<html>
<head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<meta charset="utf-8">
<title>Edit produs</title>
<style>
body{font-family:system-ui,Arial;margin:30px}
.card{border:1px solid #ddd;border-radius:10px;padding:14px;margin-bottom:16px;max-width:900px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(220px,1fr));gap:10px}
label{font-weight:600}
input,select{width:100%;padding:8px;box-sizing:border-box}
button{padding:8px 12px}
a{color:#0b57d0;text-decoration:none}
a:hover{text-decoration:underline}
@media (max-width: 640px){ .grid{grid-template-columns:1fr} }
</style>
</head>
<body>
  <h2 style="margin-top:0">Edit produs / serviciu</h2>
  ${topMenu("produse")}

  <div class="card">
    <form method="post" action="/produse/${row.id}/edit">
      <div class="grid">
        <div>
          <label>Cod</label>
          <input name="code" value="${escapeHtml(row.code || "")}">
        </div>
        <div>
          <label>Denumire</label>
          <input name="name" required value="${escapeHtml(row.name || "")}">
        </div>
        <div>
          <label>Tip</label>
          <select name="kind">
            <option value="SERVICIU" ${String(row.kind||"").toUpperCase()==="SERVICIU" ? "selected" : ""}>SERVICIU</option>
            <option value="PRODUS" ${String(row.kind||"").toUpperCase()==="PRODUS" ? "selected" : ""}>PRODUS</option>
          </select>
        </div>
        <div>
          <label>UM</label>
          <input name="unit" value="${escapeHtml(row.unit || "buc")}">
        </div>
        <div>
          <label>Preț</label>
          <input name="price" value="${escapeHtml(String(row.price ?? 0))}">
        </div>
        <div>
          <label>TVA %</label>
          <input name="tva_percent" value="${escapeHtml(String(row.tva_percent ?? 19))}">
        </div>
        <div>
          <label>Activ</label>
          <select name="active">
            <option value="1" ${Number(row.active) ? "selected" : ""}>DA</option>
            <option value="0" ${Number(row.active) ? "" : "selected"}>NU</option>
          </select>
        </div>
      </div>
      <div style="margin-top:12px;display:flex;gap:10px;flex-wrap:wrap">
        <button type="submit">Salvează modificările</button>
        <a href="/produse">Înapoi la produse</a>
      </div>
    </form>
  </div>
</body>
</html>`);
});

app.post("/produse/:id/edit", requireAuth, (req, res) => {
  const companyId = Number(req.session.user.company_id || 0);
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).send("Bad id");

  const row = db.prepare("SELECT id FROM products WHERE id=? AND company_id=?").get(id, companyId);
  if (!row) return res.status(404).send("Produs inexistent");

  const code = String(req.body?.code || "").trim();
  const name = String(req.body?.name || "").trim();
  const unit = String(req.body?.unit || "buc").trim() || "buc";
  const price = Number(String(req.body?.price || "0").replace(",", "."));
  const tva_percent = Number(String(req.body?.tva_percent || "19").replace(",", "."));
  const kindRaw = String(req.body?.kind || "SERVICIU").trim().toUpperCase();
  const active = String(req.body?.active || "1") === "1" ? 1 : 0;

  const allowedKinds = new Set(["SERVICIU","PRODUS"]);
  const kind = allowedKinds.has(kindRaw) ? kindRaw : "SERVICIU";

  if (!name) return res.status(400).send("Denumire required");
  if (!Number.isFinite(price) || price < 0) return res.status(400).send("Preț invalid");
  if (!Number.isFinite(tva_percent) || tva_percent < 0 || tva_percent > 100) return res.status(400).send("TVA invalid");

  db.prepare(`
    UPDATE products
    SET code=?, name=?, unit=?, price=?, tva_percent=?, kind=?, active=?
    WHERE id=? AND company_id=?
  `).run(code || null, name, unit, price, tva_percent, kind, active, id, companyId);

  return res.redirect("/produse");
});


app.post("/produse/create", requireAuth, (req, res) => {
  const companyId = Number(req.session.user.company_id || 0);
  const code = String(req.body?.code || "").trim();
  const name = String(req.body?.name || "").trim();
  const unit = String(req.body?.unit || "buc").trim() || "buc";
  const price = Number(String(req.body?.price || "0").replace(",", "."));
  const tva_percent = Number(String(req.body?.tva_percent || "19").replace(",", "."));
  const kindRaw = String(req.body?.kind || "SERVICIU").trim().toUpperCase();
  const active = String(req.body?.active || "1") === "1" ? 1 : 0;

  const allowedKinds = new Set(["SERVICIU","PRODUS"]);
  const kind = allowedKinds.has(kindRaw) ? kindRaw : "SERVICIU";

  if (!name) return res.status(400).send("Denumire required");
  if (!Number.isFinite(price) || price < 0) return res.status(400).send("Preț invalid");
  if (!Number.isFinite(tva_percent) || tva_percent < 0 || tva_percent > 100) return res.status(400).send("TVA invalid");

  db.prepare(`
    INSERT INTO products (code, name, unit, price, tva_percent, kind, active, company_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(code || null, name, unit, price, tva_percent, kind, active, companyId);

  return res.redirect("/produse");
});


function recalcFacturaTotals(factura_id){
  // subtotal = SUM(total_linie)
  const row = db.prepare("SELECT COALESCE(SUM(total_linie),0) AS subtotal FROM facturi_linii WHERE factura_id=?").get(factura_id);
  const f = db.prepare("SELECT tva_procent FROM facturi WHERE id=?").get(factura_id);

  const subtotal = Number(row?.subtotal ?? 0) || 0;
  const tva_procent = Number(f?.tva_procent ?? 0) || 0;
  const tva_valoare = Math.round(subtotal * tva_procent * 100) / 100;
  const total = Math.round((subtotal + tva_valoare) * 100) / 100;

  db.prepare("UPDATE facturi SET subtotal=?, tva_valoare=?, total=? WHERE id=?")
    .run(subtotal, tva_valoare, total, factura_id);

  return { subtotal, tva_procent, tva_valoare, total };
}



function getInvoiceTheme(){
  const theme = String(getSetting("invoice_color", "#39a935") || "#39a935").trim();

  function hexToLight(hex){
    const m = String(hex || "").trim().match(/^#?([0-9a-fA-F]{6})$/);
    if(!m) return "#d9f0d5";
    const raw = m[1];
    const r = parseInt(raw.slice(0,2), 16);
    const g = parseInt(raw.slice(2,4), 16);
    const b = parseInt(raw.slice(4,6), 16);

    const mix = (v) => Math.round(v + (255 - v) * 0.82);
    const rr = mix(r).toString(16).padStart(2,"0");
    const gg = mix(g).toString(16).padStart(2,"0");
    const bb = mix(b).toString(16).padStart(2,"0");
    return "#" + rr + gg + bb;
  }

  const light = hexToLight(theme);
  return { theme, light };
}

function getInvoiceLogoDataUri(){
  const p = path.join(__dirname, "public", "invoice-logo.png");
  try{
    if(!fs.existsSync(p)) return "";
    const buf = fs.readFileSync(p);
    const ext = (p.split(".").pop() || "").toLowerCase();
    const mime = ext==="jpg"||ext==="jpeg" ? "image/jpeg" : (ext==="webp" ? "image/webp" : "image/png");
    return "data:" + mime + ";base64," + buf.toString("base64");
  }catch(e){
    console.warn("Logo read failed:", String(e?.message ?? e));
    return "";
  }
}

app.get("/", requireAuth, (req, res) => {
  const uiStyleMatch = uiHtml.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
  const uiBodyMatch = uiHtml.match(/<body[^>]*>([\s\S]*?)<\/body>/i);

  const uiStyles = uiStyleMatch ? uiStyleMatch[1] : "";
  const uiBody = uiBodyMatch ? uiBodyMatch[1] : uiHtml;

  res.type("html").send(`
<!doctype html>
<html lang="ro">
<head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Form contract</title>
  <style>
    ${uiStyles}

    .crm-content body{background:transparent}
    .crm-content .card{
      background:#fff;
      border:1px solid #e5e7eb;
      border-radius:18px;
      padding:20px;
      box-shadow:0 2px 10px rgba(15,23,42,.05);
      margin:0;
    }
    .crm-content .card + .card{margin-top:16px}
    .crm-content .row{display:flex;gap:12px;flex-wrap:wrap}
    .crm-content label{
      display:block;
      font-size:13px;
      font-weight:700;
      color:#334155;
      margin:0 0 8px 0;
    }
    .crm-content input,
    .crm-content select,
    .crm-content textarea{
      width:100%;
      padding:11px 13px;
      border:1px solid #dbe2ea;
      border-radius:12px;
      background:#fff;
      color:#0f172a;
      outline:none;
      box-sizing:border-box;
    }
    .crm-content input:focus,
    .crm-content select:focus,
    .crm-content textarea:focus{
      border-color:#93c5fd;
      box-shadow:0 0 0 4px rgba(37,99,235,.12);
    }
    .crm-content textarea{min-height:120px}
    .crm-content .primary{
      background:#2563eb;
      color:#fff;
      border:none;
      padding:10px 14px;
      border-radius:12px;
      cursor:pointer;
      font-weight:700;
      box-shadow:0 8px 18px rgba(37,99,235,.18);
    }
    .crm-content .primary:hover{background:#1d4ed8}
    .crm-content .muted{color:#64748b;font-size:13px}
    .crm-content .hidden{display:none}
    .crm-content h2,
    .crm-content h3{color:#0f172a}
    .crm-form-wrap{max-width:1200px}
  </style>
</head>

${crmShellStart("form", "Form contract", "Generator contract PDF integrat în același workspace MiniCRM.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

  <div class="crm-form-wrap">
    ${uiBody}
  </div>

${crmShellEnd()}
</html>`);
});


app.post("/api/contract/pdf", requireAuth, async (req, res) => {
  try {
    const companyId = Number(req.session?.user?.company_id || 0);
    const body = req.body || {};

    const provider = {
      provider_legal_name: "QR-LAB SRL",
      provider_address: "Completează adresa prestatorului",
      provider_cui: "ROXXXXXXX",
      provider_reg_com: "Jxx/xxxx/xxxx",
      provider_iban: "ROxxBANKxxxxxxxxxxxxxx",
      provider_bank: "Banca",
      provider_representative_name: "Nume Reprezentant",
      provider_representative_role: "Administrator",
    };

    const is_company = body.is_company === "true" || body.is_company === true;
    const year = new Date().getFullYear();

    function normCui(cui) {
      return String(cui || "").toUpperCase().replace(/^RO/, "").replace(/\D/g, "");
    }
    function makePfKey(name, addr) {
      const raw = (String(name || "") + "|" + String(addr || "")).trim().toLowerCase();
      let h = 0;
      for (let k = 0; k < raw.length; k++) h = ((h << 5) - h + raw.charCodeAt(k)) | 0;
      return "PF-" + String(Math.abs(h));
    }

    let client_cui = "";
    let client_name = "";
    let client_addr = "";
    let client_reg = "";
    let client_caen = "";

    const pj_cui = normCui(body.pj_cui);
    const pj_name = String(body.pj_legal_name || "").trim();
    const pj_address = String(body.pj_address || "").trim();
    const pj_reg_com = String(body.pj_reg_com || "").trim();

    const pf_name = String(body.pf_full_name || "").trim();
    const pf_address = String(body.pf_address || "").trim();

    if (is_company) {
      client_cui = pj_cui;
      client_name = pj_name;
      client_addr = pj_address;
      client_reg = pj_reg_com;
      client_caen = String(body.caen || "").trim();
      if (!client_cui) return res.status(400).json({ error: "CUI lipsă/invalid" });
      if (!client_name) return res.status(400).json({ error: "Denumire firmă lipsă" });
    } else {
      client_cui = makePfKey(pf_name, pf_address);
      client_name = pf_name;
      client_addr = pf_address;
      client_reg = "";
      client_caen = "";
      if (!client_name) return res.status(400).json({ error: "Nume PF lipsă" });
    }

    const vat = body.vat ? 1 : 0;
    const inactive = body.inactive ? 1 : 0;

    const existingClient = db.prepare("SELECT id FROM clients WHERE cui=? AND company_id=?").get(client_cui, companyId);
    let client_id;
    if (existingClient?.id) {
      client_id = existingClient.id;
      db.prepare(`
        UPDATE clients
        SET name=?, address=?, reg_com=?, caen=?, vat=?, inactive=?
        WHERE id=? AND company_id=?
      `).run(client_name, client_addr, client_reg, client_caen, vat, inactive, client_id, companyId);
    } else {
      const r = db.prepare(`
        INSERT INTO clients (cui, name, address, reg_com, caen, vat, inactive, company_id)
        VALUES (?,?,?,?,?,?,?,?)
      `).run(client_cui, client_name, client_addr, client_reg, client_caen, vat, inactive, companyId);
      client_id = r.lastInsertRowid;
    }

    const row = db.prepare("SELECT MAX(seq) AS maxSeq FROM contracts WHERE year=? AND company_id=?").get(year, companyId);
    const nextSeq = (row?.maxSeq || 0) + 1;
    const contract_number = `QR-${year}-${String(nextSeq).padStart(4, "0")}`;

    const vm = {
      ...provider,
      contract_number,
      contract_date: body.contract_date || todayISO(),
      is_company,

      contact_email: body.contact_email || "",
      contact_phone: body.contact_phone || "",

      pj_cui: is_company ? (client_cui || "") : "",
      pj_legal_name: is_company ? (client_name || "") : "",
      pj_address: is_company ? (client_addr || "") : "",
      pj_reg_com: is_company ? (client_reg || "") : "",
      pj_representative_name: body.pj_representative_name || "",
      pj_representative_role: body.pj_representative_role || "Administrator",

      pf_full_name: !is_company ? (client_name || "") : "",
      pf_address: !is_company ? (client_addr || "") : "",

      service_description: body.service_description || "",
      price_amount: body.price_amount || "",
      price_currency: body.price_currency || "RON",
      payment_terms: body.payment_terms || "15 zile",
      start_date: body.start_date || todayISO(),
      duration: body.duration || "12 luni",
      termination_notice_days: body.termination_notice_days || "30",
      jurisdiction_city: body.jurisdiction_city || "București",
      privacy_policy_url: body.privacy_policy_url || "https://qr-lab.ro",

      client_signer_name: is_company ? (body.pj_representative_name || "") : (client_name || ""),
      provider_signer_name: provider.provider_representative_name,
    };

    const html = Mustache.render(templateHtml, { ...vm, company: COMPANY });
    const pdf = await renderPdfBuffer(html);

    const yearDir = path.join(__dirname, "contracts", String(year));
    fs.mkdirSync(yearDir, { recursive: true });
    const fileName = `${contract_number}.pdf`;
    const absPath = path.join(yearDir, fileName);
    fs.writeFileSync(absPath, pdf);
    const pdf_path = `contracts/${year}/${fileName}`;

    const priceNum = Number(String(body.price_amount || "").replace(",", "."));
    db.prepare(`
      INSERT INTO contracts (contract_number, year, seq, client_id, service_description, price, duration, pdf_path, company_id)
      VALUES (?,?,?,?,?,?,?,?,?)
    `).run(
      contract_number,
      year,
      nextSeq,
      client_id,
      String(body.service_description || ""),
      Number.isFinite(priceNum) ? priceNum : 0,
      String(body.duration || "12 luni"),
      pdf_path,
      companyId
    );

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
    res.send(pdf);
  } catch (e) {
    res.status(500).json({ error: "PDF/CRM error", details: String(e?.message ?? e) });
  }
});
app.listen(3000, "0.0.0.0", () => console.log("MiniCRM running on :3000"));




function buildFacturaXmlContent(id){
  const f = db.prepare(`
    SELECT f.*, c.name AS client_name, c.cui AS client_cui, c.address AS client_address
    FROM facturi f
    JOIN clients c ON c.id=f.client_id
    WHERE f.id=?
  `).get(id);

  if(!f) return { error: "Factura nu exista" };

  const lines = db.prepare(`
    SELECT denumire, cantitate, unitate, pret_unitar, total_linie
    FROM facturi_linii
    WHERE factura_id=?
    ORDER BY sort_order ASC, id ASC
  `).all(id);

  const totals = recalcFacturaTotals(id);

  const company_name = getSetting("company_name", COMPANY.name);
  const company_cui = getSetting("company_cui", COMPANY.cui);
  const company_address = getSetting("company_address", COMPANY.address);

  const esc = (v) => escapeHtml(String(v ?? ""));

  const linesXml = (lines||[]).map((l,i)=>`
  <cac:InvoiceLine>
    <cbc:ID>${i+1}</cbc:ID>
    <cbc:InvoicedQuantity>${Number(l.cantitate || 0)}</cbc:InvoicedQuantity>
    <cbc:LineExtensionAmount currencyID="RON">${Number(l.total_linie || 0).toFixed(2)}</cbc:LineExtensionAmount>
    <cac:Item>
      <cbc:Name>${esc(l.denumire)}</cbc:Name>
    </cac:Item>
    <cac:Price>
      <cbc:PriceAmount currencyID="RON">${Number(l.pret_unitar || 0).toFixed(2)}</cbc:PriceAmount>
    </cac:Price>
  </cac:InvoiceLine>`).join("\n");

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
 xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
 xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">

  <cbc:CustomizationID>urn:cen.eu:en16931:2017#compliant#urn:efactura.mfinante.ro:CIUS-RO:1.0.1</cbc:CustomizationID>
  <cbc:ProfileID>urn:fdc:peppol.eu:2017:poacc:billing:01:1.0</cbc:ProfileID>
  <cbc:ID>${esc(f.factura_nr)}</cbc:ID>
  <cbc:IssueDate>${String(f.data_emitere).slice(0,10)}</cbc:IssueDate>
  <cbc:DueDate>${f.scadenta ? String(f.scadenta).slice(0,10) : String(f.data_emitere).slice(0,10)}</cbc:DueDate>
  <cbc:InvoiceTypeCode>380</cbc:InvoiceTypeCode>
  <cbc:DocumentCurrencyCode>${esc(f.moneda || "RON")}</cbc:DocumentCurrencyCode>

  <cac:AccountingSupplierParty>
    <cac:Party>
      <cac:PartyName>
        <cbc:Name>${esc(company_name)}</cbc:Name>
      </cac:PartyName>
      <cac:PartyTaxScheme>
        <cbc:CompanyID>RO${esc(company_cui)}</cbc:CompanyID>
        <cac:TaxScheme>
          <cbc:ID>VAT</cbc:ID>
        </cac:TaxScheme>
      </cac:PartyTaxScheme>
      <cac:PostalAddress>
        <cbc:StreetName>${esc(company_address)}</cbc:StreetName>
        <cac:Country>
          <cbc:IdentificationCode>RO</cbc:IdentificationCode>
        </cac:Country>
      </cac:PostalAddress>
    </cac:Party>
  </cac:AccountingSupplierParty>

  <cac:AccountingCustomerParty>
    <cac:Party>
      <cac:PartyName>
        <cbc:Name>${esc(f.client_name)}</cbc:Name>
      </cac:PartyName>
      <cac:PartyTaxScheme>
        <cbc:CompanyID>RO${esc(f.client_cui)}</cbc:CompanyID>
        <cac:TaxScheme>
          <cbc:ID>VAT</cbc:ID>
        </cac:TaxScheme>
      </cac:PartyTaxScheme>
      <cac:PostalAddress>
        <cbc:StreetName>${esc(f.client_address || "")}</cbc:StreetName>
        <cac:Country>
          <cbc:IdentificationCode>RO</cbc:IdentificationCode>
        </cac:Country>
      </cac:PostalAddress>
    </cac:Party>
  </cac:AccountingCustomerParty>

  <cac:TaxTotal>
    <cbc:TaxAmount currencyID="${esc(f.moneda || "RON")}">${Number(totals.tva_valoare || 0).toFixed(2)}</cbc:TaxAmount>
    <cac:TaxSubtotal>
      <cbc:TaxableAmount currencyID="${esc(f.moneda || "RON")}">${Number(totals.subtotal || 0).toFixed(2)}</cbc:TaxableAmount>
      <cbc:TaxAmount currencyID="${esc(f.moneda || "RON")}">${Number(totals.tva_valoare || 0).toFixed(2)}</cbc:TaxAmount>
      <cac:TaxCategory>
        <cbc:ID>S</cbc:ID>
        <cbc:Percent>${Number((totals.tva_procent || 0) * 100).toFixed(2)}</cbc:Percent>
        <cac:TaxScheme>
          <cbc:ID>VAT</cbc:ID>
        </cac:TaxScheme>
      </cac:TaxCategory>
    </cac:TaxSubtotal>
  </cac:TaxTotal>

  <cac:LegalMonetaryTotal>
    <cbc:LineExtensionAmount currencyID="${esc(f.moneda || "RON")}">${Number(totals.subtotal || 0).toFixed(2)}</cbc:LineExtensionAmount>
    <cbc:TaxExclusiveAmount currencyID="${esc(f.moneda || "RON")}">${Number(totals.subtotal || 0).toFixed(2)}</cbc:TaxExclusiveAmount>
    <cbc:TaxInclusiveAmount currencyID="${esc(f.moneda || "RON")}">${Number(totals.total || 0).toFixed(2)}</cbc:TaxInclusiveAmount>
    <cbc:PayableAmount currencyID="${esc(f.moneda || "RON")}">${Number(totals.total || 0).toFixed(2)}</cbc:PayableAmount>
  </cac:LegalMonetaryTotal>

  ${linesXml}

</Invoice>`;

  return { f, lines, totals, xml };
}

function ensureFacturaXmlGenerated(id){
  const built = buildFacturaXmlContent(id);
  if(built.error) return built;

  const xmlDir = path.join(__dirname, "efactura_xml");
  fs.mkdirSync(xmlDir, { recursive:true });

  const xmlFile = `${built.f.factura_nr}.xml`;
  const absPath = path.join(xmlDir, xmlFile);
  fs.writeFileSync(absPath, built.xml);

  db.prepare(`
    UPDATE facturi
    SET efactura_xml_path=?,
        efactura_status=CASE
          WHEN efactura_status='PREGATIT_PENTRU_TRIMITERE' THEN efactura_status
          ELSE 'GENERAT'
        END
    WHERE id=?
  `).run(`efactura_xml/${xmlFile}`, id);

  return {
    ok: true,
    xmlFile,
    absPath,
    xmlPath: `efactura_xml/${xmlFile}`,
    xml: built.xml,
    f: built.f
  };
}

/* ================================
   SETTINGS MODULE
================================ */

import multer from "multer";
const upload = multer({ dest: "uploads/" });

registerAccountingRoutes(app, { db, requireAuth, escapeHtml, fmtMoney, crmShellStart, crmShellEnd, fs, path, __dirname, upload });

db.prepare(`
CREATE TABLE IF NOT EXISTS app_settings(
key TEXT PRIMARY KEY,
value TEXT
)`).run();

db.prepare(`
CREATE TABLE IF NOT EXISTS tipizate_docs(
id INTEGER PRIMARY KEY AUTOINCREMENT,
title TEXT NOT NULL,
category TEXT,
file_name TEXT NOT NULL,
file_path TEXT NOT NULL,
mime_type TEXT,
created_at TEXT DEFAULT CURRENT_TIMESTAMP
)`).run();

function getSetting(k, def=""){
  const r = db.prepare("SELECT value FROM app_settings WHERE key=?").get(k);
  return r ? r.value : def;
}

function setSetting(k,v){
  db.prepare("INSERT OR REPLACE INTO app_settings(key,value) VALUES(?,?)").run(k,String(v||""));
}

function parseJsonArray(value, fallback = []) {
  try {
    const parsed = JSON.parse(value || "[]");
    return Array.isArray(parsed) ? parsed.map(String) : [...fallback];
  } catch {
    return [...fallback];
  }
}

function getCompanySubscriptionContext(companyId) {
  const company = db.prepare(`
    SELECT id, name, cui, rc, address, bank, iban, representative, status, max_users
    FROM companies
    WHERE id=?
  `).get(companyId) || null;

  const subscription = db.prepare(`
    SELECT
      cs.id,
      cs.company_id,
      cs.plan_id,
      cs.status,
      cs.seats_included,
      cs.seats_used,
      cs.module_overrides,
      cs.stripe_subscription_id,
      cs.stripe_checkout_session_id,
      cs.stripe_price_id,
      cs.billing_currency,
      cs.billing_email,
      cs.current_period_end,
      cs.last_payment_status,
      p.code AS plan_code,
      p.name AS plan_name,
      p.price_monthly,
      p.max_users AS plan_max_users,
      p.module_keys AS plan_module_keys
    FROM company_subscriptions cs
    JOIN plans p ON p.id = cs.plan_id
    WHERE cs.company_id=?
    ORDER BY cs.id DESC
    LIMIT 1
  `).get(companyId) || null;

  const plans = db.prepare(`
    SELECT id, code, name, billing_period, price_monthly, max_users, module_keys
    FROM plans
    WHERE status='active'
    ORDER BY price_monthly ASC, id ASC
  `).all();

  const planModules = parseJsonArray(subscription?.plan_module_keys, MODULE_DEFINITIONS.map((item) => item.key));
  const moduleOverrides = parseJsonArray(subscription?.module_overrides, planModules);
  const activeModules = moduleOverrides.length ? moduleOverrides : planModules;

  return { company, subscription, plans, planModules, moduleOverrides, activeModules };
}

function refreshSessionCompanyAccess(req) {
  const companyId = Number(req.session?.user?.company_id || 0);
  const userId = Number(req.session?.user?.id || 0);
  if (!companyId || !userId) return;

  const userRow = db.prepare(`
    SELECT role, module_permissions, is_company_admin
    FROM users
    WHERE id=? AND company_id=?
  `).get(userId, companyId);
  if (!userRow) return;

  const { company, subscription, activeModules } = getCompanySubscriptionContext(companyId);
  const assignedModules = parseJsonArray(userRow.module_permissions, []);
  const effectiveModules = Number(req.session?.user?.is_super_admin || 0)
    ? MODULE_DEFINITIONS.map((item) => item.key)
    : assignedModules.length
    ? assignedModules.filter((key) => activeModules.includes(key))
    : activeModules;

  req.session.user.company_name = company?.name || req.session.user.company_name || null;
  req.session.user.is_company_admin = Number(userRow.is_company_admin || 0);
  req.session.user.module_permissions = effectiveModules;
  req.session.user.effective_module_permissions = effectiveModules;
  req.session.user.subscription = subscription ? {
    id: subscription.id,
    plan_code: subscription.plan_code,
    plan_name: subscription.plan_name,
    seats_included: subscription.seats_included,
    seats_used: subscription.seats_used
  } : null;
}

function logCompanyAdminEvent({ companyId, actorUserId, actorEmail, eventType, statusFrom = "", statusTo = "", reason = "" }) {
  if (!companyId || !eventType) return;
  db.prepare(`
    INSERT INTO company_admin_events (company_id, actor_user_id, actor_email, event_type, status_from, status_to, reason)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    companyId,
    actorUserId || null,
    String(actorEmail || ""),
    String(eventType || ""),
    String(statusFrom || ""),
    String(statusTo || ""),
    String(reason || "").trim()
  );
}

function companyStatusBadge(status) {
  const value = String(status || "").toLowerCase();
  if (value === "active") return `<span class="crm-badge crm-badge-green">active</span>`;
  if (value === "trial") return `<span class="crm-badge crm-badge-blue">trial</span>`;
  if (value === "past_due") return `<span class="crm-badge crm-badge-amber">past due</span>`;
  if (value === "suspended") return `<span class="crm-badge crm-badge-red">suspended</span>`;
  return `<span class="crm-badge crm-badge-neutral">${escapeHtml(status || "—")}</span>`;
}

function paymentSourceBadge(source) {
  const value = String(source || "").toLowerCase();
  if (value === "stripe") return `<span class="crm-badge crm-badge-blue">Stripe</span>`;
  if (value === "op") return `<span class="crm-badge crm-badge-amber">OP</span>`;
  return `<span class="crm-badge crm-badge-neutral">${escapeHtml(source || "—")}</span>`;
}

function paymentStatusBadge(status) {
  const value = String(status || "").toLowerCase();
  if (value === "paid") return `<span class="crm-badge crm-badge-green">reușită</span>`;
  if (value === "failed") return `<span class="crm-badge crm-badge-red">eșuată</span>`;
  if (value === "processing") return `<span class="crm-badge crm-badge-blue">în procesare</span>`;
  if (value === "pending_verification") return `<span class="crm-badge crm-badge-amber">așteaptă verificare</span>`;
  if (value === "initiated") return `<span class="crm-badge crm-badge-neutral">inițiată</span>`;
  return `<span class="crm-badge crm-badge-neutral">${escapeHtml(status || "—")}</span>`;
}

function syncManualPaymentToSubscription(companyId, paymentStatus) {
  const normalizedStatus = String(paymentStatus || "").trim().toLowerCase();
  if (!companyId || !normalizedStatus) return;

  const currentSubscription = db.prepare(`
    SELECT id
    FROM company_subscriptions
    WHERE company_id=?
    ORDER BY id DESC
    LIMIT 1
  `).get(companyId);

  if (!currentSubscription) return;

  if (normalizedStatus === "paid") {
    db.prepare(`
      UPDATE company_subscriptions
      SET status='active',
          last_payment_status='manual_paid',
          updated_at=datetime('now')
      WHERE id=?
    `).run(currentSubscription.id);

    db.prepare(`
      UPDATE companies
      SET status='active',
          updated_at=datetime('now')
      WHERE id=?
    `).run(companyId);
    return;
  }

  if (normalizedStatus === "failed") {
    db.prepare(`
      UPDATE company_subscriptions
      SET status='past_due',
          last_payment_status='manual_failed',
          updated_at=datetime('now')
      WHERE id=?
    `).run(currentSubscription.id);

    db.prepare(`
      UPDATE companies
      SET status='past_due',
          updated_at=datetime('now')
      WHERE id=?
    `).run(companyId);
    return;
  }

  if (normalizedStatus === "pending_verification") {
    db.prepare(`
      UPDATE company_subscriptions
      SET last_payment_status='manual_pending_verification',
          updated_at=datetime('now')
      WHERE id=?
    `).run(currentSubscription.id);
  }
}


app.get("/tipizate", requireAuth, (req, res) => {
  const companyId = Number(req.session.user.company_id || 0);
  const docs = db.prepare(`
    SELECT id, title, category, file_name, file_path, mime_type, created_at
    FROM tipizate_docs
    WHERE company_id=?
    ORDER BY id DESC
    LIMIT 300
  `).all(companyId);

  let employees = [];
  const hasEmployeesTable = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='employees'").get();
  if (hasEmployeesTable) {
    employees = db.prepare(`
      SELECT id, name, email, phone, position
      FROM employees
      WHERE active=1 AND company_id=?
      ORDER BY name COLLATE NOCASE ASC
    `).all(companyId);
  }

  const employeeOptions = employees.map(e => `<option value="${e.id}">${escapeHtml(e.name || "")}${e.position ? ` — ${escapeHtml(e.position)}` : ""}</option>`).join("");

  const htmlRows = docs.map(d => `
    <tr>
      <td>
        <div style="font-weight:800">${escapeHtml(d.title || "")}</div>
      </td>
      <td>${escapeHtml(d.category || "") || `<span class="crm-muted">—</span>`}</td>
      <td>${escapeHtml(d.file_name || "")}</td>
      <td>${escapeHtml(d.created_at || "")}</td>
      <td>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <a href="/${encodeURI(d.file_path)}" target="_blank">Deschide</a>
          <form method="post" action="/tipizate/${d.id}/delete" style="margin:0" onsubmit="return confirm('Ștergi documentul?');">
            <button class="crm-btn crm-btn-danger" type="submit">Șterge</button>
          </form>
        </div>
      </td>
    </tr>
  `).join("");

  res.type("html").send(`
<!doctype html>
<html>
<head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<meta charset="utf-8">
<title>Tipizate</title>
</head>
${crmShellStart("tipizate", "Tipizate", "Template-uri interne și documente PDF încărcate.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

  <div class="crm-grid-2" style="overflow:visible" style="margin-bottom:18px">
    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <div style="margin-bottom:14px">
        <h3 style="margin:0;font-size:20px">Modele generate</h3>
        <div class="crm-muted" style="margin-top:6px">Documente generate direct din aplicație.</div>
      </div>

      <div class="crm-stack">

        <a href="/tipizate/proces-verbal" style="text-decoration:none">
          <div class="crm-card">
            <div style="font-weight:800">Proces verbal</div>
            <div class="crm-muted" style="margin-top:6px">Deschide formularul editabil pentru proces verbal.</div>
          </div>
        </a>

        <a href="/tipizate/adeverinta" style="text-decoration:none">
          <div class="crm-card">
            <div style="font-weight:800">Adeverință salariat</div>
            <div class="crm-muted" style="margin-top:6px">Deschide formularul editabil pentru adeverință.</div>
          </div>
        </a>

        <a href="/tipizate/decizie-interna" style="text-decoration:none">
          <div class="crm-card">
            <div style="font-weight:800">Decizie internă</div>
            <div class="crm-muted" style="margin-top:6px">Deschide formularul editabil pentru decizie internă.</div>
          </div>
        </a>

        <a href="/tipizate/notificare-client" style="text-decoration:none">
          <div class="crm-card">
            <div style="font-weight:800">Notificare client</div>
            <div class="crm-muted" style="margin-top:6px">Deschide formularul editabil pentru notificare client.</div>
          </div>
        </a>

        <a href="/tipizate/cerere-concediu" style="text-decoration:none">
          <div class="crm-card">
            <div style="font-weight:800">Cerere concediu</div>
            <div class="crm-muted" style="margin-top:6px">Deschide formularul editabil pentru cerere concediu.</div>
          </div>
        </a>

        <a href="/tipizate/ordin-deplasare" style="text-decoration:none">
          <div class="crm-card">
            <div style="font-weight:800">Ordin de deplasare</div>
            <div class="crm-muted" style="margin-top:6px">Deschide formularul editabil pentru ordin de deplasare.</div>
          </div>
        </a>

        <a href="/tipizate/fisa-hr" style="text-decoration:none">
          <div class="crm-card">
            <div style="font-weight:800">Fișă HR</div>
            <div class="crm-muted" style="margin-top:6px">Deschide formularul editabil pentru fișă HR.</div>
          </div>
        </a>

      </div>
    </section>

    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <div style="margin-bottom:14px">
        <h3 style="margin:0;font-size:20px">Încarcă PDF</h3>
        <div class="crm-muted" style="margin-top:6px">Adaugă manual documente PDF în biblioteca de tipizate.</div>
      </div>

      <form method="post" action="/tipizate/upload" enctype="multipart/form-data" class="crm-stack">
        <div>
          <label class="crm-label">Titlu document</label>
          <input class="crm-input" name="title" required placeholder="Ex: Proces verbal recepție">
        </div>

        <div>
          <label class="crm-label">Categorie</label>
          <select class="crm-select" name="category">
            <option value="PROCES_VERBAL">PROCES_VERBAL</option>
            <option value="ADEVERINTA">ADEVERINTA</option>
            <option value="DECIZIE_INTERNA">DECIZIE_INTERNA</option>
            <option value="NOTIFICARE_CLIENT">NOTIFICARE_CLIENT</option>
            <option value="CERERE_CONCEDIU">CERERE_CONCEDIU</option>
            <option value="FISE_HR">FISE_HR</option>
            <option value="CONTRACT">CONTRACT</option>
            <option value="HR">HR</option>
            <option value="ALTELE">ALTELE</option>
          </select>
        </div>

        <div>
          <label class="crm-label">Fișier PDF</label>
          <input class="crm-input" type="file" name="pdf" accept="application/pdf,.pdf" required>
        </div>

        <div>
          <button class="crm-btn" type="submit">Upload PDF</button>
        </div>
      </form>
    </section>
  </div>

  <section class="crm-card" style="position:sticky;top:20px;z-index:10">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;margin-bottom:14px">
      <div>
        <h3 style="margin:0;font-size:20px">PDF-uri încărcate</h3>
        <div class="crm-muted" style="margin-top:6px">Biblioteca documentelor tipizate încărcate manual sau generate.</div>
      </div>
      <div class="crm-badge crm-badge-blue">${escapeHtml(String(docs.length))} documente</div>
    </div>

    <div class="crm-table-wrap">
      <table class="crm-table">
        <thead>
          <tr>
            <th>Titlu</th>
            <th>Categorie</th>
            <th>Fișier</th>
            <th>Creat</th>
            <th>Acțiune</th>
          </tr>
        </thead>
        <tbody>${htmlRows || `<tr><td colspan="5"><em>Nu există documente încărcate.</em></td></tr>`}</tbody>
      </table>
    </div>
  </section>

${crmShellEnd()}
</html>`);
});

app.get("/tipizate/proces-verbal", requireAuth, (req, res) => {
  res.type("html").send(`
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Proces verbal</title>
</head>

${crmShellStart("tipizate", "Proces verbal", "Completează formularul și generează PDF.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

<div class="crm-card" style="max-width:900px">

  <form method="post" action="/tipizate/proces-verbal/generate" class="crm-stack">

    <div>
      <label class="crm-label">Titlu document</label>
      <input class="crm-input" name="title" required placeholder="Ex: Proces verbal recepție lucrări">
    </div>

    <div class="crm-grid-2">
      <div>
        <label class="crm-label">Data</label>
        <input class="crm-input" type="date" name="doc_date" value="${todayISO()}">
      </div>
      <div>
        <label class="crm-label">Locația</label>
        <input class="crm-input" name="location">
      </div>
    </div>

    <div>
      <label class="crm-label">Participanți</label>
      <input class="crm-input" name="participants">
    </div>

    <div>
      <label class="crm-label">Subiect</label>
      <input class="crm-input" name="subject">
    </div>

    <div>
      <label class="crm-label">Conținut</label>
      <textarea class="crm-textarea" name="content" rows="8" required></textarea>
    </div>

    <div>
      <label class="crm-label">Întocmit de</label>
      <input class="crm-input" name="prepared_by">
    </div>

    <div>
      

    </div>

    <div>
      <button class="crm-btn" type="submit">Generează PDF</button>
    </div>

  </form>
</div>

${crmShellEnd()}
</html>
`);
});


app.get("/tipizate/decizie-interna", requireAuth, (req, res) => {
  res.type("html").send(`
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Decizie internă</title>
</head>

${crmShellStart("tipizate", "Decizie internă", "Completează formularul și generează PDF.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

<div class="crm-card" style="max-width:900px">
  <form method="post" action="/tipizate/decizie-interna/generate" class="crm-stack">

    <div>
      <label class="crm-label">Titlu document</label>
      <input class="crm-input" name="title" required placeholder="Ex: Decizie internă nr. 1">
    </div>

    <div class="crm-grid-2">
      <div>
        <label class="crm-label">Data</label>
        <input class="crm-input" type="date" name="doc_date" value="${todayISO()}">
      </div>
      <div>
        <label class="crm-label">Emitent</label>
        <input class="crm-input" name="issuer" placeholder="Ex: Administrator">
      </div>
    </div>

    <div>
      <label class="crm-label">Subiect</label>
      <input class="crm-input" name="subject" required>
    </div>

    <div>
      <label class="crm-label">Conținut</label>
      <textarea class="crm-textarea" name="content" rows="7" required></textarea>
    </div>

    <div>
      <button class="crm-btn" type="submit">Generează PDF</button>
    </div>

  </form>
</div>

${crmShellEnd()}
</html>
`);
});

app.get("/tipizate/notificare-client", requireAuth, (req, res) => {
  res.type("html").send(`
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Notificare client</title>
</head>

${crmShellStart("tipizate", "Notificare client", "Completează formularul și generează PDF.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

<div class="crm-card" style="max-width:900px">
  <form method="post" action="/tipizate/notificare-client/generate" class="crm-stack">

    <div>
      <label class="crm-label">Titlu document</label>
      <input class="crm-input" name="title" required placeholder="Ex: Notificare client">
    </div>

    <div class="crm-grid-2">
      <div>
        <label class="crm-label">Client</label>
        <input class="crm-input" name="client_name" required>
      </div>
      <div>
        <label class="crm-label">Data</label>
        <input class="crm-input" type="date" name="doc_date" value="${todayISO()}">
      </div>
    </div>

    <div>
      <label class="crm-label">Subiect</label>
      <input class="crm-input" name="subject" required>
    </div>

    <div>
      <label class="crm-label">Mesaj</label>
      <textarea class="crm-textarea" name="content" rows="7" required></textarea>
    </div>

    <div>
      <label class="crm-label">Semnat de</label>
      <input class="crm-input" name="prepared_by" placeholder="Ex: QR-LAB SRL">
    </div>

    <div>
      <button class="crm-btn" type="submit">Generează PDF</button>
    </div>

  </form>
</div>

${crmShellEnd()}
</html>
`);
});

app.get("/tipizate/cerere-concediu", requireAuth, (req, res) => {
  res.type("html").send(`
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Cerere concediu</title>
</head>

${crmShellStart("tipizate", "Cerere concediu", "Completează formularul și generează PDF.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

<div class="crm-card" style="max-width:900px">
  <form method="post" action="/tipizate/cerere-concediu/generate" class="crm-stack">

    <div>
      <label class="crm-label">Nume salariat</label>
      <input class="crm-input" name="employee_name" required>
    </div>

    <div class="crm-grid-2">
      <div>
        <label class="crm-label">Perioada</label>
        <input class="crm-input" name="period" required placeholder="Ex: 10.03.2026 - 15.03.2026">
      </div>
      <div>
        <label class="crm-label">Tip concediu</label>
        <input class="crm-input" name="leave_type" required placeholder="Ex: odihnă">
      </div>
    </div>

    <div>
      <label class="crm-label">Motiv / observații</label>
      <textarea class="crm-textarea" name="content" rows="5"></textarea>
    </div>

    <div>
      <label class="crm-label">Data cererii</label>
      <input class="crm-input" type="date" name="doc_date" value="${todayISO()}">
    </div>

    <div>
      <button class="crm-btn" type="submit">Generează PDF</button>
    </div>

  </form>
</div>

${crmShellEnd()}
</html>
`);
});



app.get("/tipizate/ordin-deplasare", requireAuth, (req, res) => {
  res.type("html").send(`
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Ordin de deplasare</title>
</head>

${crmShellStart("tipizate", "Ordin de deplasare", "Completează formularul în formatul tipizatului și generează PDF.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

<div class="crm-card" style="max-width:1400px">
  <form method="post" action="/tipizate/ordin-deplasare/generate" class="crm-stack">

    <div class="crm-grid-2" style="overflow:visible">
      <div>
        <label class="crm-label">Titlu document</label>
        <input class="crm-input" name="title" required value="Ordin de deplasare">
      </div>
      <div>
        <label class="crm-label">Data</label>
        <input class="crm-input" type="date" name="doc_date" value="${todayISO()}">
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;align-items:start">

      <div class="crm-card" style="margin:0">
        <div class="crm-label" style="font-size:16px;font-weight:800;margin-bottom:10px">Partea stângă — Decont cheltuieli</div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Unitatea / compartimentul</label>
            <input class="crm-input" name="department" placeholder="Ex: Service">
          </div>
          <div>
            <label class="crm-label">Număr ordin</label>
            <input class="crm-input" name="order_number" placeholder="Ex: 15">
          </div>
        </div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Ziua plecării</label>
            <input class="crm-input" type="date" name="departure_date">
          </div>
          <div>
            <label class="crm-label">Ora plecării</label>
            <input class="crm-input" name="departure_time" placeholder="Ex: 08:00">
          </div>
        </div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Ziua sosirii</label>
            <input class="crm-input" type="date" name="return_date">
          </div>
          <div>
            <label class="crm-label">Ora sosirii</label>
            <input class="crm-input" name="return_time" placeholder="Ex: 18:30">
          </div>
        </div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Avans spre decontare</label>
            <input class="crm-input" name="advance_amount" placeholder="Ex: 500">
          </div>
          <div>
            <label class="crm-label">Observații</label>
            <input class="crm-input" name="expenses_notes" placeholder="Ex: cazare, transport, diurnă">
          </div>
        </div>

        <div style="margin-top:12px">
          <label class="crm-label">Cheltuieli</label>
          <table style="width:100%;border-collapse:collapse">
            <tr style="background:#f5f5f5">
              <th style="border:1px solid #ccc;padding:6px;width:50%">Felul actului și emitent</th>
              <th style="border:1px solid #ccc;padding:6px;width:28%">Nr. și data actului</th>
              <th style="border:1px solid #ccc;padding:6px;width:22%">Sumă</th>
            </tr>

            <tr>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[0][type]" placeholder="Ex: Factură / Bon fiscal / Diurnă"></td>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[0][doc]" placeholder="Ex: 23/24.03.2026"></td>
              <td style="border:1px solid #ccc"><input class="crm-input amount-field" name="expense_rows[0][amount]" placeholder="Ex: 458.50"></td>
            </tr>
            <tr>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[1][type]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[1][doc]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input amount-field" name="expense_rows[1][amount]"></td>
            </tr>
            <tr>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[2][type]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[2][doc]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input amount-field" name="expense_rows[2][amount]"></td>
            </tr>
            <tr>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[3][type]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[3][doc]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input amount-field" name="expense_rows[3][amount]"></td>
            </tr>
            <tr>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[4][type]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[4][doc]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input amount-field" name="expense_rows[4][amount]"></td>
            </tr>
            <tr>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[5][type]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[5][doc]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input amount-field" name="expense_rows[5][amount]"></td>
            </tr>
            <tr>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[6][type]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[6][doc]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input amount-field" name="expense_rows[6][amount]"></td>
            </tr>
            <tr>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[7][type]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[7][doc]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input amount-field" name="expense_rows[7][amount]"></td>
            </tr>
            <tr>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[8][type]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[8][doc]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input amount-field" name="expense_rows[8][amount]"></td>
            </tr>
            <tr>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[9][type]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input" name="expense_rows[9][doc]"></td>
              <td style="border:1px solid #ccc"><input class="crm-input amount-field" name="expense_rows[9][amount]"></td>
            </tr>
          </table>

          <div style="margin-top:10px;text-align:right">
            <b>Total cheltuieli: <span id="total_expenses">0.00</span> lei</b>
          </div>
        </div>

        <div class="crm-grid-2" style="overflow:visible;margin-top:12px">
          <div>
            <label class="crm-label">Diferență de restituit</label>
            <input class="crm-input" name="difference_returned" placeholder="Ex: 0">
          </div>
          <div>
            <label class="crm-label">Diferență de primit</label>
            <input class="crm-input" name="difference_received" placeholder="Ex: 0">
          </div>
        </div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Aprobat de</label>
            <input class="crm-input" name="approved_by" placeholder="Ex: Administrator">
          </div>
          <div>
            <label class="crm-label">Semnătura delegatului</label>
            <input class="crm-input" name="employee_sign" placeholder="Ex: Popescu Ion">
          </div>
        </div>
      </div>

      <div class="crm-card" style="margin:0">
        <div class="crm-label" style="font-size:16px;font-weight:800;margin-bottom:10px">Partea dreaptă — Ordin de deplasare</div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Angajat / delegat</label>
            <input class="crm-input" name="employee_name" required placeholder="Ex: Popescu Ion">
          </div>
          <div>
            <label class="crm-label">Funcție</label>
            <input class="crm-input" name="position" placeholder="Ex: Tehnician">
          </div>
        </div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Localitatea delegării</label>
            <input class="crm-input" name="destination" required placeholder="Ex: Cluj-Napoca">
          </div>
          <div>
            <label class="crm-label">Scopul deplasării</label>
            <input class="crm-input" name="purpose" placeholder="Ex: Intervenție tehnică / întâlnire client">
          </div>
        </div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Mijloc transport</label>
            <input class="crm-input" name="transport" placeholder="Ex: auto propriu / tren / avion">
          </div>
          <div>
            <label class="crm-label">Seria CI</label>
            <input class="crm-input" name="ci_series" placeholder="Ex: RX 123456">
          </div>
        </div>

        <div style="margin-top:14px">
          <div class="crm-label" style="font-size:15px;font-weight:800;margin-bottom:10px">Sosit / Plecat / Cu-fără cazare</div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div class="crm-card" style="margin:0">
              <label class="crm-label">Sosit 1</label>
              <input class="crm-input" name="stamp_1_in">
              <label class="crm-label">Plecat 1</label>
              <input class="crm-input" name="stamp_1_out">
              <label class="crm-label">Cu / fără cazare 1</label>
              <input class="crm-input" name="stamp_1_cazare" placeholder="Ex: cu cazare">
            </div>
            <div class="crm-card" style="margin:0">
              <label class="crm-label">Sosit 2</label>
              <input class="crm-input" name="stamp_2_in">
              <label class="crm-label">Plecat 2</label>
              <input class="crm-input" name="stamp_2_out">
              <label class="crm-label">Cu / fără cazare 2</label>
              <input class="crm-input" name="stamp_2_cazare" placeholder="Ex: fără cazare">
            </div>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px">
            <div class="crm-card" style="margin:0">
              <label class="crm-label">Sosit 3</label>
              <input class="crm-input" name="stamp_3_in">
              <label class="crm-label">Plecat 3</label>
              <input class="crm-input" name="stamp_3_out">
              <label class="crm-label">Cu / fără cazare 3</label>
              <input class="crm-input" name="stamp_3_cazare">
            </div>
            <div class="crm-card" style="margin:0">
              <label class="crm-label">Sosit 4</label>
              <input class="crm-input" name="stamp_4_in">
              <label class="crm-label">Plecat 4</label>
              <input class="crm-input" name="stamp_4_out">
              <label class="crm-label">Cu / fără cazare 4</label>
              <input class="crm-input" name="stamp_4_cazare">
            </div>
          </div>
        </div>
      </div>

    </div>

    <div>
      <button class="crm-btn" type="submit">Generează PDF</button>
    </div>

  </form>
</div>

<script>
(function(){
  function calcTotal(){
    let total = 0;
    document.querySelectorAll(".amount-field").forEach(function(i){
      const val = parseFloat((i.value || "").replace(",", "."));
      if(!isNaN(val)) total += val;
    });
    const target = document.getElementById("total_expenses");
    if(target) target.textContent = total.toFixed(2);
  }
  document.addEventListener("input", function(e){
    if(e.target && e.target.classList.contains("amount-field")) calcTotal();
  });
  calcTotal();
})();
</script>

${crmShellEnd()}
</html>
`);
});

app.get("/tipizate/fisa-hr", requireAuth, (req, res) => {
  res.type("html").send(`
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Fișă HR</title>
</head>

${crmShellStart("tipizate", "Fișă HR", "Completează formularul și generează PDF.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

<div class="crm-card" style="max-width:900px">
  <form method="post" action="/tipizate/fisa-hr/generate" class="crm-stack">

    <div>
      <label class="crm-label">Nume salariat</label>
      <input class="crm-input" name="employee_name" required>
    </div>

    <div class="crm-grid-2" style="overflow:visible">
      <div>
        <label class="crm-label">Funcție</label>
        <input class="crm-input" name="position" required>
      </div>
      <div>
        <label class="crm-label">Departament</label>
        <input class="crm-input" name="department">
      </div>
    </div>

    <div>
      <label class="crm-label">Data angajării</label>
      <input class="crm-input" type="date" name="hire_date">
    </div>

    <div>
      <label class="crm-label">Observații</label>
      <textarea class="crm-textarea" name="content" rows="6"></textarea>
    </div>

    <div>
      <button class="crm-btn" type="submit">Generează PDF</button>
    </div>

  </form>
</div>

${crmShellEnd()}
</html>
`);
});

app.post("/tipizate/proces-verbal/generate", requireAuth, async (req, res) => {
  try {
    const companyId = Number(req.session.user.company_id || 0);
    const title = String(req.body?.title || "").trim();
    const doc_date = String(req.body?.doc_date || "").trim() || todayISO();
    const location = String(req.body?.location || "").trim();
    const participants = String(req.body?.participants || "").trim();
    const subject = String(req.body?.subject || "").trim();
    const content = String(req.body?.content || "").trim();
    const prepared_by = String(req.body?.prepared_by || "").trim();

    if (!title) return res.status(400).send("Titlul este obligatoriu.");
    if (!content) return res.status(400).send("Conținutul este obligatoriu.");

    const esc = (v) => escapeHtml(String(v || ""));
    
    let total = 0;
    if (Array.isArray(expense_rows)) {
      expense_rows.forEach(r => {
        const val = parseFloat(r.amount || 0);
        if (!isNaN(val)) total += val;
      });
    }
const html = `
<!doctype html>
<html>
<head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<meta charset="utf-8">
<style>
  body{font-family:Arial,sans-serif;color:#111;line-height:1.45;margin:32px}
  h1{font-size:24px;margin:0 0 16px 0}
  .meta{margin-bottom:20px;padding:14px;border:1px solid #ddd;border-radius:10px;background:#fafafa}
  .meta div{margin:4px 0}
  .content{white-space:pre-wrap;border:1px solid #ddd;border-radius:10px;padding:16px;min-height:280px}
  .sign{margin-top:32px;display:flex;justify-content:space-between;gap:24px}
  .sign-box{width:45%}
  .line{margin-top:48px;border-top:1px solid #222;padding-top:8px}
</style>
</head>
<body>
  <h1>${esc(title)}</h1>

  <div class="meta">
    <div><b>Data:</b> ${esc(doc_date)}</div>
    <div><b>Locația:</b> ${esc(location)}</div>
    <div><b>Părți / participanți:</b> ${esc(participants)}</div>
    <div><b>Subiect:</b> ${esc(subject)}</div>
  </div>

  <div class="content">${esc(content)}</div>

  <div class="sign">
    <div class="sign-box">
      <div><b>Întocmit de</b></div>
      <div class="line">${esc(prepared_by || "-")}</div>
    </div>
    <div class="sign-box">
      <div><b>Semnătură / Confirmare</b></div>
      <div class="line">&nbsp;</div>
    </div>
  </div>
</body>
</html>`;

    const pdf = await renderPdfBuffer(html);

    const dir = path.join(__dirname, "public", "uploads", "tipizate");
    fs.mkdirSync(dir, { recursive: true });










    const safeBase = title
      .replace(/[^a-zA-Z0-9._-]+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "") || "proces-verbal";

    const finalName = `${Date.now()}-${safeBase}.pdf`;
    const absPath = path.join(dir, finalName);
    fs.writeFileSync(absPath, pdf);

    const file_path = `uploads/tipizate/${finalName}`;

    db.prepare(`
      INSERT INTO tipizate_docs (title, category, file_name, file_path, mime_type, company_id)
      VALUES (?,?,?,?,?,?)
    `).run(
      title,
      "PROCES_VERBAL",
      finalName,
      file_path,
      "application/pdf",
      companyId
    );

    return res.redirect("/" + encodeURI(file_path));
  } catch (e) {
    return res.status(500).send("Proces verbal failed: " + String(e?.message || e));
  }
});

app.post("/tipizate/adeverinta/generate", requireAuth, async (req, res) => {
  try {
    const companyId = Number(req.session.user.company_id || 0);
    const title = String(req.body?.title || "").trim() || "Adeverință salariat";
    const employee_name = String(req.body?.employee_name || "").trim();
    const position = String(req.body?.position || "").trim();
    const employee_id = String(req.body?.employee_id || "").trim();
    const doc_date = String(req.body?.doc_date || "").trim() || todayISO();
    const content = String(req.body?.content || "").trim();
    const prepared_by = String(req.body?.prepared_by || "").trim();

    if (!employee_name) return res.status(400).send("Numele salariatului este obligatoriu.");
    if (!position) return res.status(400).send("Funcția este obligatorie.");

    const esc = (v) => escapeHtml(String(v || ""));
    const html = `
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
  @page { size: A4 landscape; margin: 8mm; }
  body{
    margin:0;
    font-family: Arial, Helvetica, sans-serif;
    color:#000;
    font-size:10px;
    line-height:1.15;
  }
  .page{
    width:100%;
    box-sizing:border-box;
    padding:2mm 1mm;
  }
  .wrap{
    display:grid;
    grid-template-columns: 1fr 1fr;
    gap:18mm;
    align-items:start;
  }
  .col{
    min-height:180mm;
    position:relative;
  }
  .col.right{
    border-left:1px solid #000;
    padding-left:12mm;
  }
  .small{
    font-size:9px;
  }
  .topline{
    display:flex;
    justify-content:space-between;
    align-items:flex-end;
    margin-bottom:8mm;
    min-height:18px;
  }
  .mutedline{
    border-bottom:1px dotted #666;
    min-width:110px;
    display:inline-block;
    padding:0 3px 1px 3px;
    vertical-align:bottom;
  }
  .title{
    text-align:center;
    font-size:18px;
    font-weight:700;
    margin:10mm 0 8mm 0;
  }
  .row{
    margin:2.5mm 0;
  }
  .line{
    display:inline-block;
    border-bottom:1px dotted #666;
    min-width:120px;
    padding:0 3px 1px 3px;
    vertical-align:bottom;
  }
  .line.sm{ min-width:70px; }
  .line.md{ min-width:120px; }
  .line.lg{ min-width:200px; }
  .line.xl{ min-width:280px; }
  .tight{ margin-top:1mm; }
  table{
    width:100%;
    border-collapse:collapse;
    table-layout:fixed;
  }
  th, td{
    border:1px solid #000;
    padding:3px 4px;
    vertical-align:top;
    word-wrap:break-word;
  }
  th{
    font-weight:700;
    text-align:center;
  }
  .no-border td, .no-border th{
    border:none;
    padding:0;
  }
  .expenses-meta{
    margin-bottom:4mm;
  }
  .expenses-meta table td{
    border:1px solid #000;
    padding:2px 4px;
    font-size:9px;
  }
  .expenses-table{
    margin-top:2mm;
    font-size:9px;
  }
  .expenses-table td{
    height:16px;
  }
  .total-row td{
    font-weight:700;
  }
  .footer-table{
    margin-top:2mm;
    font-size:8px;
  }
  .footer-table td{
    height:26px;
    vertical-align:top;
  }
  .sign-col{
    text-align:center;
    margin-top:7mm;
  }
  .sign-line{
    border-top:1px solid #000;
    margin-top:9mm;
    padding-top:2mm;
  }
  .stamp{
    text-align:center;
    margin-top:4mm;
  }
  .mini-boxes{
    margin-top:5mm;
  }
  .mini-boxes td{
    height:34px;
    font-size:8px;
  }
  .bottom-note{
    margin-top:4mm;
    font-size:8px;
  }
</style>
</head>
<body>
<div class="page">
  <div class="wrap">

    <div class="col left">
      <div class="topline small">
        <div>
          <span class="mutedline">${esc(department || "")}</span><br>
          <span style="margin-left:18px">(unitatea)</span>
        </div>
        <div>
          Depus decontul (numărul și data)<br>
          <span class="mutedline" style="min-width:150px">&nbsp;</span>
        </div>
      </div>

      <div class="expenses-meta">
        <table>
          <tr>
            <td style="width:48%">
              Ziua și ora plecării <span class="line sm">${esc(departure_date || "")} ${esc(departure_time || "")}</span><br>
              Ziua și ora sosirii <span class="line sm">${esc(return_date || "")} ${esc(return_time || "")}</span><br>
              Data depunerii decontului <span class="line sm">&nbsp;</span><br>
              Penalizări calculate <span class="line sm">&nbsp;</span>
            </td>
            <td>
              Avans spre decontare <span class="line sm">${esc(advance_amount || "")}</span><br>
              Primit la plecare <span class="line sm">&nbsp;</span> lei<br>
              Primit în timpul deplasării <span class="line sm">&nbsp;</span> lei<br>
              TOTAL <span class="line sm">${esc(advance_amount || "")}</span> lei
            </td>
          </tr>
        </table>
      </div>

      <table class="expenses-table">
        <tr>
          <th style="width:48%">Felul actului și emitentul</th>
          <th style="width:27%">Nr. și data actului</th>
          <th style="width:25%">Suma</th>
        </tr>
        ${(() => {
          const rows = Array.isArray(expense_rows) ? expense_rows : [];
          let out = "";
          for (let i = 0; i < 14; i++) {
            const r = rows[i] || {};
            const left = esc(r.type || "");
            const mid = esc(r.doc || ((r.date || "") ? String(r.date) : ""));
            const amt = esc(r.amount || "");
            out += `<tr><td>${left}</td><td>${mid}</td><td>${amt}</td></tr>`;
          }
          return out;
        })()}
        <tr class="total-row">
          <td colspan="2" style="text-align:center">TOTAL CHELTUIELI</td>
          <td>${Array.isArray(expense_rows) ? expense_rows.reduce((sum, r) => sum + (parseFloat(r.amount || 0) || 0), 0).toFixed(2) : "0.00"}</td>
        </tr>
      </table>

      <table class="footer-table">
        <tr>
          <td style="width:34%">
            Diferență de restituit - s-a depus<br>
            cu chitanța nr. <span class="line sm">&nbsp;</span> din <span class="line sm">&nbsp;</span>
          </td>
          <td style="width:28%">
            Diferență de primit<br>
            <span class="line sm">&nbsp;</span> lei
          </td>
          <td style="width:12%; text-align:center; writing-mode:vertical-rl; transform:rotate(180deg);">Semnătura</td>
          <td style="width:26%">&nbsp;</td>
        </tr>
      </table>

      <table class="footer-table">
        <tr>
          <td style="text-align:center">Control aprobat,<br>conducătorul unității</td>
          <td style="text-align:center">Control financiar preventiv</td>
          <td style="text-align:center">Verificat<br>decont</td>
          <td style="text-align:center">Șef<br>compartiment</td>
          <td style="text-align:center">Titular<br>avans</td>
        </tr>
        <tr>
          <td style="height:26px"></td>
          <td></td>
          <td></td>
          <td></td>
          <td>${esc(employee_sign || employee_name || "")}</td>
        </tr>
      </table>
    </div>

    <div class="col right">
      <div class="topline small">
        <div>
          <span class="mutedline">${esc(department || "")}</span><br>
          <span style="margin-left:18px">(unitatea)</span>
        </div>
        <div>&nbsp;</div>
      </div>

      <div class="title">Ordin de deplasare (delegație) nr. <span class="line sm">${esc(order_number || "")}</span></div>

      <div class="row">
        Domnul <span class="line xl">${esc(employee_name || "")}</span>
      </div>
      <div class="row">
        având funcția de <span class="line lg">${esc(position || "")}</span>
      </div>
      <div class="row">
        este delegat pentru <span class="line xl">${esc(purpose || "")}</span>
      </div>
      <div class="row">
        <span class="line xl">&nbsp;</span>
      </div>
      <div class="row">
        la <span class="line xl">${esc(destination || "")}</span>
      </div>
      <div class="row">
        <span class="line xl">&nbsp;</span>
      </div>

      <div class="row" style="margin-top:6mm">
        Durata deplasării de la <span class="line md">${esc(departure_date || "")}</span>
        la <span class="line md">${esc(return_date || "")}</span>
      </div>
      <div class="row">
        se legitimează cu <span class="line xl">${esc(transport || "")}</span>
      </div>

      <div class="stamp">Ștampila unității și semnătura</div>

      <div class="row" style="margin-top:4mm">
        Data <span class="line md">${esc(doc_date || "")}</span>
      </div>

      <table class="mini-boxes">
        <tr>
          <td>
            Sosit* <span class="line sm">&nbsp;</span><br>
            Plecat* <span class="line sm">&nbsp;</span><br>
            Cu / fără cazare <span class="line sm">&nbsp;</span>
          </td>
          <td>
            Sosit* <span class="line sm">&nbsp;</span><br>
            Plecat* <span class="line sm">&nbsp;</span><br>
            Cu / fără cazare <span class="line sm">&nbsp;</span>
          </td>
        </tr>
        <tr>
          <td style="text-align:center; vertical-align:bottom">
            Ștampila unității<br>și semnătura
          </td>
          <td style="text-align:center; vertical-align:bottom">
            Ștampila unității<br>și semnătura
          </td>
        </tr>
        <tr>
          <td>
            Sosit* <span class="line sm">&nbsp;</span><br>
            Plecat* <span class="line sm">&nbsp;</span><br>
            Cu / fără cazare <span class="line sm">&nbsp;</span>
          </td>
          <td>
            Sosit* <span class="line sm">&nbsp;</span><br>
            Plecat* <span class="line sm">&nbsp;</span><br>
            Cu / fără cazare <span class="line sm">&nbsp;</span>
          </td>
        </tr>
        <tr>
          <td style="text-align:center; vertical-align:bottom">
            Ștampila unității<br>și semnătura
          </td>
          <td style="text-align:center; vertical-align:bottom">
            Ștampila unității<br>și semnătura
          </td>
        </tr>
      </table>

      <div class="bottom-note">*) Se va completa ziua, luna, anul și ora</div>
    </div>

  </div>
</div>
</body>
</html>`;

    const pdf = await renderPdfBuffer(html);
    const dir = path.join(__dirname, "public", "uploads", "tipizate");
    fs.mkdirSync(dir, { recursive: true });

    const finalName = `${Date.now()}-adeverinta-salariat.pdf`;
    fs.writeFileSync(path.join(dir, finalName), pdf);
    const file_path = `uploads/tipizate/${finalName}`;

    db.prepare(`
      INSERT INTO tipizate_docs (title, category, file_name, file_path, mime_type, company_id)
      VALUES (?,?,?,?,?,?)
    `).run(title, "ADEVERINTA", finalName, file_path, "application/pdf", companyId);

    return res.redirect("/" + encodeURI(file_path));
  } catch (e) {
    return res.status(500).send("Adeverinta failed: " + String(e?.message || e));
  }
});

app.post("/tipizate/decizie-interna/generate", requireAuth, async (req, res) => {
  try {
    const companyId = Number(req.session.user.company_id || 0);
    const title = String(req.body?.title || "").trim();
    const doc_date = String(req.body?.doc_date || "").trim() || todayISO();
    const issuer = String(req.body?.issuer || "").trim();
    const subject = String(req.body?.subject || "").trim();
    const content = String(req.body?.content || "").trim();

    if (!title) return res.status(400).send("Titlul este obligatoriu.");
    if (!subject) return res.status(400).send("Subiectul este obligatoriu.");
    if (!content) return res.status(400).send("Conținutul este obligatoriu.");

    const esc = (v) => escapeHtml(String(v || ""));
    const html = `
<!doctype html>
<html><head><meta charset="utf-8">
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<style>
body{font-family:Arial,sans-serif;color:#111;line-height:1.5;margin:36px}
h1{text-align:center;margin-bottom:16px}
.meta{margin-bottom:20px}
.content{white-space:pre-wrap;border:1px solid #ddd;padding:16px;border-radius:10px}
.line{margin-top:60px;border-top:1px solid #222;padding-top:8px;width:280px}
</style>
</head><body>
  <h1>${esc(title)}</h1>
  <div class="meta"><b>Data:</b> ${esc(doc_date)}<br><b>Emitent:</b> ${esc(issuer)}</div>
  <p><b>Subiect:</b> ${esc(subject)}</p>
  <div class="content">${esc(content)}</div>
  <div class="line">${esc(issuer || "-")}</div>
</body></html>`;

    const pdf = await renderPdfBuffer(html);
    const dir = path.join(__dirname, "public", "uploads", "tipizate");
    fs.mkdirSync(dir, { recursive: true });

    const finalName = `${Date.now()}-decizie-interna.pdf`;
    fs.writeFileSync(path.join(dir, finalName), pdf);
    const file_path = `uploads/tipizate/${finalName}`;

    db.prepare(`
      INSERT INTO tipizate_docs (title, category, file_name, file_path, mime_type, company_id)
      VALUES (?,?,?,?,?,?)
    `).run(title, "DECIZIE_INTERNA", finalName, file_path, "application/pdf", companyId);

    return res.redirect("/" + encodeURI(file_path));
  } catch (e) {
    return res.status(500).send("Decizie interna failed: " + String(e?.message || e));
  }
});

app.post("/tipizate/notificare-client/generate", requireAuth, async (req, res) => {
  try {
    const companyId = Number(req.session.user.company_id || 0);
    const title = String(req.body?.title || "").trim();
    const client_name = String(req.body?.client_name || "").trim();
    const doc_date = String(req.body?.doc_date || "").trim() || todayISO();
    const subject = String(req.body?.subject || "").trim();
    const content = String(req.body?.content || "").trim();
    const prepared_by = String(req.body?.prepared_by || "").trim();

    if (!title) return res.status(400).send("Titlul este obligatoriu.");
    if (!client_name) return res.status(400).send("Clientul este obligatoriu.");
    if (!subject) return res.status(400).send("Subiectul este obligatoriu.");
    if (!content) return res.status(400).send("Mesajul este obligatoriu.");

    const esc = (v) => escapeHtml(String(v || ""));
    const html = `
<!doctype html>
<html><head><meta charset="utf-8">
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<style>
body{font-family:Arial,sans-serif;color:#111;line-height:1.5;margin:36px}
h1{margin-bottom:20px}
.content{white-space:pre-wrap;border:1px solid #ddd;padding:16px;border-radius:10px}
.line{margin-top:60px;border-top:1px solid #222;padding-top:8px;width:280px}
</style>
</head><body>
  <h1>${esc(title)}</h1>
  <p><b>Către:</b> ${esc(client_name)}</p>
  <p><b>Data:</b> ${esc(doc_date)}</p>
  <p><b>Subiect:</b> ${esc(subject)}</p>
  <div class="content">${esc(content)}</div>
  <div class="line">${esc(prepared_by || "-")}</div>
</body></html>`;

    const pdf = await renderPdfBuffer(html);
    const dir = path.join(__dirname, "public", "uploads", "tipizate");
    fs.mkdirSync(dir, { recursive: true });

    const finalName = `${Date.now()}-notificare-client.pdf`;
    fs.writeFileSync(path.join(dir, finalName), pdf);
    const file_path = `uploads/tipizate/${finalName}`;

    db.prepare(`
      INSERT INTO tipizate_docs (title, category, file_name, file_path, mime_type, company_id)
      VALUES (?,?,?,?,?,?)
    `).run(title, "NOTIFICARE_CLIENT", finalName, file_path, "application/pdf", companyId);

    return res.redirect("/" + encodeURI(file_path));
  } catch (e) {
    return res.status(500).send("Notificare client failed: " + String(e?.message || e));
  }
});

app.post("/tipizate/cerere-concediu/generate", requireAuth, async (req, res) => {
  try {
    const companyId = Number(req.session.user.company_id || 0);
    const employee_name = String(req.body?.employee_name || "").trim();
    const period = String(req.body?.period || "").trim();
    const leave_type = String(req.body?.leave_type || "").trim();
    const content = String(req.body?.content || "").trim();
    const doc_date = String(req.body?.doc_date || "").trim() || todayISO();

    if (!employee_name) return res.status(400).send("Numele salariatului este obligatoriu.");
    if (!period) return res.status(400).send("Perioada este obligatorie.");
    if (!leave_type) return res.status(400).send("Tipul concediului este obligatoriu.");

    const title = `Cerere concediu - ${employee_name}`;
    const esc = (v) => escapeHtml(String(v || ""));
    const html = `
<!doctype html>
<html><head><meta charset="utf-8">
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<style>
body{font-family:Arial,sans-serif;color:#111;line-height:1.5;margin:36px}
h1{text-align:center;margin-bottom:20px}
.content{white-space:pre-wrap}
.line{margin-top:60px;border-top:1px solid #222;padding-top:8px;width:280px}
</style>
</head><body>
  <h1>${esc(title)}</h1>
  <p>Subsemnatul(a) <b>${esc(employee_name)}</b> solicit acordarea unui concediu de tip <b>${esc(leave_type)}</b>, pentru perioada <b>${esc(period)}</b>.</p>
  <div class="content">${esc(content || "")}</div>
  <p>Data cererii: ${esc(doc_date)}</p>
  <div class="line">${esc(employee_name)}</div>
</body></html>`;

    const pdf = await renderPdfBuffer(html);
    const dir = path.join(__dirname, "public", "uploads", "tipizate");
    fs.mkdirSync(dir, { recursive: true });

    const finalName = `${Date.now()}-cerere-concediu.pdf`;
    fs.writeFileSync(path.join(dir, finalName), pdf);
    const file_path = `uploads/tipizate/${finalName}`;

    db.prepare(`
      INSERT INTO tipizate_docs (title, category, file_name, file_path, mime_type, company_id)
      VALUES (?,?,?,?,?,?)
    `).run(title, "CERERE_CONCEDIU", finalName, file_path, "application/pdf", companyId);

    return res.redirect("/" + encodeURI(file_path));
  } catch (e) {
    return res.status(500).send("Cerere concediu failed: " + String(e?.message || e));
  }
});

app.post("/tipizate/ordin-deplasare/generate", requireAuth, async (req, res) => {
  try {
    const companyId = Number(req.session.user.company_id || 0);
    const title = String(req.body?.title || "").trim() || "ORDIN DE DEPLASARE";
    const doc_date = String(req.body?.doc_date || "").trim() || todayISO();
    const order_number = String(req.body?.order_number || "").trim();
    const employee_name = String(req.body?.employee_name || "").trim();
    const position = String(req.body?.position || "").trim();
    const department = String(req.body?.department || "").trim();
    const destination = String(req.body?.destination || "").trim();
    const purpose = String(req.body?.purpose || "").trim();
    const departure_date = String(req.body?.departure_date || "").trim();
    const return_date = String(req.body?.return_date || "").trim();
    const departure_time = String(req.body?.departure_time || "").trim();
    const return_time = String(req.body?.return_time || "").trim();
    const ci_series = String(req.body?.ci_series || "").trim();
    const transport = String(req.body?.transport || "").trim();
    const advance_amount = String(req.body?.advance_amount || "").trim();
    const expenses_notes = String(req.body?.expenses_notes || "").trim();
    const expense_rows = req.body?.expense_rows || [];
    const approved_by = String(req.body?.approved_by || "").trim();
    const advance_num = parseFloat(String(advance_amount || "0").replace(",", ".")) || 0;
    const total_num = Array.isArray(expense_rows)
      ? expense_rows.reduce((sum, r) => sum + (parseFloat(String(r?.amount || "0").replace(",", ".")) || 0), 0)
      : 0;
    const difference_returned = advance_num > total_num ? (advance_num - total_num).toFixed(2) : "";
    const difference_received = total_num > advance_num ? (total_num - advance_num).toFixed(2) : "";
    const employee_sign = String(req.body?.employee_sign || "").trim();
    const stamp_1_in = String(req.body?.stamp_1_in || "").trim();
    const stamp_1_out = String(req.body?.stamp_1_out || "").trim();
    const stamp_1_cazare = String(req.body?.stamp_1_cazare || "").trim();
    const stamp_2_in = String(req.body?.stamp_2_in || "").trim();
    const stamp_2_out = String(req.body?.stamp_2_out || "").trim();
    const stamp_2_cazare = String(req.body?.stamp_2_cazare || "").trim();
    const stamp_3_in = String(req.body?.stamp_3_in || "").trim();
    const stamp_3_out = String(req.body?.stamp_3_out || "").trim();
    const stamp_3_cazare = String(req.body?.stamp_3_cazare || "").trim();
    const stamp_4_in = String(req.body?.stamp_4_in || "").trim();
    const stamp_4_out = String(req.body?.stamp_4_out || "").trim();
    const stamp_4_cazare = String(req.body?.stamp_4_cazare || "").trim();

    if (!employee_name) return res.status(400).send("Numele delegatului este obligatoriu.");
    if (!destination) return res.status(400).send("Localitatea delegării este obligatorie.");

    const esc = (v) => escapeHtml(String(v || ""));
    const line = (v, n = 24) => esc(v || "_".repeat(n));

    const html = `
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
  @page { size: A4 landscape; margin: 8mm; }
  body{
    margin:0;
    font-family: Arial, Helvetica, sans-serif;
    color:#000;
    font-size:10px;
    line-height:1.15;
  }
  .page{ width:100%; box-sizing:border-box; }
  .wrap{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:14mm;
    align-items:start;
  }
  .col{
    min-height:180mm;
    position:relative;
  }
  .col.right{
    border-left:1px solid #000;
    padding-left:10mm;
  }
  .top{
    display:flex;
    justify-content:space-between;
    align-items:flex-end;
    margin-bottom:5mm;
    font-size:9px;
  }
  .unit{
    min-width:140px;
  }
  .fill{
    display:inline-block;
    border-bottom:1px dotted #666;
    min-width:80px;
    padding:0 6px 1px 6px; text-align:center;
    vertical-align:bottom;
  }
  .fill.sm{ min-width:55px; }
  .fill.md{ min-width:110px; }
  .fill.lg{ min-width:180px; }
  .fill.xl{ min-width:250px; }
  .title{
    text-align:center;
    font-size:17px;
    font-weight:700;
    margin:8mm 0 6mm 0;
  }
  .row{ margin:2.5mm 0; }
  table{
    width:100%;
    border-collapse:collapse;
    table-layout:fixed;
  }
  th, td{
    border:1px solid #000;
    padding:3px 4px;
    vertical-align:top;
    word-wrap:break-word;
  }
  th{
    text-align:center;
    font-weight:700;
  }
  .t9{ font-size:9px; }
  .t8{ font-size:8px; }
  .expenses td{ height:15px; }
  .signrow td{ height:26px; }
  .center{ text-align:center; }
  .mt2{ margin-top:2mm; }
  .mt4{ margin-top:4mm; }
  .mt6{ margin-top:6mm; }
</style>
</head>
<body>
<div class="page">
  <div class="wrap">

    <div class="col left">
      <div class="top">
        <div class="unit">
          <span class="fill lg">${esc(department || "")}</span><br>
          <span style="margin-left:18px">(unitatea)</span>
        </div>
        <div>
          Depus decontul<br>
          <span class="fill md">&nbsp;</span>
        </div>
      </div>

      <table class="t9">
        <tr>
          <td style="width:52%">
            Ziua și ora plecării <span class="fill sm">${esc(departure_date || "")}</span> <span class="fill sm">${esc(departure_time || "")}</span><br>
            Ziua și ora sosirii <span class="fill sm">${esc(return_date || "")}</span> <span class="fill sm">${esc(return_time || "")}</span><br>
            Data depunerii decontului <span class="fill sm">&nbsp;</span><br>
            Penalizări calculate <span class="fill sm">&nbsp;</span>
          </td>
          <td>
            Avans spre decontare <span class="fill sm">${esc(advance_amount || "")}</span><br>
            Primit la plecare <span class="fill sm">&nbsp;</span> lei<br>
            Primit în timpul deplasării <span class="fill sm">&nbsp;</span> lei<br>
            TOTAL <span class="fill sm">${esc(advance_amount || "")}</span> lei
          </td>
        </tr>
      </table>

      <table class="expenses t9 mt2">
        <tr>
          <th style="width:50%">Felul actului și emitentul</th>
          <th style="width:28%">Nr. și data actului</th>
          <th style="width:22%">Suma</th>
        </tr>
        ${(() => {
          const rows = Array.isArray(expense_rows) ? expense_rows : [];
          let out = "";
          for (let i = 0; i < 14; i++) {
            const r = rows[i] || {};
            const c1 = esc(r.type || "");
            const c2 = esc(r.doc || "");
            const c3 = esc(r.amount || "");
            out += `<tr><td>${c1}</td><td>${c2}</td><td>${c3}</td></tr>`;
          }
          return out;
        })()}
        <tr>
          <td colspan="2" class="center"><b>TOTAL CHELTUIELI</b></td>
          <td><b>${Array.isArray(expense_rows) ? expense_rows.reduce((sum, r) => sum + (parseFloat(r.amount || 0) || 0), 0).toFixed(2) : "0.00"}</b></td>
        </tr>
      </table>

      <table class="t8 mt2">
        <tr>
          <td style="width:40%">
            Diferență de restituit<br>
            <span class="fill sm">${esc(difference_returned || "")}</span> lei
          </td>
          <td style="width:28%">
            Diferență de primit<br>
            <span class="fill sm">${esc(difference_received || "")}</span> lei
          </td>
          <td style="width:12%" class="center">Semnătura</td>
          <td>&nbsp;</td>
        </tr>
      </table>

      <table class="t8 signrow mt2">
        <tr>
          <td class="center">Control aprobat,<br>conducătorul unității</td>
          <td class="center">Control financiar<br>preventiv</td>
          <td class="center">Verificat<br>decont</td>
          <td class="center">Șef<br>compartiment</td>
          <td class="center">Titular<br>avans</td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td>${esc(employee_sign || employee_name || "")}</td>
        </tr>
      </table>
    </div>

    <div class="col right">
      <div class="top">
        <div class="unit">
          <span class="fill lg">${esc(department || "")}</span><br>
          <span style="margin-left:18px">(unitatea)</span>
        </div>
        <div>&nbsp;</div>
      </div>

      <div class="title">Ordin de deplasare (delegație) nr. <span class="fill sm">${esc(order_number || "")}</span></div>

      <div class="row">Domnul <span class="fill xl">${esc(employee_name || "")}</span></div>
      <div class="row">având funcția de <span class="fill lg">${esc(position || "")}</span></div>
      <div class="row">este delegat pentru <span class="fill xl">${esc(purpose || "")}</span></div>
      <div class="row"><span class="fill xl">&nbsp;</span></div>
      <div class="row">la <span class="fill xl">${esc(destination || "")}</span></div>
      <div class="row"><span class="fill xl">&nbsp;</span></div>

      <div class="row mt6">
        Durata deplasării de la <span class="fill md">${esc(departure_date || "")}</span>
        până la <span class="fill md">${esc(return_date || "")}</span>
      </div>

      <div class="row">se legitimează cu <span class="fill lg">${esc(transport || "")}</span> seria CI <span class="fill md">${esc(ci_series || "")}</span></div>

      <div class="center mt6">Ștampila unității și semnătura</div>
      <div class="row mt4">Data <span class="fill md">${esc(doc_date || "")}</span></div>

      <table class="t8 mt4">
        <tr>
          <td>
            Sosit* <span class="fill sm">${esc(stamp_1_in || "")}</span><br>
            Plecat* <span class="fill sm">${esc(stamp_1_out || "")}</span><br>
            Cu / fără cazare <span class="fill sm">${esc(stamp_1_cazare || "")}</span>
          </td>
          <td>
            Sosit* <span class="fill sm">${esc(stamp_2_in || "")}</span><br>
            Plecat* <span class="fill sm">${esc(stamp_2_out || "")}</span><br>
            Cu / fără cazare <span class="fill sm">${esc(stamp_2_cazare || "")}</span>
          </td>
        </tr>
        <tr>
          <td class="center" style="height:28px; vertical-align:bottom">Ștampila unității și semnătura</td>
          <td class="center" style="height:28px; vertical-align:bottom">Ștampila unității și semnătura</td>
        </tr>
        <tr>
          <td>
            Sosit* <span class="fill sm">${esc(stamp_3_in || "")}</span><br>
            Plecat* <span class="fill sm">${esc(stamp_3_out || "")}</span><br>
            Cu / fără cazare <span class="fill sm">${esc(stamp_3_cazare || "")}</span>
          </td>
          <td>
            Sosit* <span class="fill sm">${esc(stamp_4_in || "")}</span><br>
            Plecat* <span class="fill sm">${esc(stamp_4_out || "")}</span><br>
            Cu / fără cazare <span class="fill sm">${esc(stamp_4_cazare || "")}</span>
          </td>
        </tr>
        <tr>
          <td class="center" style="height:28px; vertical-align:bottom">Ștampila unității și semnătura</td>
          <td class="center" style="height:28px; vertical-align:bottom">Ștampila unității și semnătura</td>
        </tr>
      </table>

      <div class="t8 mt2">*) Se va completa ziua, luna, anul și ora</div>
    </div>

  </div>
</div>
</body>
</html>`;
    const pdf = await renderPdfBuffer(html);
    const dir = path.join(__dirname, "public", "uploads", "tipizate");
    fs.mkdirSync(dir, { recursive: true });

    const finalName = `${Date.now()}-ordin-de-deplasare.pdf`;
    fs.writeFileSync(path.join(dir, finalName), pdf);
    const file_path = `uploads/tipizate/${finalName}`;

    db.prepare(`
      INSERT INTO tipizate_docs (title, category, file_name, file_path, mime_type, company_id)
      VALUES (?,?,?,?,?,?)
    `).run(title, "ORDIN_DE_DEPLASARE", finalName, file_path, "application/pdf", companyId);

    return res.redirect("/" + encodeURI(file_path));
  } catch (e) {
    return res.status(500).send("Ordin de deplasare failed: " + String(e?.message || e));
  }
});


app.post("/tipizate/fisa-hr/generate", requireAuth, async (req, res) => {
  try {
    const companyId = Number(req.session.user.company_id || 0);
    const employee_name = String(req.body?.employee_name || "").trim();
    const position = String(req.body?.position || "").trim();
    const hire_date = String(req.body?.hire_date || "").trim();
    const department = String(req.body?.department || "").trim();
    const content = String(req.body?.content || "").trim();

    if (!employee_name) return res.status(400).send("Numele salariatului este obligatoriu.");
    if (!position) return res.status(400).send("Funcția este obligatorie.");

    const title = `Fișă HR - ${employee_name}`;
    const esc = (v) => escapeHtml(String(v || ""));
    const html = `
<!doctype html>
<html><head><meta charset="utf-8">
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<style>
body{font-family:Arial,sans-serif;color:#111;line-height:1.5;margin:36px}
h1{margin-bottom:20px}
.box{border:1px solid #ddd;border-radius:10px;padding:16px}
.content{white-space:pre-wrap;margin-top:16px}
</style>
</head><body>
  <h1>${esc(title)}</h1>
  <div class="box">
    <div><b>Nume:</b> ${esc(employee_name)}</div>
    <div><b>Funcție:</b> ${esc(position)}</div>
    <div><b>Data angajării:</b> ${esc(hire_date)}</div>
    <div><b>Departament:</b> ${esc(department)}</div>
  </div>
  <div class="content">${esc(content || "")}</div>
</body></html>`;

    const pdf = await renderPdfBuffer(html);
    const dir = path.join(__dirname, "public", "uploads", "tipizate");
    fs.mkdirSync(dir, { recursive: true });

    const finalName = `${Date.now()}-fisa-hr.pdf`;
    fs.writeFileSync(path.join(dir, finalName), pdf);
    const file_path = `uploads/tipizate/${finalName}`;

    db.prepare(`
      INSERT INTO tipizate_docs (title, category, file_name, file_path, mime_type, company_id)
      VALUES (?,?,?,?,?,?)
    `).run(title, "FISE_HR", finalName, file_path, "application/pdf", companyId);

    return res.redirect("/" + encodeURI(file_path));
  } catch (e) {
    return res.status(500).send("Fisa HR failed: " + String(e?.message || e));
  }
});

app.post("/tipizate/upload", requireAuth, upload.single("pdf"), (req, res) => {
  const companyId = Number(req.session.user.company_id || 0);
  if (!req.file) return res.status(400).send("Fișier PDF obligatoriu.");

  const title = String(req.body?.title || "").trim();
  const category = String(req.body?.category || "ALTELE").trim().toUpperCase();
  if (!title) return res.status(400).send("Titlul documentului este obligatoriu.");

  const uploadsDir = path.join(__dirname, "public", "uploads", "tipizate");
  fs.mkdirSync(uploadsDir, { recursive: true });

  const safeBase = String(req.file.originalname || "document.pdf").replace(/[^A-Za-z0-9._-]/g, "_");
  const finalName = `${Date.now()}-${safeBase.endsWith(".pdf") ? safeBase : `${safeBase}.pdf`}`;
  const finalPath = path.join(uploadsDir, finalName);
  fs.renameSync(req.file.path, finalPath);

  db.prepare(`
    INSERT INTO tipizate_docs (title, category, file_name, file_path, mime_type, company_id)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(
    title,
    category,
    finalName,
    `uploads/tipizate/${finalName}`,
    req.file.mimetype || "application/pdf",
    companyId
  );

  return res.redirect("/tipizate");
});

app.post("/tipizate/:id/delete", requireAuth, (req, res) => {
  const companyId = Number(req.session.user.company_id || 0);
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).send("Bad id");

  const doc = db.prepare(`
    SELECT id, file_path
    FROM tipizate_docs
    WHERE id=? AND company_id=?
  `).get(id, companyId);

  if (!doc) return res.status(404).send("Document not found");

  if (doc.file_path) {
    const absPath = path.join(__dirname, "public", String(doc.file_path || "").replace(/^\/+/, ""));
    if (fs.existsSync(absPath)) {
      fs.unlinkSync(absPath);
    }
  }

  db.prepare("DELETE FROM tipizate_docs WHERE id=? AND company_id=?").run(id, companyId);
  return res.redirect("/tipizate");
});


app.post("/accounts/create", requireAuth, requireRole("admin"), (req, res) => {

  const email = String(req.body?.email || "").trim().toLowerCase();
  const password = String(req.body?.password || "");
  const role = String(req.body?.role || "operator");
  const companyId = Number(req.session?.user?.company_id || 0);

  if(!email || !password){
    return res.status(400).send("Email și parolă obligatorii.");
  }
  if(!companyId){
    return res.status(400).send("Compania utilizatorului curent nu este configurată.");
  }

  const existing = db.prepare("SELECT id FROM users WHERE email=?").get(email);
  if(existing){
    return res.status(400).send("Utilizatorul există deja.");
  }

  const roleKey = String(role || "").trim().toLowerCase();
  const defaultRoleModules = Array.isArray(ROLE_MODULES[roleKey]) ? ROLE_MODULES[roleKey] : [];
  const hash = bcrypt.hashSync(password, 12);

  db.prepare(`
    INSERT INTO users (email,password_hash,role,company_id,status,is_company_admin,module_permissions)
    VALUES (?,?,?,?, 'active', ?, ?)
  `).run(
    email,
    hash,
    role,
    companyId,
    role === "admin" ? 1 : 0,
    JSON.stringify(defaultRoleModules)
  );

  db.prepare(`
    UPDATE company_subscriptions
    SET seats_used=(SELECT COUNT(*) FROM users WHERE company_id=?),
        updated_at=datetime('now')
    WHERE id = (
      SELECT id
      FROM company_subscriptions
      WHERE company_id=?
      ORDER BY id DESC
      LIMIT 1
    )
  `).run(companyId, companyId, companyId);

  res.redirect("/accounts");

});



app.post("/accounts/:id/edit", requireAuth, requireRole("admin"), (req, res) => {

  const id = Number(req.params.id);
  const email = String(req.body?.email || "").trim().toLowerCase();
  const role = String(req.body?.role || "operator");
  const password = String(req.body?.password || "");
  const companyId = Number(req.session?.user?.company_id || 0);
  const currentUserId = Number(req.session?.user?.id || 0);

  let modules = req.body.modules || [];
  if (!Array.isArray(modules)) modules = [modules];
  const modulesJson = JSON.stringify(modules);

  const existingUser = db.prepare(`
    SELECT id
    FROM users
    WHERE id=? AND company_id=?
  `).get(id, companyId);
  if (!existingUser) {
    return res.status(404).send("User not found");
  }

  if (!email) {
    return res.status(400).send("Email obligatoriu.");
  }

  const emailOwner = db.prepare(`
    SELECT id
    FROM users
    WHERE email=? AND id<>?
  `).get(email, id);
  if (emailOwner) {
    return res.status(400).send("Există deja un utilizator cu acest email.");
  }

  if (currentUserId === id && role !== "admin") {
    return res.status(400).send("Contul conectat trebuie să rămână admin.");
  }

  if(password){

    const hash = bcrypt.hashSync(password,12);

    db.prepare(`
      UPDATE users
      SET email=?, role=?, password_hash=?, module_permissions=?, is_company_admin=?
      WHERE id=?
    `).run(email, role, hash, modulesJson, role === "admin" ? 1 : 0, id);

  } else {

    db.prepare(`
      UPDATE users
      SET email=?, role=?, module_permissions=?, is_company_admin=?
      WHERE id=?
    `).run(email, role, modulesJson, role === "admin" ? 1 : 0, id);

  }

  if (currentUserId === id) {
    req.session.user.email = email;
  }

  res.redirect("/accounts");

});

app.post("/accounts/:id/delete", requireAuth, requireRole("admin"), (req, res) => {
  const id = Number(req.params.id);
  const companyId = Number(req.session?.user?.company_id || 0);
  const currentUserId = Number(req.session?.user?.id || 0);

  const user = db.prepare(`
    SELECT id, role
    FROM users
    WHERE id=? AND company_id=?
  `).get(id, companyId);

  if (!user) {
    return res.status(404).send("User not found");
  }

  if (id === currentUserId) {
    return res.status(400).send("Nu îți poți șterge contul conectat.");
  }

  if (String(user.role || "").toLowerCase() === "admin") {
    const adminsCount = db.prepare(`
      SELECT COUNT(*) AS n
      FROM users
      WHERE company_id=? AND LOWER(COALESCE(role,''))='admin'
    `).get(companyId)?.n || 0;

    if (adminsCount <= 1) {
      return res.status(400).send("Nu poți șterge ultimul administrator al companiei.");
    }
  }

  db.prepare(`
    DELETE FROM users
    WHERE id=? AND company_id=?
  `).run(id, companyId);

  db.prepare(`
    UPDATE company_subscriptions
    SET seats_used=(SELECT COUNT(*) FROM users WHERE company_id=?),
        updated_at=datetime('now')
    WHERE id = (
      SELECT id
      FROM company_subscriptions
      WHERE company_id=?
      ORDER BY id DESC
      LIMIT 1
    )
  `).run(companyId, companyId);

  res.redirect("/accounts");
});



app.get("/accounts/:id/edit", requireAuth, requireRole("admin"), (req, res) => {

  const id = Number(req.params.id);
  const companyId = Number(req.session?.user?.company_id || 0);

  const user = db.prepare(`
    SELECT id,email,role,module_permissions
    FROM users
    WHERE id=? AND company_id=?
  `).get(id, companyId);

  if(!user){
    return res.status(404).send("User not found");
  }

  let perms = [];
  try {
    perms = JSON.parse(user.module_permissions || "[]");
    if (!Array.isArray(perms)) perms = [];
  } catch (e) {
    perms = [];
  }

  const allModules = MODULE_DEFINITIONS.map((item) => [item.key, item.label]);

  const modulesHtml = allModules.map(([key,label]) => `
    <label style="display:flex;align-items:center;gap:10px;padding:10px 12px;border:1px solid #e5e7eb;border-radius:12px;background:#fff">
      <input type="checkbox" name="modules" value="${key}" ${perms.includes(key) ? "checked" : ""}>
      <span>${label}</span>
    </label>
  `).join("");

  const html = `
<!doctype html>
<html>
<head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<meta charset="utf-8">
<title>Edit user</title>
</head>

${crmShellStart("accounts","Edit user","Modificare rol, parolă și module utilizator.",req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

<section class="crm-card" style="max-width:760px">

<form method="post" action="/accounts/${user.id}/edit" class="crm-stack">

<div>
<label class="crm-label">Email</label>
<input class="crm-input" type="email" name="email" value="${escapeHtml(user.email)}" required>
</div>

<div>
<label class="crm-label">Rol</label>
<select class="crm-input" name="role">

<option value="admin" ${user.role==="admin"?"selected":""}>admin</option>
<option value="manager" ${user.role==="manager"?"selected":""}>manager</option>
<option value="operator" ${user.role==="operator"?"selected":""}>operator</option>
<option value="hr" ${user.role==="hr"?"selected":""}>hr</option>
<option value="accounting" ${user.role==="accounting"?"selected":""}>accounting</option>

</select>
</div>

<div>
<label class="crm-label">Module permise</label>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">
${modulesHtml}
</div>
</div>

<div>
<label class="crm-label">Parolă nouă (opțional)</label>
<input class="crm-input" type="password" name="password">
</div>

<div>
<button class="crm-btn" type="submit">Salvează</button>
</div>

</form>

<form method="post" action="/accounts/${user.id}/delete" onsubmit="return confirm('Ștergi acest utilizator?');" style="margin-top:12px">
  <button class="crm-btn crm-btn-danger" type="submit">Șterge utilizatorul</button>
</form>

</section>

${crmShellEnd()}
</html>
`;

res.send(html);

});



app.get("/accounts", requireAuth, requireRole("admin"), (req, res) => {
  const companyId = Number(req.session?.user?.company_id || 0);
  const users = db.prepare(`
    SELECT id, email, role, created_at
    FROM users
    WHERE company_id=?
    ORDER BY id DESC
  `).all(companyId);

  const rows = users.map(u => `
    <tr>
      <td>${u.id}</td>
      <td>${escapeHtml(u.email || "")}</td>
      <td>${escapeHtml(u.role || "")}</td>
      <td>${escapeHtml(u.created_at || "")}</td>
      <td>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <a href="/accounts/${u.id}/edit">Edit</a>
          <form method="post" action="/accounts/${u.id}/delete" style="margin:0" onsubmit="return confirm('Ștergi acest utilizator?');">
            <button type="submit" class="crm-btn crm-btn-danger" style="padding:6px 10px">Șterge</button>
          </form>
        </div>
      </td>
    </tr>
  `).join("");

  const html = `
<!doctype html>
<html>
<head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<meta charset="utf-8">
<title>Accounts</title>
</head>

${crmShellStart("accounts", "Accounts", "Administrare utilizatori și roluri.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

  <section class="crm-card" style="position:sticky;top:20px;z-index:10">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px">
      <div>
        <h3 style="margin:0;font-size:20px">Utilizatori</h3>
        <div class="crm-muted" style="margin-top:6px">Listă conturi existente în MiniCRM.</div>
      </div>
    </div>

    <form method="post" action="/accounts/create" class="crm-grid-3" style="margin-bottom:18px">
      <div>
        <label class="crm-label">Email</label>
        <input class="crm-input" type="email" name="email" required>
      </div>
      <div>
        <label class="crm-label">Parolă</label>
        <input class="crm-input" type="password" name="password" required>
      </div>
      <div>
        <label class="crm-label">Rol</label>
        <select class="crm-input" name="role">
          <option value="admin">admin</option>
          <option value="manager">manager</option>
          <option value="operator" selected>operator</option>
          <option value="hr">hr</option>
          <option value="accounting">accounting</option>
        </select>
      </div>
      <div style="grid-column:1/-1">
        <button class="crm-btn" type="submit">Adaugă utilizator</button>
      </div>
    </form>

    <div style="overflow:auto">
      <table class="crm-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Email</th>
            <th>Rol</th>
            <th>Creat la</th>
            <th>Acțiuni</th>
          </tr>
        </thead>
        <tbody>
          ${rows || `<tr><td colspan="5" class="crm-muted">Nu există utilizatori.</td></tr>`}
        </tbody>
      </table>
    </div>
  </section>

${crmShellEnd()}
</html>
`;
  res.send(html);
});

app.get("/super-admin/companies", requireAuth, requireSuperAdmin, (req, res) => {
  const q = String(req.query?.q || "").trim();
  const status = String(req.query?.status || "").trim().toLowerCase();
  const plan = String(req.query?.plan || "").trim().toLowerCase();

  const where = [];
  const params = [];
  if (q) {
    where.push("(LOWER(c.name) LIKE ? OR LOWER(COALESCE(c.slug,'')) LIKE ? OR LOWER(COALESCE(c.cui,'')) LIKE ?)");
    const token = `%${q.toLowerCase()}%`;
    params.push(token, token, token);
  }
  if (status && status !== "all") {
    where.push("LOWER(COALESCE(c.status,'active')) = ?");
    params.push(status);
  }
  if (plan && plan !== "all") {
    where.push("LOWER(COALESCE(p.code,'')) = ?");
    params.push(plan);
  }

  const rows = db.prepare(`
    SELECT
      c.id,
      c.name,
      c.slug,
      c.cui,
      c.status,
      c.suspension_reason,
      c.created_at,
      c.max_users,
      p.name AS plan_name,
      p.price_monthly,
      cs.status AS subscription_status,
      cs.seats_included,
      cs.seats_used,
      (
        SELECT COUNT(*) FROM users u
        WHERE u.company_id = c.id
      ) AS users_count,
      (
        SELECT COUNT(*) FROM clients cl
        WHERE cl.company_id = c.id
      ) AS clients_count,
      (
        SELECT COUNT(*) FROM contracts ct
        WHERE ct.company_id = c.id
      ) AS contracts_count,
      (
        SELECT COUNT(*) FROM facturi f
        WHERE f.company_id = c.id
      ) AS facturi_count
    FROM companies c
    LEFT JOIN company_subscriptions cs
      ON cs.company_id = c.id
     AND cs.id = (
       SELECT cs2.id
       FROM company_subscriptions cs2
       WHERE cs2.company_id = c.id
       ORDER BY cs2.id DESC
       LIMIT 1
     )
    LEFT JOIN plans p ON p.id = cs.plan_id
    ${where.length ? `WHERE ${where.join(" AND ")}` : ""}
    ORDER BY c.id DESC
  `).all(...params);

  const planOptions = db.prepare(`
    SELECT code, name
    FROM plans
    WHERE status='active'
    ORDER BY price_monthly ASC, id ASC
  `).all();

  const htmlRows = rows.map((row) => {
    const statusBadge = companyStatusBadge(row.status);

    return `
      <tr>
        <td>
          <div style="font-weight:800">${escapeHtml(row.name || "")}</div>
          <div class="crm-muted" style="margin-top:4px">${escapeHtml(row.slug || "")}</div>
        </td>
        <td>${escapeHtml(row.cui || "—")}</td>
        <td>${escapeHtml(row.plan_name || "Fără plan")}</td>
        <td>${statusBadge}</td>
        <td>${escapeHtml(String(row.users_count || 0))} / ${escapeHtml(String(row.seats_included || row.max_users || 0))}</td>
        <td>${escapeHtml(String(row.clients_count || 0))}</td>
        <td>${escapeHtml(String(row.contracts_count || 0))}</td>
        <td>${escapeHtml(String(row.facturi_count || 0))}</td>
        <td>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <a class="crm-btn crm-btn-secondary" href="/super-admin/companies/${row.id}">Audit</a>
            <div class="crm-muted">${escapeHtml(row.subscription_status || row.status || "—")}</div>
          </div>
        </td>
      </tr>
    `;
  }).join("");

  const html = `
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Super Admin - Companii</title>
</head>
${crmShellStart("superadmin", "Companii", "Control global pentru tenant-uri, planuri și status operațional.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}
  <section class="crm-card">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:16px">
      <div>
        <h3 style="margin:0;font-size:20px">Companii active în platformă</h3>
        <div class="crm-muted" style="margin-top:6px">Vezi rapid planul, capacitatea, statusul și intri în auditul fiecărui tenant.</div>
      </div>
      <div class="crm-badge crm-badge-blue">${escapeHtml(String(rows.length))} companii</div>
    </div>

    <form method="get" action="/super-admin/companies" class="crm-grid-3" style="margin-bottom:18px;overflow:visible">
      <div>
        <label class="crm-label">Căutare</label>
        <input class="crm-input" type="text" name="q" value="${escapeHtml(q)}" placeholder="nume, slug sau CUI">
      </div>
      <div>
        <label class="crm-label">Status</label>
        <select class="crm-input" name="status">
          <option value="all" ${!status || status === "all" ? "selected" : ""}>Toate</option>
          <option value="trial" ${status === "trial" ? "selected" : ""}>Trial</option>
          <option value="active" ${status === "active" ? "selected" : ""}>Active</option>
          <option value="past_due" ${status === "past_due" ? "selected" : ""}>Past due</option>
          <option value="suspended" ${status === "suspended" ? "selected" : ""}>Suspendate</option>
        </select>
      </div>
      <div>
        <label class="crm-label">Plan</label>
        <select class="crm-input" name="plan">
          <option value="all" ${!plan || plan === "all" ? "selected" : ""}>Toate planurile</option>
          ${planOptions.map((item) => `<option value="${escapeHtml(item.code || "")}" ${plan === String(item.code || "").toLowerCase() ? "selected" : ""}>${escapeHtml(item.name || item.code || "")}</option>`).join("")}
        </select>
      </div>
      <div style="grid-column:1/-1;display:flex;gap:10px;flex-wrap:wrap">
        <button class="crm-btn" type="submit">Aplică filtrele</button>
        <a class="crm-btn crm-btn-secondary" href="/super-admin/companies">Resetează</a>
      </div>
    </form>

    <div class="crm-table-wrap">
      <table class="crm-table">
        <thead>
          <tr>
            <th>Companie</th>
            <th>CUI</th>
            <th>Plan</th>
            <th>Status</th>
            <th>Utilizatori</th>
            <th>Clienți</th>
            <th>Contracte</th>
            <th>Facturi</th>
            <th>Acțiuni</th>
          </tr>
        </thead>
        <tbody>
          ${htmlRows || `<tr><td colspan="9" class="crm-muted">Nu există companii.</td></tr>`}
        </tbody>
      </table>
    </div>
  </section>
${crmShellEnd()}
</html>
`;

  res.send(html);
});

app.get("/super-admin/companies/:id", requireAuth, requireSuperAdmin, (req, res) => {
  const companyId = Number(req.params.id);
  if (!Number.isFinite(companyId)) return res.status(400).send("Bad id");

  const company = db.prepare(`
    SELECT
      c.*,
      p.name AS plan_name,
      p.price_monthly,
      cs.seats_included,
      cs.seats_used,
      cs.status AS subscription_status
    FROM companies c
    LEFT JOIN company_subscriptions cs
      ON cs.company_id = c.id
     AND cs.id = (
       SELECT cs2.id
       FROM company_subscriptions cs2
       WHERE cs2.company_id = c.id
       ORDER BY cs2.id DESC
       LIMIT 1
     )
    LEFT JOIN plans p ON p.id = cs.plan_id
    WHERE c.id=?
  `).get(companyId);

  if (!company) return res.status(404).send("Company not found");

  const users = db.prepare(`
    SELECT id, email, role, status, created_at
    FROM users
    WHERE company_id=?
    ORDER BY id DESC
    LIMIT 25
  `).all(companyId);

  const recentClients = db.prepare(`
    SELECT id, name, cui, created_at
    FROM clients
    WHERE company_id=?
    ORDER BY id DESC
    LIMIT 10
  `).all(companyId);

  const recentFacturi = db.prepare(`
    SELECT id, factura_nr, status, total, created_at
    FROM facturi
    WHERE company_id=?
    ORDER BY id DESC
    LIMIT 10
  `).all(companyId);

  const recentPayments = db.prepare(`
    SELECT bp.source, bp.status, bp.amount, bp.currency, bp.payer_name, bp.payer_email, bp.reference_code, bp.created_at, bp.paid_at,
           bp.invoice_generation_status, bp.generated_factura_id, f.factura_nr
    FROM billing_payments bp
    LEFT JOIN facturi f ON f.id = bp.generated_factura_id
    WHERE bp.company_id=?
    ORDER BY bp.id DESC
    LIMIT 10
  `).all(companyId);

  const adminEvents = db.prepare(`
    SELECT actor_email, event_type, status_from, status_to, reason, created_at
    FROM company_admin_events
    WHERE company_id=?
    ORDER BY id DESC
    LIMIT 12
  `).all(companyId);

  const stats = {
    users: db.prepare(`SELECT COUNT(*) AS n FROM users WHERE company_id=?`).get(companyId)?.n || 0,
    clients: db.prepare(`SELECT COUNT(*) AS n FROM clients WHERE company_id=?`).get(companyId)?.n || 0,
    quotes: db.prepare(`SELECT COUNT(*) AS n FROM quotes WHERE company_id=?`).get(companyId)?.n || 0,
    contracts: db.prepare(`SELECT COUNT(*) AS n FROM contracts WHERE company_id=?`).get(companyId)?.n || 0,
    facturi: db.prepare(`SELECT COUNT(*) AS n FROM facturi WHERE company_id=?`).get(companyId)?.n || 0,
    tipizate: db.prepare(`SELECT COUNT(*) AS n FROM tipizate_docs WHERE company_id=?`).get(companyId)?.n || 0
  };

  const usersRows = users.map((user) => `
    <tr>
      <td>${escapeHtml(user.email || "")}</td>
      <td>${escapeHtml(user.role || "")}</td>
      <td>${escapeHtml(user.status || "")}</td>
      <td>${escapeHtml(user.created_at || "")}</td>
    </tr>
  `).join("");

  const clientsRows = recentClients.map((client) => `
    <tr>
      <td>${escapeHtml(client.name || "")}</td>
      <td>${escapeHtml(client.cui || "—")}</td>
      <td>${escapeHtml(client.created_at || "")}</td>
    </tr>
  `).join("");

  const facturiRows = recentFacturi.map((factura) => `
    <tr>
      <td>${escapeHtml(factura.factura_nr || "")}</td>
      <td>${escapeHtml(factura.status || "")}</td>
      <td>${fmtMoney(factura.total || 0)}</td>
      <td>${escapeHtml(factura.created_at || "")}</td>
    </tr>
  `).join("");

  const adminEventRows = adminEvents.map((event) => `
    <tr>
      <td>${escapeHtml(event.created_at || "")}</td>
      <td>${escapeHtml(event.actor_email || "—")}</td>
      <td>${escapeHtml(event.event_type || "")}</td>
      <td>${escapeHtml(event.status_from || "—")} -> ${escapeHtml(event.status_to || "—")}</td>
      <td>${escapeHtml(event.reason || "—")}</td>
    </tr>
  `).join("");

  const paymentRows = recentPayments.map((payment) => `
    <tr>
      <td>${paymentSourceBadge(payment.source)}</td>
      <td>${paymentStatusBadge(payment.status)}</td>
      <td>${fmtMoney(payment.amount || 0)} ${escapeHtml(String(payment.currency || "").toUpperCase() || "")}</td>
      <td>${escapeHtml(payment.payer_name || payment.payer_email || "—")}</td>
      <td>${escapeHtml(payment.reference_code || payment.factura_nr || "—")}</td>
      <td>${escapeHtml(payment.paid_at || payment.created_at || "—")}</td>
    </tr>
  `).join("");

  const html = `
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Audit companie</title>
</head>
${crmShellStart("superadmin", `Audit ${company.name || ""}`, "Audit rapid pentru o companie: utilizatori, documente și volum de lucru.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}
  <section class="crm-card" style="margin-bottom:18px">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap">
      <div>
        <a href="/super-admin/companies" class="crm-btn crm-btn-secondary" style="margin-bottom:14px">Înapoi la companii</a>
        <h3 style="margin:0;font-size:24px">${escapeHtml(company.name || "")}</h3>
        <div class="crm-muted" style="margin-top:8px">Slug: ${escapeHtml(company.slug || "")} • CUI: ${escapeHtml(company.cui || "—")} • Status: ${escapeHtml(company.status || "")}</div>
        ${company.suspension_reason ? `<div class="crm-muted" style="margin-top:8px">Motiv curent: ${escapeHtml(company.suspension_reason)}</div>` : ``}
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <div class="crm-badge crm-badge-blue">${escapeHtml(company.plan_name || "Fără plan")}</div>
        ${companyStatusBadge(company.status)}
      </div>
    </div>

    <div class="crm-grid-3" style="margin-top:18px;overflow:visible">
      <div class="crm-card">
        <div class="crm-muted">Utilizatori</div>
        <div style="font-size:28px;font-weight:800;margin-top:8px">${escapeHtml(String(stats.users))}</div>
      </div>
      <div class="crm-card">
        <div class="crm-muted">Clienți / Oferte / Contracte</div>
        <div style="font-size:28px;font-weight:800;margin-top:8px">${escapeHtml(String(stats.clients))} / ${escapeHtml(String(stats.quotes))} / ${escapeHtml(String(stats.contracts))}</div>
      </div>
      <div class="crm-card">
        <div class="crm-muted">Facturi / Tipizate</div>
        <div style="font-size:28px;font-weight:800;margin-top:8px">${escapeHtml(String(stats.facturi))} / ${escapeHtml(String(stats.tipizate))}</div>
      </div>
    </div>
  </section>

  <section class="crm-card" style="margin-bottom:18px">
    <h3 style="margin:0 0 14px 0;font-size:18px">Control status companie</h3>
    <form method="post" action="/super-admin/companies/${company.id}/status" class="crm-stack" style="max-width:720px">
      <div class="crm-grid-2" style="overflow:visible">
        <div>
          <label class="crm-label">Status nou</label>
          <select class="crm-input" name="status">
            <option value="trial" ${String(company.status || "").toLowerCase() === "trial" ? "selected" : ""}>trial</option>
            <option value="active" ${String(company.status || "").toLowerCase() === "active" ? "selected" : ""}>active</option>
            <option value="past_due" ${String(company.status || "").toLowerCase() === "past_due" ? "selected" : ""}>past_due</option>
            <option value="suspended" ${String(company.status || "").toLowerCase() === "suspended" ? "selected" : ""}>suspended</option>
          </select>
        </div>
        <div>
          <label class="crm-label">Motiv</label>
          <input class="crm-input" name="reason" value="${escapeHtml(company.suspension_reason || "")}" placeholder="motiv suspendare / reactivare">
        </div>
      </div>
      <div>
        <button class="crm-btn" type="submit">Salvează statusul</button>
      </div>
    </form>
  </section>

  <div class="crm-grid-2" style="overflow:visible">
    <section class="crm-card">
      <h3 style="margin:0 0 14px 0;font-size:18px">Utilizatori companie</h3>
      <div class="crm-table-wrap">
        <table class="crm-table">
          <thead><tr><th>Email</th><th>Rol</th><th>Status</th><th>Creat la</th></tr></thead>
          <tbody>${usersRows || `<tr><td colspan="4" class="crm-muted">Nu există utilizatori.</td></tr>`}</tbody>
        </table>
      </div>
    </section>

    <section class="crm-card">
      <h3 style="margin:0 0 14px 0;font-size:18px">Ultimii clienți</h3>
      <div class="crm-table-wrap">
        <table class="crm-table">
          <thead><tr><th>Client</th><th>CUI</th><th>Creat la</th></tr></thead>
          <tbody>${clientsRows || `<tr><td colspan="3" class="crm-muted">Nu există clienți.</td></tr>`}</tbody>
        </table>
      </div>
    </section>
  </div>

  <section class="crm-card" style="margin-top:18px">
    <h3 style="margin:0 0 14px 0;font-size:18px">Ultimele facturi</h3>
    <div class="crm-table-wrap">
      <table class="crm-table">
        <thead><tr><th>Factură</th><th>Status</th><th>Total</th><th>Creat la</th></tr></thead>
        <tbody>${facturiRows || `<tr><td colspan="4" class="crm-muted">Nu există facturi.</td></tr>`}</tbody>
      </table>
    </div>
  </section>

  <section class="crm-card" style="margin-top:18px">
    <h3 style="margin:0 0 14px 0;font-size:18px">Ultimele plăți</h3>
    <div class="crm-table-wrap">
      <table class="crm-table">
        <thead><tr><th>Sursă</th><th>Status</th><th>Sumă</th><th>Plătitor</th><th>Referință</th><th>Moment</th></tr></thead>
        <tbody>${paymentRows || `<tr><td colspan="6" class="crm-muted">Nu există plăți înregistrate.</td></tr>`}</tbody>
      </table>
    </div>
  </section>

  <section class="crm-card" style="margin-top:18px">
    <h3 style="margin:0 0 14px 0;font-size:18px">Istoric acțiuni super-admin</h3>
    <div class="crm-table-wrap">
      <table class="crm-table">
        <thead><tr><th>Data</th><th>Actor</th><th>Eveniment</th><th>Status</th><th>Motiv</th></tr></thead>
        <tbody>${adminEventRows || `<tr><td colspan="5" class="crm-muted">Nu există evenimente încă.</td></tr>`}</tbody>
      </table>
    </div>
  </section>
${crmShellEnd()}
</html>
`;

  res.send(html);
});

app.post("/super-admin/companies/:id/status", requireAuth, requireSuperAdmin, (req, res) => {
  const companyId = Number(req.params.id);
  const nextStatus = String(req.body?.status || "").trim().toLowerCase();
  const reason = String(req.body?.reason || "").trim();
  if (!Number.isFinite(companyId)) return res.status(400).send("Bad id");
  if (!["trial", "active", "past_due", "suspended"].includes(nextStatus)) return res.status(400).send("Status invalid");

  const existingCompany = db.prepare(`
    SELECT id, status, suspension_reason
    FROM companies
    WHERE id=?
  `).get(companyId);
  if (!existingCompany) return res.status(404).send("Company not found");

  db.prepare(`
    UPDATE companies
    SET status=?,
        suspension_reason=?,
        suspended_at=CASE WHEN ?='suspended' THEN datetime('now') ELSE NULL END,
        suspended_by_email=CASE WHEN ?='suspended' THEN ? ELSE NULL END,
        updated_at=datetime('now')
    WHERE id=?
  `).run(
    nextStatus,
    reason || null,
    nextStatus,
    nextStatus,
    String(req.session.user.email || ""),
    companyId
  );

  db.prepare(`
    UPDATE company_subscriptions
    SET status=?,
        updated_at=datetime('now')
    WHERE company_id=?
  `).run(nextStatus, companyId);

  logCompanyAdminEvent({
    companyId,
    actorUserId: Number(req.session.user.id || 0),
    actorEmail: req.session.user.email,
    eventType: "company_status_updated",
    statusFrom: existingCompany.status || "",
    statusTo: nextStatus,
    reason
  });

  res.redirect("/super-admin/companies");
});

app.get("/super-admin/payments", requireAuth, requireSuperAdmin, (req, res) => {
  const q = String(req.query?.q || "").trim();
  const status = String(req.query?.status || "").trim().toLowerCase();
  const source = String(req.query?.source || "").trim().toLowerCase();
  const plan = String(req.query?.plan || "").trim().toLowerCase();
  const companyFilter = Number(req.query?.company_id || 0) || 0;

  const where = [];
  const params = [];

  if (q) {
    where.push("(LOWER(c.name) LIKE ? OR LOWER(COALESCE(bp.payer_email,'')) LIKE ? OR LOWER(COALESCE(bp.payer_name,'')) LIKE ? OR LOWER(COALESCE(bp.reference_code,'')) LIKE ?)");
    const token = `%${q.toLowerCase()}%`;
    params.push(token, token, token, token);
  }
  if (status && status !== "all") {
    where.push("LOWER(COALESCE(bp.status,'')) = ?");
    params.push(status);
  }
  if (source && source !== "all") {
    where.push("LOWER(COALESCE(bp.source,'')) = ?");
    params.push(source);
  }
  if (plan && plan !== "all") {
    where.push("LOWER(COALESCE(p.code,'')) = ?");
    params.push(plan);
  }
  if (companyFilter) {
    where.push("bp.company_id = ?");
    params.push(companyFilter);
  }

  const payments = db.prepare(`
    SELECT
      bp.*,
      c.name AS company_name,
      c.slug AS company_slug,
      c.status AS company_status,
      cs.status AS subscription_status,
      p.code AS plan_code,
      p.name AS plan_name,
      f.factura_nr AS generated_factura_nr
    FROM billing_payments bp
    JOIN companies c ON c.id = bp.company_id
    LEFT JOIN company_subscriptions cs ON cs.id = bp.company_subscription_id
    LEFT JOIN plans p ON p.id = cs.plan_id
    LEFT JOIN facturi f ON f.id = bp.generated_factura_id
    ${where.length ? `WHERE ${where.join(" AND ")}` : ""}
    ORDER BY bp.id DESC
    LIMIT 300
  `).all(...params);

  const stats = payments.reduce((acc, row) => {
    acc.total += 1;
    if (String(row.status || "").toLowerCase() === "paid") acc.paid += 1;
    if (String(row.status || "").toLowerCase() === "failed") acc.failed += 1;
    if (String(row.status || "").toLowerCase() === "pending_verification") acc.pending += 1;
    if (String(row.source || "").toLowerCase() === "stripe") acc.stripe += 1;
    if (String(row.source || "").toLowerCase() === "op") acc.op += 1;
    return acc;
  }, { total: 0, paid: 0, failed: 0, pending: 0, stripe: 0, op: 0 });

  const planBreakdown = db.prepare(`
    SELECT
      p.name AS plan_name,
      p.code AS plan_code,
      COUNT(bp.id) AS payments_count,
      SUM(CASE WHEN LOWER(COALESCE(bp.status,''))='paid' THEN 1 ELSE 0 END) AS paid_count
    FROM billing_payments bp
    JOIN companies c ON c.id = bp.company_id
    LEFT JOIN company_subscriptions cs ON cs.id = bp.company_subscription_id
    LEFT JOIN plans p ON p.id = cs.plan_id
    GROUP BY p.id, p.name, p.code
    ORDER BY payments_count DESC, p.name ASC
  `).all();

  const companies = db.prepare(`
    SELECT id, name
    FROM companies
    ORDER BY name COLLATE NOCASE ASC
  `).all();

  const planOptions = db.prepare(`
    SELECT code, name
    FROM plans
    WHERE status='active'
    ORDER BY price_monthly ASC, id ASC
  `).all();

  const paymentRows = payments.map((row) => `
    <tr>
      <td>
        <div style="font-weight:800">${escapeHtml(row.company_name || "")}</div>
        <div class="crm-muted" style="margin-top:4px">${escapeHtml(row.plan_name || "Fără plan")}</div>
      </td>
      <td>${paymentSourceBadge(row.source)}</td>
      <td>${paymentStatusBadge(row.status)}</td>
      <td>${fmtMoney(row.amount || 0)} ${escapeHtml(String(row.currency || "").toUpperCase() || "")}</td>
      <td>
        <div>${escapeHtml(row.payer_name || "—")}</div>
        <div class="crm-muted" style="margin-top:4px">${escapeHtml(row.payer_email || "—")}</div>
      </td>
      <td>
        <div>${escapeHtml(row.created_by_email || "—")}</div>
        <div class="crm-muted" style="margin-top:4px">${escapeHtml(row.provider_event_type || "manual")}</div>
      </td>
      <td>${escapeHtml(row.reference_code || row.stripe_invoice_id || row.stripe_checkout_session_id || "—")}</td>
      <td>${escapeHtml(row.paid_at || "—")}</td>
      <td>
        <div>${row.generated_factura_id ? `<a href="/factura/${row.generated_factura_id}">${escapeHtml(row.generated_factura_nr || `Factura #${row.generated_factura_id}`)}</a>` : "—"}</div>
        <div class="crm-muted" style="margin-top:4px">${escapeHtml(row.invoice_generation_status || "neprocesată")}</div>
      </td>
      <td>${escapeHtml(row.failure_reason || row.notes || "—")}</td>
    </tr>
  `).join("");

  const planRows = planBreakdown.map((row) => `
    <tr>
      <td>${escapeHtml(row.plan_name || row.plan_code || "Fără plan")}</td>
      <td>${escapeHtml(String(row.payments_count || 0))}</td>
      <td>${escapeHtml(String(row.paid_count || 0))}</td>
    </tr>
  `).join("");

  const html = `
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Super Admin - Plăți</title>
</head>
${crmShellStart("superadmin-payments", "Plăți", "Monitorizare centrală pentru Stripe și înregistrări manuale prin OP.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}
  <section class="crm-card" style="margin-bottom:18px">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px">
      <div class="crm-card"><div class="crm-muted">Plăți urmărite</div><div style="font-size:30px;font-weight:800;margin-top:8px">${escapeHtml(String(stats.total))}</div></div>
      <div class="crm-card"><div class="crm-muted">Stripe</div><div style="font-size:30px;font-weight:800;margin-top:8px;color:#1d4ed8">${escapeHtml(String(stats.stripe))}</div></div>
      <div class="crm-card"><div class="crm-muted">OP</div><div style="font-size:30px;font-weight:800;margin-top:8px;color:#b45309">${escapeHtml(String(stats.op))}</div></div>
      <div class="crm-card"><div class="crm-muted">Reușite</div><div style="font-size:30px;font-weight:800;margin-top:8px;color:#15803d">${escapeHtml(String(stats.paid))}</div></div>
      <div class="crm-card"><div class="crm-muted">Eșuate</div><div style="font-size:30px;font-weight:800;margin-top:8px;color:#b91c1c">${escapeHtml(String(stats.failed))}</div></div>
      <div class="crm-card"><div class="crm-muted">Așteaptă verificare</div><div style="font-size:30px;font-weight:800;margin-top:8px;color:#b45309">${escapeHtml(String(stats.pending))}</div></div>
    </div>
  </section>

  <div class="crm-grid-2" style="overflow:visible">
    <section class="crm-card">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px">
        <div>
          <h3 style="margin:0;font-size:20px">Flux plăți</h3>
          <div class="crm-muted" style="margin-top:6px">Vezi cine a inițiat plata, cine a plătit și unde au apărut eșecuri.</div>
        </div>
        <div class="crm-badge crm-badge-blue">${escapeHtml(String(payments.length))} rezultate</div>
      </div>

      <form method="get" action="/super-admin/payments" class="crm-grid-3" style="margin-bottom:18px;overflow:visible">
        <div>
          <label class="crm-label">Căutare</label>
          <input class="crm-input" type="text" name="q" value="${escapeHtml(q)}" placeholder="companie, plătitor, referință">
        </div>
        <div>
          <label class="crm-label">Status</label>
          <select class="crm-input" name="status">
            <option value="all" ${!status || status === "all" ? "selected" : ""}>Toate</option>
            <option value="initiated" ${status === "initiated" ? "selected" : ""}>inițiată</option>
            <option value="processing" ${status === "processing" ? "selected" : ""}>în procesare</option>
            <option value="pending_verification" ${status === "pending_verification" ? "selected" : ""}>așteaptă verificare</option>
            <option value="paid" ${status === "paid" ? "selected" : ""}>reușită</option>
            <option value="failed" ${status === "failed" ? "selected" : ""}>eșuată</option>
          </select>
        </div>
        <div>
          <label class="crm-label">Sursă</label>
          <select class="crm-input" name="source">
            <option value="all" ${!source || source === "all" ? "selected" : ""}>Toate</option>
            <option value="stripe" ${source === "stripe" ? "selected" : ""}>Stripe</option>
            <option value="op" ${source === "op" ? "selected" : ""}>OP</option>
          </select>
        </div>
        <div>
          <label class="crm-label">Plan</label>
          <select class="crm-input" name="plan">
            <option value="all" ${!plan || plan === "all" ? "selected" : ""}>Toate planurile</option>
            ${planOptions.map((item) => `<option value="${escapeHtml(item.code || "")}" ${plan === String(item.code || "").toLowerCase() ? "selected" : ""}>${escapeHtml(item.name || item.code || "")}</option>`).join("")}
          </select>
        </div>
        <div>
          <label class="crm-label">Companie</label>
          <select class="crm-input" name="company_id">
            <option value="0" ${!companyFilter ? "selected" : ""}>Toate companiile</option>
            ${companies.map((item) => `<option value="${escapeHtml(String(item.id))}" ${companyFilter === Number(item.id) ? "selected" : ""}>${escapeHtml(item.name || "")}</option>`).join("")}
          </select>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end">
          <button class="crm-btn" type="submit">Aplică filtrele</button>
          <a class="crm-btn crm-btn-secondary" href="/super-admin/payments">Resetează</a>
        </div>
      </form>

      <div class="crm-table-wrap">
        <table class="crm-table">
          <thead>
            <tr>
              <th>Companie</th>
              <th>Sursă</th>
              <th>Status</th>
              <th>Sumă</th>
              <th>Plătitor</th>
              <th>Inițiat de</th>
              <th>Referință</th>
              <th>Plătită la</th>
              <th>Factură</th>
              <th>Detalii</th>
            </tr>
          </thead>
          <tbody>${paymentRows || `<tr><td colspan="10" class="crm-muted">Nu există plăți înregistrate.</td></tr>`}</tbody>
        </table>
      </div>
    </section>

    <section class="crm-card">
      <h3 style="margin:0 0 14px 0;font-size:20px">Înregistrează plată OP</h3>
      <div class="crm-muted" style="margin-bottom:14px">Folosește acest formular pentru companiile care plătesc prin ordin de plată și păstrezi evidența manuală în platformă.</div>
      <form method="post" action="/super-admin/payments/op" class="crm-stack">
        <div>
          <label class="crm-label">Companie</label>
          <select class="crm-input" name="company_id" required>
            <option value="">Alege compania</option>
            ${companies.map((item) => `<option value="${escapeHtml(String(item.id))}">${escapeHtml(item.name || "")}</option>`).join("")}
          </select>
        </div>
        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Sumă</label>
            <input class="crm-input" type="number" step="0.01" min="0" name="amount" required>
          </div>
          <div>
            <label class="crm-label">Monedă</label>
            <input class="crm-input" type="text" name="currency" value="RON" maxlength="8">
          </div>
        </div>
        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Plătitor</label>
            <input class="crm-input" type="text" name="payer_name" placeholder="nume firmă / persoană">
          </div>
          <div>
            <label class="crm-label">Email plătitor</label>
            <input class="crm-input" type="email" name="payer_email" placeholder="billing@companie.ro">
          </div>
        </div>
        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Referință OP</label>
            <input class="crm-input" type="text" name="reference_code" placeholder="nr. OP / explicație plată">
          </div>
          <div>
            <label class="crm-label">Status</label>
            <select class="crm-input" name="status">
              <option value="pending_verification">așteaptă verificare</option>
              <option value="paid">reușită</option>
              <option value="failed">eșuată</option>
            </select>
          </div>
        </div>
        <div>
          <label class="crm-label">Data plății</label>
          <input class="crm-input" type="datetime-local" name="paid_at">
        </div>
        <div>
          <label class="crm-label">Notițe</label>
          <textarea class="crm-input" name="notes" rows="4" placeholder="detalii OP, bancă, confirmări, extras"></textarea>
        </div>
        <div>
          <button class="crm-btn" type="submit">Salvează plata OP</button>
        </div>
      </form>

      <section class="crm-card" style="margin-top:18px">
        <h4 style="margin:0 0 12px 0;font-size:17px">Distribuție pe planuri</h4>
        <div class="crm-table-wrap">
          <table class="crm-table">
            <thead><tr><th>Plan</th><th>Plăți</th><th>Reușite</th></tr></thead>
            <tbody>${planRows || `<tr><td colspan="3" class="crm-muted">Nu există încă plăți agregate pe planuri.</td></tr>`}</tbody>
          </table>
        </div>
      </section>
    </section>
  </div>
${crmShellEnd()}
</html>
`;

  res.send(html);
});

app.post("/super-admin/payments/op", requireAuth, requireSuperAdmin, (req, res) => {
  const companyId = Number(req.body?.company_id || 0);
  const amount = Number(req.body?.amount || 0);
  const currency = String(req.body?.currency || "RON").trim().toUpperCase();
  const payerName = String(req.body?.payer_name || "").trim();
  const payerEmail = String(req.body?.payer_email || "").trim().toLowerCase();
  const referenceCode = String(req.body?.reference_code || "").trim();
  const status = String(req.body?.status || "pending_verification").trim().toLowerCase();
  const notes = String(req.body?.notes || "").trim();
  const paidAtRaw = String(req.body?.paid_at || "").trim();
  const paidAt = paidAtRaw ? new Date(paidAtRaw).toISOString() : (status === "paid" ? new Date().toISOString() : null);

  if (!Number.isFinite(companyId) || companyId <= 0) return res.status(400).send("Companie invalidă");
  if (!Number.isFinite(amount) || amount <= 0) return res.status(400).send("Sumă invalidă");
  if (!["pending_verification", "paid", "failed"].includes(status)) return res.status(400).send("Status invalid");

  const company = db.prepare(`
    SELECT id, name
    FROM companies
    WHERE id=?
  `).get(companyId);
  if (!company) return res.status(404).send("Company not found");

  const subscription = db.prepare(`
    SELECT id
    FROM company_subscriptions
    WHERE company_id=?
    ORDER BY id DESC
    LIMIT 1
  `).get(companyId);

  const insertResult = db.prepare(`
    INSERT INTO billing_payments (
      company_id, company_subscription_id, source, provider_event_type, payment_kind, status,
      amount, currency, payer_name, payer_email, reference_code, paid_at, notes,
      created_by_user_id, created_by_email, created_at, updated_at
    )
    VALUES (?, ?, 'op', 'manual_op_entry', 'subscription', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
  `).run(
    companyId,
    subscription?.id || null,
    status,
    amount,
    currency,
    payerName || null,
    payerEmail || null,
    referenceCode || null,
    paidAt,
    notes || null,
    Number(req.session.user.id || 0) || null,
    String(req.session.user.email || "")
  );
  const paymentId = Number(insertResult.lastInsertRowid || 0);

  syncManualPaymentToSubscription(companyId, status);
  if (paymentId && status === "paid") {
    maybeGenerateBillingInvoice(db, paymentId, { livemode: 1 });
  }
  logCompanyAdminEvent({
    companyId,
    actorUserId: Number(req.session.user.id || 0),
    actorEmail: req.session.user.email,
    eventType: "manual_payment_recorded",
    statusFrom: "",
    statusTo: status,
    reason: `OP ${referenceCode || "fără referință"}${notes ? ` | ${notes}` : ""}`
  });

  res.redirect("/super-admin/payments");
});


app.get("/setari", requireAuth,(req,res)=>{
const companyId = Number(req.session.user.company_id || 0);
const isCompanyAdmin = String(req.session.user.role || "").toLowerCase() === "admin" || Number(req.session.user.is_company_admin || 0) === 1;
const companyContext = getCompanySubscriptionContext(companyId);
const companyDetails = companyContext.company || {};
const activeSubscription = companyContext.subscription || null;
const activeModuleSet = new Set(companyContext.activeModules);
const companyStatus = String(companyDetails.status || activeSubscription?.status || "active").toLowerCase();
const stripeBillingConfigured = Boolean(String(process.env.STRIPE_SECRET_KEY || "").trim());
const stripeWebhookConfigured = Boolean(String(process.env.STRIPE_WEBHOOK_SECRET || "").trim());
const planOptions = companyContext.plans.map((plan) => {
  const planModules = parseJsonArray(plan.module_keys, []);
  const included = planModules
    .map((key) => MODULE_DEFINITIONS.find((item) => item.key === key)?.label || key)
    .join(", ");
  return `
    <label style="display:flex;gap:12px;align-items:flex-start;padding:14px 16px;border:1px solid ${activeSubscription?.plan_id === plan.id ? "var(--primary)" : "var(--line)"};border-radius:16px;background:${activeSubscription?.plan_id === plan.id ? "rgba(255,255,255,.98)" : "rgba(255,255,255,.82)"};box-shadow:${activeSubscription?.plan_id === plan.id ? "0 0 0 3px var(--theme-ring)" : "none"}">
      <input type="radio" name="plan_id" value="${plan.id}" ${activeSubscription?.plan_id === plan.id ? "checked" : ""} ${isCompanyAdmin ? "" : "disabled"}>
      <span>
        <span style="display:block;font-weight:800">${escapeHtml(plan.name)}</span>
        <span class="crm-muted" style="display:block;margin-top:4px">${escapeHtml(String(plan.price_monthly))} EUR / lună • ${escapeHtml(String(plan.max_users))} utilizatori</span>
        <span class="crm-muted" style="display:block;margin-top:6px;font-size:12px;line-height:1.45">${escapeHtml(included)}</span>
      </span>
    </label>
  `;
}).join("");
const groupedModuleCards = Object.entries(MODULE_GROUPS).map(([groupKey, moduleKeys]) => {
  const groupLabel = groupKey === "crm" ? "CRM" : groupKey === "erp" ? "ERP" : "Admin";
  const groupDescription = groupKey === "crm"
    ? "Lead-uri, relații comerciale și vânzare."
    : groupKey === "erp"
      ? "Operațional, facturare și resurse interne."
      : "Administrare, utilizatori și configurare.";
  const moduleItems = moduleKeys.map((moduleKey) => {
    const def = MODULE_DEFINITIONS.find((item) => item.key === moduleKey);
    const includedByPlan = companyContext.planModules.includes(moduleKey);
    const active = activeModuleSet.has(moduleKey);
    return `
      <label style="display:flex;align-items:flex-start;gap:10px;padding:12px 14px;border:1px solid var(--line);border-radius:14px;background:${active ? "rgba(255,255,255,.96)" : "rgba(248,250,252,.92)"};opacity:${includedByPlan ? "1" : ".65"}">
        <input type="checkbox" name="module_keys" value="${moduleKey}" ${active ? "checked" : ""} ${includedByPlan && isCompanyAdmin ? "" : "disabled"}>
        <span>
          <span style="display:block;font-weight:700">${escapeHtml(def?.label || moduleKey)}</span>
          <span class="crm-muted" style="display:block;margin-top:4px;font-size:12px">${includedByPlan ? "Disponibil în planul curent." : "Necesită upgrade de plan."}</span>
        </span>
      </label>
    `;
  }).join("");
  return `
    <div style="padding:16px;border:1px solid var(--line);border-radius:18px;background:rgba(255,255,255,.7)">
      <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:12px">
        <div>
          <div style="font-weight:800">${groupLabel}</div>
          <div class="crm-muted" style="margin-top:4px;font-size:13px">${groupDescription}</div>
        </div>
        <div class="crm-badge crm-badge-blue">${moduleKeys.filter((key) => activeModuleSet.has(key)).length}/${moduleKeys.length}</div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">
        ${moduleItems}
      </div>
    </div>
  `;
}).join("");

const html = `
<!doctype html>
<html>
<head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
.settings-launcher{
  display:grid;
  grid-template-columns:repeat(5,minmax(0,1fr));
  gap:14px;
  margin-bottom:18px;
}
.settings-tab{
  appearance:none;
  border:1px solid var(--line);
  background:linear-gradient(180deg,rgba(255,255,255,.96) 0%, rgba(248,250,252,.88) 100%);
  color:var(--text);
  border-radius:22px;
  padding:18px 18px;
  text-align:left;
  cursor:pointer;
  box-shadow:var(--shadow-soft);
  position:relative;
  overflow:hidden;
  transition:transform .14s ease,border-color .14s ease,box-shadow .14s ease,background .14s ease;
}
.settings-tab::before{
  content:"";
  position:absolute;
  inset:0 auto 0 0;
  width:4px;
  background:linear-gradient(180deg,var(--primary) 0%, var(--primary-2) 100%);
  opacity:.18;
  transition:opacity .14s ease, width .14s ease;
}
.settings-tab:hover{
  transform:translateY(-1px);
  border-color:var(--primary);
  box-shadow:0 14px 34px rgba(15,23,42,.10);
}
.settings-tab.active{
  border-color:var(--primary);
  box-shadow:0 0 0 4px var(--theme-ring), 0 18px 40px rgba(15,23,42,.10);
  background:linear-gradient(180deg,rgba(255,255,255,.99) 0%, rgba(242,248,255,.94) 100%);
}
.settings-tab.active::before{
  opacity:1;
  width:6px;
}
.settings-tab-head{
  display:flex;
  align-items:flex-start;
  gap:12px;
}
.settings-tab-icon{
  width:42px;
  height:42px;
  border-radius:14px;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  flex:0 0 auto;
  background:linear-gradient(135deg,var(--primary),var(--primary-2));
  color:#fff;
  box-shadow:0 10px 22px rgba(37,99,235,.22);
}
.settings-tab-icon svg{
  width:18px;
  height:18px;
  stroke:currentColor;
  fill:none;
  stroke-width:2;
  stroke-linecap:round;
  stroke-linejoin:round;
}
.settings-tab-copy{
  min-width:0;
}
.settings-tab-title{
  font-size:16px;
  font-weight:800;
}
.settings-tab-sub{
  margin-top:6px;
  color:var(--muted);
  font-size:13px;
  line-height:1.45;
}
.settings-panel{
  display:none;
}
.settings-panel.active{
  display:block;
  animation:settingsPanelIn .18s ease;
}
@keyframes settingsPanelIn{
  from{opacity:0;transform:translateY(4px)}
  to{opacity:1;transform:translateY(0)}
}
@media (max-width: 1100px){
  .settings-launcher{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media (max-width: 720px){
  .settings-launcher{grid-template-columns:1fr}
}
</style>
<meta charset="utf-8">
<title>Setări firmă</title>
</head>

${crmShellStart("setari", "Setări", "Configurare firmă, facturi și identitate vizuală.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

  <div class="settings-launcher">
    <button class="settings-tab active" type="button" data-settings-target="company">
      <div class="settings-tab-head">
        <span class="settings-tab-icon">
          <svg viewBox="0 0 24 24"><path d="M4 20V8l8-4 8 4v12"/><path d="M9 20v-5h6v5"/><path d="M8 10h.01"/><path d="M16 10h.01"/></svg>
        </span>
        <span class="settings-tab-copy">
          <div class="settings-tab-title">Date firmă</div>
          <div class="settings-tab-sub">Date comerciale, facturare și informațiile de bază ale companiei.</div>
        </span>
      </div>
    </button>
    <button class="settings-tab" type="button" data-settings-target="subscription">
      <div class="settings-tab-head">
        <span class="settings-tab-icon">
          <svg viewBox="0 0 24 24"><path d="M5 7h14"/><path d="M7 4h10v16H7z"/><path d="M9 11h6"/><path d="M9 15h4"/></svg>
        </span>
        <span class="settings-tab-copy">
          <div class="settings-tab-title">Abonament & module</div>
          <div class="settings-tab-sub">Planul companiei, modulele active CRM/ERP și limitele de utilizatori.</div>
        </span>
      </div>
    </button>
    <button class="settings-tab" type="button" data-settings-target="theme">
      <div class="settings-tab-head">
        <span class="settings-tab-icon">
          <svg viewBox="0 0 24 24"><path d="M12 3v3"/><path d="M12 18v3"/><path d="M3 12h3"/><path d="M18 12h3"/><path d="M5.6 5.6l2.1 2.1"/><path d="M16.3 16.3l2.1 2.1"/><path d="M18.4 5.6l-2.1 2.1"/><path d="M7.7 16.3l-2.1 2.1"/><circle cx="12" cy="12" r="4"/></svg>
        </span>
        <span class="settings-tab-copy">
          <div class="settings-tab-title">Temă interfață</div>
          <div class="settings-tab-sub">Alegi stilul vizual al aplicației și look-ul shell-ului.</div>
        </span>
      </div>
    </button>
    <button class="settings-tab" type="button" data-settings-target="logo">
      <div class="settings-tab-head">
        <span class="settings-tab-icon">
          <svg viewBox="0 0 24 24"><rect x="4" y="5" width="16" height="14" rx="2"/><circle cx="9" cy="10" r="1.5"/><path d="M20 16l-4.5-4.5L7 20"/></svg>
        </span>
        <span class="settings-tab-copy">
          <div class="settings-tab-title">Logo factură</div>
          <div class="settings-tab-sub">Upload pentru logo-ul folosit în PDF-urile de factură.</div>
        </span>
      </div>
    </button>
    <button class="settings-tab" type="button" data-settings-target="spv">
      <div class="settings-tab-head">
        <span class="settings-tab-icon">
          <svg viewBox="0 0 24 24"><path d="M4 6h16v12H4z"/><path d="M8 10h8"/><path d="M8 14h5"/></svg>
        </span>
        <span class="settings-tab-copy">
          <div class="settings-tab-title">Conectare SPV / e-Factura</div>
          <div class="settings-tab-sub">Setări ANAF, OAuth și acces rapid la inbox / outbox.</div>
        </span>
      </div>
    </button>
  </div>

  <div class="crm-grid" style="margin-bottom:18px">
    <section class="crm-card settings-panel active" data-settings-panel="company">
      <div style="margin-bottom:14px">
        <h3 style="margin:0;font-size:20px">Date firmă</h3>
        <div class="crm-muted" style="margin-top:6px">Informațiile folosite în documente și facturi.</div>
      </div>

      <form method="post" action="/setari" class="crm-stack">
        <div>
          <label class="crm-label">Nume firmă</label>
          <input class="crm-input" name="company_name" value="${escapeHtml(companyDetails.name || getSetting("company_name","QR-LAB SRL"))}">
        </div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">CUI</label>
            <input class="crm-input" name="company_cui" value="${escapeHtml(companyDetails.cui || getSetting("company_cui",""))}">
          </div>
          <div>
            <label class="crm-label">RC</label>
            <input class="crm-input" name="company_rc" value="${escapeHtml(companyDetails.rc || getSetting("company_rc",""))}">
          </div>
        </div>

        <div>
          <label class="crm-label">Adresă</label>
          <input class="crm-input" name="company_address" value="${escapeHtml(companyDetails.address || getSetting("company_address",""))}">
        </div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">IBAN</label>
            <input class="crm-input" name="company_iban" value="${escapeHtml(companyDetails.iban || getSetting("company_iban",""))}">
          </div>
          <div>
            <label class="crm-label">Banca</label>
            <input class="crm-input" name="company_bank" value="${escapeHtml(companyDetails.bank || getSetting("company_bank",""))}">
          </div>
        </div>

        <div>
          <label class="crm-label">Reprezentant</label>
          <input class="crm-input" name="company_rep" value="${escapeHtml(companyDetails.representative || getSetting("company_rep",""))}">
        </div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Serie facturi</label>
            <input class="crm-input" name="invoice_series" value="${getSetting("invoice_series","INV")}">
          </div>
          <div>
            <label class="crm-label">Culoare temă</label>
            <input class="crm-input" type="color" name="invoice_color" value="${getSetting("invoice_color","#39a935")}" style="min-height:46px;padding:6px">
          </div>
        </div>

        <div>
          <label class="crm-label">Capital social</label>
          <input class="crm-input" name="capital_social" value="${getSetting("capital_social","")}">
        </div>

        <div>
          <label class="crm-label">Text footer factură</label>
          <textarea class="crm-textarea" name="invoice_footer" rows="5">${getSetting("invoice_footer","Factura este valabila fara semnatura conform legii.")}</textarea>
        </div>

        <div>
          <button class="crm-btn" type="submit">Salvează setările</button>
        </div>
      </form>
    </section>

    <section class="crm-card settings-panel" data-settings-panel="subscription">
      <div style="margin-bottom:14px">
        <h3 style="margin:0;font-size:20px">Abonament & module</h3>
        <div class="crm-muted" style="margin-top:6px">Controlezi planul lunar și modulele active pentru compania curentă.</div>
      </div>

      <div class="crm-grid-2" style="overflow:visible;align-items:start">
        <div class="crm-stack">
          <div style="padding:18px;border:1px solid var(--line);border-radius:18px;background:rgba(255,255,255,.72)">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap">
              <div>
                <div style="font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted)">Companie</div>
                <div style="font-size:20px;font-weight:800;margin-top:6px">${escapeHtml(companyDetails.name || req.session.user.company_name || "Companie")}</div>
                <div class="crm-muted" style="margin-top:6px">CUI ${escapeHtml(companyDetails.cui || "neconfigurat")} • ${escapeHtml(companyStatus)}</div>
              </div>
              <div style="display:flex;gap:8px;flex-wrap:wrap">
                <div class="crm-badge crm-badge-green">${escapeHtml(activeSubscription?.plan_name || "Fără plan")}</div>
                ${companyStatusBadge(companyStatus)}
              </div>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-top:16px">
              <div style="padding:14px;border-radius:14px;background:rgba(248,250,252,.92)">
                <div class="crm-muted" style="font-size:12px">Utilizatori activi</div>
                <div style="font-size:24px;font-weight:800;margin-top:6px">${escapeHtml(String(activeSubscription?.seats_used ?? 0))}</div>
              </div>
              <div style="padding:14px;border-radius:14px;background:rgba(248,250,252,.92)">
                <div class="crm-muted" style="font-size:12px">Locuri incluse</div>
                <div style="font-size:24px;font-weight:800;margin-top:6px">${escapeHtml(String(activeSubscription?.seats_included ?? companyDetails.max_users ?? 0))}</div>
              </div>
              <div style="padding:14px;border-radius:14px;background:rgba(248,250,252,.92)">
                <div class="crm-muted" style="font-size:12px">Module active</div>
                <div style="font-size:24px;font-weight:800;margin-top:6px">${escapeHtml(String(companyContext.activeModules.length))}</div>
              </div>
            </div>
          </div>

          <form method="post" action="/setari/subscription" class="crm-stack">
            <div>
              <label class="crm-label">Planuri disponibile</label>
              <div class="crm-stack">${planOptions}</div>
            </div>
            <div style="display:flex;gap:10px;flex-wrap:wrap">
              <button class="crm-btn" type="submit" ${isCompanyAdmin ? "" : "disabled"}>Salvează abonamentul</button>
              ${!isCompanyAdmin ? `<span class="crm-muted">Doar administratorul companiei poate modifica abonamentul.</span>` : ``}
            </div>
          </form>

          <div style="padding:18px;border:1px solid var(--line);border-radius:18px;background:rgba(255,255,255,.72)">
            <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap">
              <div>
                <div style="font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted)">Stripe Billing</div>
                <div style="font-size:20px;font-weight:800;margin-top:6px">Plată abonament</div>
                <div class="crm-muted" style="margin-top:6px">Checkout securizat pentru planul curent și sincronizare automată în MiniCRM.</div>
              </div>
              <div style="display:flex;gap:8px;flex-wrap:wrap">
                ${stripeBillingConfigured ? `<span class="crm-badge crm-badge-green">Stripe conectat</span>` : `<span class="crm-badge crm-badge-red">Stripe neconfigurat</span>`}
                ${stripeWebhookConfigured ? `<span class="crm-badge crm-badge-blue">Webhook OK</span>` : `<span class="crm-badge crm-badge-amber">Webhook lipsă</span>`}
              </div>
            </div>

            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-top:16px">
              <div style="padding:14px;border-radius:14px;background:rgba(248,250,252,.92)">
                <div class="crm-muted" style="font-size:12px">Status plată</div>
                <div style="font-size:20px;font-weight:800;margin-top:6px">${escapeHtml(activeSubscription?.last_payment_status || "neinițiat")}</div>
              </div>
              <div style="padding:14px;border-radius:14px;background:rgba(248,250,252,.92)">
                <div class="crm-muted" style="font-size:12px">Monedă billing</div>
                <div style="font-size:20px;font-weight:800;margin-top:6px">${escapeHtml(String(activeSubscription?.billing_currency || process.env.STRIPE_CURRENCY || "eur").toUpperCase())}</div>
              </div>
              <div style="padding:14px;border-radius:14px;background:rgba(248,250,252,.92)">
                <div class="crm-muted" style="font-size:12px">Perioadă curentă până la</div>
                <div style="font-size:20px;font-weight:800;margin-top:6px">${escapeHtml(activeSubscription?.current_period_end || "—")}</div>
              </div>
            </div>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:16px">
              <a class="crm-btn" href="/billing/checkout">Plătește cu Stripe</a>
              <a class="crm-btn crm-btn-secondary" href="/billing/portal">Portal facturare</a>
              <a class="crm-btn crm-btn-secondary" href="/billing/status" target="_blank">Status JSON</a>
            </div>

            <div style="margin-top:14px" class="crm-muted">
              Configurează în server: <code>STRIPE_SECRET_KEY</code>, <code>STRIPE_WEBHOOK_SECRET</code>, opțional <code>STRIPE_CURRENCY</code> și <code>APP_URL</code>.
            </div>
          </div>
        </div>

        <form method="post" action="/setari/modules" class="crm-stack">
          <div>
            <label class="crm-label">Module active pentru companie</label>
            <div class="crm-muted" style="margin-bottom:12px">Poți activa doar module incluse în planul curent. Drepturile pe utilizator rămân în <code>Utilizatori</code>.</div>
            <div class="crm-stack">
              ${groupedModuleCards}
            </div>
          </div>
          <div style="padding:16px;border:1px dashed #cbd5e1;border-radius:14px;background:#f8fafc">
            <div style="font-weight:800;margin-bottom:8px">Cum funcționează</div>
            <div class="crm-muted">
              Abonamentul definește plafonul de module disponibile. Aici alegi ce rămâne activ pentru companie, iar apoi în <code>Utilizatori</code> controlezi ce vede fiecare persoană din echipă.
            </div>
          </div>
          <div>
            <button class="crm-btn" type="submit" ${isCompanyAdmin ? "" : "disabled"}>Salvează modulele active</button>
          </div>
        </form>
      </div>
    </section>

    <section class="crm-card settings-panel" data-settings-panel="logo">
      <div style="margin-bottom:14px">
        <h3 style="margin:0;font-size:20px">Logo factură</h3>
        <div class="crm-muted" style="margin-top:6px">Fișierul va fi salvat ca <code>public/invoice-logo.png</code>.</div>
      </div>

      <form method="post" action="/setari/logo" enctype="multipart/form-data" class="crm-stack">
        <div>
          <label class="crm-label">Selectează logo</label>
          <input class="crm-input" type="file" name="logo">
        </div>
        <div>
          <button class="crm-btn" type="submit">Upload logo</button>
        </div>
      </form>

      <div style="margin-top:18px;padding:16px;border:1px dashed #cbd5e1;border-radius:14px;background:#f8fafc">
        <div style="font-weight:800;margin-bottom:8px">Recomandare</div>
        <div class="crm-muted">
          Pentru rezultat bun în PDF, folosește un PNG cu fundal transparent și lățime rezonabilă.
        </div>
      </div>
    </section>

    <section class="crm-card settings-panel" data-settings-panel="spv">
      <div style="margin-bottom:14px">
        <h3 style="margin:0;font-size:20px">Conectare SPV / e-Factura</h3>
        <div class="crm-muted" style="margin-top:6px">Pregătire integrare directă ANAF pentru autorizare SPV, trimitere și recepție e-Factura.</div>
      </div>

      <form method="post" action="/setari" class="crm-stack">
        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Mediu ANAF</label>
            <select class="crm-input" name="anaf_environment">
              <option value="test" ${getSetting("anaf_environment","test") === "test" ? "selected" : ""}>test</option>
              <option value="prod" ${getSetting("anaf_environment","test") === "prod" ? "selected" : ""}>prod</option>
            </select>
          </div>
          <div>
            <label class="crm-label">Redirect URI</label>
            <input class="crm-input" name="anaf_redirect_uri" value="${escapeHtml(getSetting("anaf_redirect_uri","https://minicrm.qr-lab.ro/oauth/anaf/callback"))}">
          </div>
        </div>

        <div>
          <label class="crm-label">Client ID aplicație</label>
          <input class="crm-input" name="anaf_client_id" value="${escapeHtml(getSetting("anaf_client_id",""))}" placeholder="Client ID primit de la ANAF">
        </div>

        <div>
          <label class="crm-label">Client Secret aplicație</label>
          <input class="crm-input" type="password" name="anaf_client_secret" value="${escapeHtml(getSetting("anaf_client_secret",""))}" placeholder="Client Secret primit de la ANAF">
        </div>

        <div style="padding:16px;border:1px dashed #cbd5e1;border-radius:14px;background:#f8fafc">
          <div style="font-weight:800;margin-bottom:8px">Status infrastructură</div>
          <div class="crm-muted">
            Modulul e-Factura are acum fluxul OAuth SPV pregătit. După configurarea aplicației în ANAF, poți porni autorizarea direct din MiniCRM.
          </div>
        </div>

        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button class="crm-btn" type="submit">Salvează setările ANAF</button>
          <a class="crm-btn" href="/oauth/anaf/start">Conectează SPV</a>
          <a class="crm-btn crm-btn-secondary" href="/anaf/status">Status ANAF</a>
          <a class="crm-btn crm-btn-secondary" href="/anaf/inbox">Inbox e-Factura</a>
          <a class="crm-btn crm-btn-secondary" href="/anaf/outbox">Outbox e-Factura</a>
        </div>
      </form>
    </section>
  </div>

${crmShellEnd()}
<script>
  (function(){
    const tabs = Array.from(document.querySelectorAll("[data-settings-target]"));
    const panels = Array.from(document.querySelectorAll("[data-settings-panel]"));

    function openPanel(target){
      tabs.forEach((tab) => {
        tab.classList.toggle("active", tab.getAttribute("data-settings-target") === target);
      });
      panels.forEach((panel) => {
        panel.classList.toggle("active", panel.getAttribute("data-settings-panel") === target);
      });
    }

    tabs.forEach((tab) => {
      tab.addEventListener("click", () => openPanel(tab.getAttribute("data-settings-target")));
    });
  })();
</script>
</html>
`;

res.send(html);
});


app.post("/setari", requireAuth,(req,res)=>{
const companyId = Number(req.session.user.company_id || 0);

for(const k of Object.keys(req.body)){
setSetting(k,req.body[k]);
}

if (companyId) {
  db.prepare(`
    UPDATE companies
    SET name=?,
        cui=?,
        rc=?,
        address=?,
        bank=?,
        iban=?,
        representative=?,
        updated_at=datetime('now')
    WHERE id=?
  `).run(
    String(req.body?.company_name || "").trim(),
    String(req.body?.company_cui || "").trim(),
    String(req.body?.company_rc || "").trim(),
    String(req.body?.company_address || "").trim(),
    String(req.body?.company_bank || "").trim(),
    String(req.body?.company_iban || "").trim(),
    String(req.body?.company_rep || "").trim(),
    companyId
  );
  refreshSessionCompanyAccess(req);
}

res.redirect("/setari");
});

app.post("/setari/subscription", requireAuth, requireRole("admin"), (req, res) => {
  const companyId = Number(req.session.user.company_id || 0);
  const planId = Number(req.body?.plan_id);
  if (!companyId || !Number.isFinite(planId)) return res.status(400).send("Plan invalid");

  const plan = db.prepare(`
    SELECT id, max_users, module_keys
    FROM plans
    WHERE id=? AND status='active'
  `).get(planId);
  if (!plan) return res.status(404).send("Plan not found");

  const currentSubscription = db.prepare(`
    SELECT id, module_overrides
    FROM company_subscriptions
    WHERE company_id=?
    ORDER BY id DESC
    LIMIT 1
  `).get(companyId);
  if (!currentSubscription) return res.status(404).send("Subscription not found");
  const planModules = parseJsonArray(plan.module_keys, []);
  const existingOverrides = parseJsonArray(currentSubscription?.module_overrides, planModules);
  const nextOverrides = existingOverrides.filter((key) => planModules.includes(key));

  db.prepare(`
    UPDATE company_subscriptions
    SET plan_id=?,
        seats_included=?,
        module_overrides=?,
        updated_at=datetime('now')
    WHERE id=?
  `).run(
    plan.id,
    Math.max(Number(plan.max_users || 1), 1),
    JSON.stringify(nextOverrides.length ? nextOverrides : planModules),
    currentSubscription?.id
  );

  db.prepare(`
    UPDATE companies
    SET max_users=?,
        updated_at=datetime('now')
    WHERE id=?
  `).run(Math.max(Number(plan.max_users || 1), 1), companyId);

  refreshSessionCompanyAccess(req);
  res.redirect("/setari");
});

app.post("/setari/modules", requireAuth, requireRole("admin"), (req, res) => {
  const companyId = Number(req.session.user.company_id || 0);
  if (!companyId) return res.status(400).send("Companie invalidă");

  let moduleKeys = req.body?.module_keys || [];
  if (!Array.isArray(moduleKeys)) moduleKeys = [moduleKeys];
  moduleKeys = moduleKeys.map(String);

  const { subscription, planModules } = getCompanySubscriptionContext(companyId);
  if (!subscription) return res.status(404).send("Subscription not found");

  const nextModules = moduleKeys.filter((key) => planModules.includes(key));

  db.prepare(`
    UPDATE company_subscriptions
    SET module_overrides=?,
        updated_at=datetime('now')
    WHERE id=?
  `).run(JSON.stringify(nextModules), subscription.id);

  refreshSessionCompanyAccess(req);
  res.redirect("/setari");
});


app.post("/setari/logo", requireAuth, upload.single("logo"),(req,res)=>{

if(!req.file) return res.redirect("/setari");

const dest="public/invoice-logo.png";

fs.renameSync(req.file.path,dest);

res.redirect("/setari");

});


app.get("/anaf/status", requireAuth, (req,res)=>{
  const companyId = Number(req.session.user.company_id || 0);
  const oauthState = String(req.query.oauth || "");
  const oauthMessage = String(req.query.message || "");
  const environment = String(getSetting("anaf_environment","test") || "test").trim() || "test";
  const redirectUri = String(getSetting("anaf_redirect_uri","https://minicrm.qr-lab.ro/oauth/anaf/callback") || "").trim();
  const authorizeUrl = String(getSetting("anaf_authorize_url","https://logincert.anaf.ro/anaf-oauth2/v1/authorize") || "https://logincert.anaf.ro/anaf-oauth2/v1/authorize").trim();
  const tokenUrl = String(getSetting("anaf_token_url","https://logincert.anaf.ro/anaf-oauth2/v1/token") || "https://logincert.anaf.ro/anaf-oauth2/v1/token").trim();
  const efacturaApiBase = `https://api.anaf.ro/${environment === "prod" ? "prod" : "test"}/FCTEL/rest`;
  const connectionCounts = db.prepare(`
    SELECT environment, COUNT(*) c
    FROM anaf_connections
    WHERE company_id=?
    GROUP BY environment
  `).all(companyId);
  const connectionCountMap = Object.fromEntries(
    connectionCounts.map((row) => [String(row.environment || "").trim(), Number(row.c || 0)])
  );
  const latestConnections = db.prepare(`
    SELECT environment, serial_certificate, expires_at, updated_at
    FROM anaf_connections
    WHERE company_id=?
    ORDER BY id DESC
  `).all(companyId);
  const latestTestConnection = latestConnections.find((row) => String(row.environment || "").trim() === "test");
  const latestProdConnection = latestConnections.find((row) => String(row.environment || "").trim() === "prod");
  const lastOauthLog = db.prepare(`
    SELECT event_type, status, details, created_at
    FROM anaf_oauth_logs
    WHERE company_id=?
    ORDER BY id DESC
    LIMIT 1
  `).get(companyId);
  const oauthBanner = oauthState
    ? `
      <div class="crm-card" style="margin-bottom:16px;border:${oauthState === "success" ? "1px solid #86efac;background:#f0fdf4" : "1px solid #fecaca;background:#fef2f2"}">
        <div style="font-weight:800;margin-bottom:6px">${oauthState === "success" ? "Conectare ANAF reușită" : "Conectare ANAF eșuată"}</div>
        <div>${escapeHtml(oauthMessage || (oauthState === "success" ? "Conexiunea a fost salvată." : "A apărut o eroare la autorizare."))}</div>
      </div>
    `
    : "";
  const environmentBanner = environment === "prod"
    ? `
      <div class="crm-card" style="margin-bottom:16px;border:1px solid #86efac;background:#f0fdf4">
        <div style="font-weight:800;margin-bottom:6px">Mediu activ: PRODUCȚIE</div>
        <div>Aplicația este setată pe producție. Trimiterile e-Factura sunt reale și pot ajunge în SPV producție.</div>
      </div>
    `
    : `
      <div class="crm-card" style="margin-bottom:16px;border:1px solid #93c5fd;background:#eff6ff">
        <div style="font-weight:800;margin-bottom:6px">Mediu activ: TEST</div>
        <div>Aplicația este setată pe test. Facturile trimise din acest mod nu trebuie considerate trimiteri reale în SPV producție.</div>
      </div>
    `;
  const html = `
  <!doctype html>
  <html>
  <head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
  <meta charset="utf-8">
  <title>Status ANAF</title>
  </head>
  ${crmShellStart("accounting-spv", "Status ANAF", "Stare integrare SPV și e-Factura.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

    ${oauthBanner}
    ${environmentBanner}

    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <h3 style="margin:0 0 12px 0;font-size:20px">Status integrare</h3>
      <div class="crm-stack">
        <div><b>Mediu activ:</b> ${escapeHtml(environment)} ${environment === "test" ? '<span class="crm-badge crm-badge-blue" style="margin-left:8px">TEST</span>' : '<span class="crm-badge crm-badge-green" style="margin-left:8px">PROD</span>'}</div>
        <div><b>Redirect URI:</b> ${escapeHtml(redirectUri)}</div>
        <div><b>Client ID:</b> ${getSetting("anaf_client_id","") ? "configurat" : "neconfigurat"}</div>
        <div><b>Client Secret:</b> ${getSetting("anaf_client_secret","") ? "configurat" : "neconfigurat"}</div>
        <div><b>Conexiuni SPV salvate:</b> ${db.prepare("SELECT COUNT(*) c FROM anaf_connections WHERE company_id=?").get(companyId).c}</div>
        <div><b>Conexiuni SPV test:</b> ${connectionCountMap.test || 0}</div>
        <div><b>Conexiuni SPV producție:</b> ${connectionCountMap.prod || 0}</div>
        <div><b>Endpoint autorizare OAuth:</b> ${escapeHtml(authorizeUrl)}</div>
        <div><b>Endpoint token OAuth:</b> ${escapeHtml(tokenUrl)}</div>
        <div><b>Endpoint e-Factura:</b> ${escapeHtml(efacturaApiBase)}</div>
        <div><b>Ultima conexiune test:</b> ${latestTestConnection ? `${escapeHtml(latestTestConnection.updated_at || "-")} / serial ${escapeHtml((latestTestConnection.serial_certificate || "").slice(0, 24) || "-")}` : "niciuna"}</div>
        <div><b>Ultima conexiune producție:</b> ${latestProdConnection ? `${escapeHtml(latestProdConnection.updated_at || "-")} / serial ${escapeHtml((latestProdConnection.serial_certificate || "").slice(0, 24) || "-")}` : "niciuna"}</div>
        <div><b>Ultimul eveniment OAuth:</b> ${lastOauthLog ? `${escapeHtml(lastOauthLog.event_type || "-")} / ${escapeHtml(lastOauthLog.status || "-")} / ${escapeHtml(lastOauthLog.created_at || "-")}` : "niciunul"}</div>
        <div><b>Detaliu:</b> ${lastOauthLog?.details ? escapeHtml(String(lastOauthLog.details).slice(0, 500)) : "—"}</div>
        <div style="padding-top:12px">
          <a class="crm-btn" href="/oauth/anaf/start">Conectează contul ANAF</a>
        </div>
      </div>
    </section>

  ${crmShellEnd()}
  </html>`;
  res.send(html);
});

app.post("/anaf/inbox/:id/process", requireAuth, (req, res) => {
  const companyId = Number(req.session.user.company_id || 0);
  const id = Number(req.params.id || 0);
  if (!id) return res.status(400).send("ID invalid");

  const row = db.prepare(`
    SELECT id, processed
    FROM anaf_inbox
    WHERE id=? AND company_id=?
  `).get(id, companyId);

  if (!row) return res.status(404).send("Mesajul nu exista");

  const nextProcessed = String(req.body?.processed || "") === "1" ? 1 : 0;
  db.prepare(`
    UPDATE anaf_inbox
    SET processed=?
    WHERE id=? AND company_id=?
  `).run(nextProcessed, id, companyId);

  const redirectTo = String(req.body?.redirect_to || "").trim();
  if (redirectTo && redirectTo.startsWith("/")) return res.redirect(redirectTo);
  return res.redirect("/anaf/inbox");
});

app.get("/anaf/inbox", requireAuth, (req,res)=>{
  const companyId = Number(req.session.user.company_id || 0);
  const processedFilter = String(req.query?.processed || "").trim().toLowerCase();
  const search = String(req.query?.search || "").trim();
  const dateFrom = /^\d{4}-\d{2}-\d{2}$/.test(String(req.query?.date_from || "").trim()) ? String(req.query.date_from).trim() : "";
  const dateTo = /^\d{4}-\d{2}-\d{2}$/.test(String(req.query?.date_to || "").trim()) ? String(req.query.date_to).trim() : "";

  const where = ["company_id=?"];
  const params = [companyId];

  if (processedFilter === "processed") {
    where.push("processed=1");
  } else if (processedFilter === "new") {
    where.push("processed=0");
  }

  if (dateFrom) {
    where.push("date(COALESCE(received_at, created_at)) >= date(?)");
    params.push(dateFrom);
  }

  if (dateTo) {
    where.push("date(COALESCE(received_at, created_at)) <= date(?)");
    params.push(dateTo);
  }

  if (search) {
    const like = `%${search.toLowerCase()}%`;
    where.push("(LOWER(COALESCE(supplier_cui,'')) LIKE ? OR LOWER(COALESCE(invoice_number,'')) LIKE ? OR LOWER(COALESCE(xml_path,'')) LIKE ? OR LOWER(COALESCE(pdf_path,'')) LIKE ?)");
    params.push(like, like, like, like);
  }

  const whereSql = where.join(" AND ");

  const rows = db.prepare(`
    SELECT id, supplier_cui, invoice_number, xml_path, pdf_path, received_at, processed, created_at
    FROM anaf_inbox
    WHERE ${whereSql}
    ORDER BY COALESCE(received_at, created_at) DESC, id DESC
    LIMIT 200
  `).all(...params);

  const stats = db.prepare(`
    SELECT
      COUNT(*) AS total_count,
      SUM(CASE WHEN processed=0 THEN 1 ELSE 0 END) AS new_count,
      SUM(CASE WHEN processed=1 THEN 1 ELSE 0 END) AS processed_count
    FROM anaf_inbox
    WHERE company_id=?
  `).get(companyId) || {};

  const filteredStats = db.prepare(`
    SELECT
      COUNT(*) AS total_count,
      SUM(CASE WHEN processed=0 THEN 1 ELSE 0 END) AS new_count
    FROM anaf_inbox
    WHERE ${whereSql}
  `).get(...params) || {};

  const currentQuery = new URLSearchParams();
  if (processedFilter) currentQuery.set("processed", processedFilter);
  if (search) currentQuery.set("search", search);
  if (dateFrom) currentQuery.set("date_from", dateFrom);
  if (dateTo) currentQuery.set("date_to", dateTo);
  const currentPath = `/anaf/inbox${currentQuery.toString() ? `?${currentQuery.toString()}` : ""}`;

  function processedBadge(value){
    return Number(value)
      ? `<span class="crm-badge crm-badge-green">procesată</span>`
      : `<span class="crm-badge crm-badge-blue">nouă</span>`;
  }

  function filterBtn(label, value){
    const active = (value === "" && !processedFilter) || value === processedFilter;
    const next = new URLSearchParams();
    if (value) next.set("processed", value);
    if (search) next.set("search", search);
    if (dateFrom) next.set("date_from", dateFrom);
    if (dateTo) next.set("date_to", dateTo);
    const href = `/anaf/inbox${next.toString() ? `?${next.toString()}` : ""}`;
    return `<a class="${active ? "crm-btn" : "crm-btn crm-btn-secondary"}" href="${href}">${escapeHtml(label)}</a>`;
  }

  const htmlRows = rows.map(r => `
    <tr>
      <td>${escapeHtml(String(r.id))}</td>
      <td>
        <div style="font-weight:800">${escapeHtml(r.invoice_number || "Fără număr")}</div>
        <div class="crm-muted" style="margin-top:4px">${escapeHtml(r.supplier_cui || "—")}</div>
      </td>
      <td>${escapeHtml(r.received_at || r.created_at || "")}</td>
      <td>${processedBadge(r.processed)}</td>
      <td>
        <div style="display:grid;gap:6px">
          ${r.xml_path ? `<a href="/${encodeURI(r.xml_path)}" target="_blank">XML</a>` : `<span class="crm-muted">XML lipsă</span>`}
          ${r.pdf_path ? `<a href="/${encodeURI(r.pdf_path)}" target="_blank">PDF</a>` : `<span class="crm-muted">PDF lipsă</span>`}
        </div>
      </td>
      <td>
        <form method="post" action="/anaf/inbox/${r.id}/process" style="margin:0;display:flex;gap:8px;flex-wrap:wrap">
          <input type="hidden" name="processed" value="${Number(r.processed) ? "0" : "1"}">
          <input type="hidden" name="redirect_to" value="${escapeHtml(currentPath)}">
          <button class="crm-btn ${Number(r.processed) ? "crm-btn-secondary" : ""}" type="submit">${Number(r.processed) ? "Marchează nouă" : "Marchează procesată"}</button>
          ${r.xml_path ? `<a class="crm-btn crm-btn-secondary" href="/${encodeURI(r.xml_path)}" target="_blank">Deschide XML</a>` : ``}
        </form>
      </td>
    </tr>
  `).join("");

  const html = `
  <!doctype html>
  <html>
  <head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
  <meta charset="utf-8">
  <title>Inbox e-Factura</title>
  </head>
  ${crmShellStart("accounting-spv-inbox", "Inbox e-Factura", "Facturi primite din ANAF.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px">
        <div>
          <h3 style="margin:0;font-size:20px">Inbox e-Factura</h3>
          <div class="crm-muted" style="margin-top:6px">Mesaje/facturi primite prin integrarea ANAF, cu status operațional pentru lucru contabil.</div>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <a class="crm-btn crm-btn-secondary" href="/accounting">Contabilitate</a>
          <a class="crm-btn crm-btn-secondary" href="/anaf/status">Status ANAF</a>
        </div>
      </div>

      <div class="crm-kpis" style="grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-bottom:18px">
        <div class="crm-kpi">
          <div class="crm-kpi-label">Total inbox</div>
          <div class="crm-kpi-value">${escapeHtml(String(stats.total_count || 0))}</div>
        </div>
        <div class="crm-kpi">
          <div class="crm-kpi-label">Noi</div>
          <div class="crm-kpi-value">${escapeHtml(String(stats.new_count || 0))}</div>
        </div>
        <div class="crm-kpi">
          <div class="crm-kpi-label">În selecție</div>
          <div class="crm-kpi-value">${escapeHtml(String(filteredStats.total_count || 0))}</div>
          <div class="crm-muted" style="margin-top:6px">${escapeHtml(String(filteredStats.new_count || 0))} noi</div>
        </div>
      </div>

      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px">
        ${filterBtn("Toate", "")}
        ${filterBtn("Noi", "new")}
        ${filterBtn("Procesate", "processed")}
      </div>

      <form method="get" action="/anaf/inbox" class="crm-grid-4" style="margin-bottom:18px;overflow:visible">
        <input type="hidden" name="processed" value="${escapeHtml(processedFilter)}">
        <div>
          <label class="crm-label">De la</label>
          <input class="crm-input" type="date" name="date_from" value="${escapeHtml(dateFrom)}">
        </div>
        <div>
          <label class="crm-label">Până la</label>
          <input class="crm-input" type="date" name="date_to" value="${escapeHtml(dateTo)}">
        </div>
        <div style="grid-column:span 2">
          <label class="crm-label">Căutare</label>
          <input class="crm-input" name="search" value="${escapeHtml(search)}" placeholder="CUI furnizor, nr. factură sau fișier">
        </div>
        <div style="grid-column:1 / -1;display:flex;gap:10px;flex-wrap:wrap">
          <button class="crm-btn" type="submit">Aplică filtrele</button>
          <a class="crm-btn crm-btn-secondary" href="/anaf/inbox">Resetează</a>
        </div>
      </div>

      <div class="crm-table-wrap">
        <table class="crm-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Document</th>
              <th>Recepționată</th>
              <th>Status</th>
              <th>Fișiere</th>
              <th>Acțiuni</th>
            </tr>
          </thead>
          <tbody>
            ${htmlRows || `<tr><td colspan="6" class="crm-muted">Nu există mesaje în inbox pentru filtrele selectate.</td></tr>`}
          </tbody>
        </table>
      </div>
    </section>

  ${crmShellEnd()}
  </html>`;
  res.send(html);
});

app.get("/anaf/outbox", requireAuth, (req,res)=>{
  const companyId = Number(req.session.user.company_id || 0);
  const allowedStatuses = ["PREGATIT_PENTRU_TRIMITERE", "TRIMIS", "LIVRAT", "EROARE"];
  const statusFilter = String(req.query?.status || "").trim().toUpperCase();
  const hasStatusFilter = allowedStatuses.includes(statusFilter);

  const rows = hasStatusFilter
    ? db.prepare(`
        SELECT
          m.id,
          m.message_id,
          m.factura_id,
          m.direction,
          m.status,
          m.created_at,
          f.factura_nr,
          f.efactura_xml_path
        FROM anaf_messages m
        LEFT JOIN facturi f ON f.id = m.factura_id AND f.company_id = m.company_id
        WHERE m.company_id = ? AND UPPER(COALESCE(m.status,'')) = ?
        ORDER BY m.id DESC
        LIMIT 100
      `).all(companyId, statusFilter)
    : db.prepare(`
        SELECT
          m.id,
          m.message_id,
          m.factura_id,
          m.direction,
          m.status,
          m.created_at,
          f.factura_nr,
          f.efactura_xml_path
        FROM anaf_messages m
        LEFT JOIN facturi f ON f.id = m.factura_id AND f.company_id = m.company_id
        WHERE m.company_id = ?
        ORDER BY m.id DESC
        LIMIT 100
      `).all(companyId);

  function outboxDirectionBadge(direction){
    const v = String(direction || "").toUpperCase();
    if(v === "OUT") return `<span class="crm-badge crm-badge-blue">OUT</span>`;
    if(v === "IN") return `<span class="crm-badge crm-badge-green">IN</span>`;
    return `<span class="crm-badge crm-badge-neutral">${escapeHtml(direction || "—")}</span>`;
  }

  function outboxStatusBadge(status){
    const v = String(status || "").toUpperCase();
    if(v === "PREGATIT_PENTRU_TRIMITERE") return `<span class="crm-badge crm-badge-amber">pregătit</span>`;
    if(v === "TRIMIS") return `<span class="crm-badge crm-badge-blue">trimis</span>`;
    if(v === "LIVRAT") return `<span class="crm-badge crm-badge-green">livrat</span>`;
    if(v === "EROARE") return `<span class="crm-badge crm-badge-red">eroare</span>`;
    return `<span class="crm-badge crm-badge-neutral">${escapeHtml(status || "—")}</span>`;
  }

  function filterBtn(label, status){
    const active = (status === "" && !hasStatusFilter) || (status === statusFilter);
    const href = status ? `/anaf/outbox?status=${encodeURIComponent(status)}` : `/anaf/outbox`;
    const cls = active ? "crm-btn" : "crm-btn crm-btn-secondary";
    return `<a class="${cls}" href="${href}">${escapeHtml(label)}</a>`;
  }

  const htmlRows = rows.map(r => `
    <tr>
      <td>${r.factura_id ? `<a href="/factura/${r.factura_id}">${escapeHtml(r.factura_nr || ("#" + String(r.factura_id)))}</a>` : `<span class="crm-muted">—</span>`}</td>
      <td>${outboxDirectionBadge(r.direction)}</td>
      <td>${outboxStatusBadge(r.status)}</td>
      <td>${escapeHtml(r.message_id || "")}</td>
      <td>${escapeHtml(r.created_at || "")}</td>
      <td>${r.efactura_xml_path ? escapeHtml(r.efactura_xml_path) : `<span class="crm-muted">—</span>`}</td>
    </tr>
  `).join("");

  const html = `
  <!doctype html>
  <html>
  <head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
  <meta charset="utf-8">
  <title>Outbox e-Factura</title>
  </head>
  ${crmShellStart("accounting-spv-outbox", "Outbox e-Factura", "Mesajele pregătite / trimise către ANAF.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px">
        <div>
          <h3 style="margin:0;font-size:20px">Outbox e-Factura</h3>
          <div class="crm-muted" style="margin-top:6px">Ultimele 100 mesaje din jurnalul ANAF outbox.</div>
        </div>
      </div>

      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
        ${filterBtn("Toate", "")}
        ${filterBtn("Pregătit", "PREGATIT_PENTRU_TRIMITERE")}
        ${filterBtn("Trimis", "TRIMIS")}
        ${filterBtn("Livrat", "LIVRAT")}
        ${filterBtn("Eroare", "EROARE")}
      </div>

      <div class="crm-table-wrap">
        <table class="crm-table">
          <thead>
            <tr>
              <th>Factură</th>
              <th>Direcție</th>
              <th>Status</th>
              <th>Message ID</th>
              <th>Creat la</th>
              <th>XML</th>
            </tr>
          </thead>
          <tbody>
            ${htmlRows || `<tr><td colspan="6" class="crm-muted">Nu există mesaje în outbox.</td></tr>`}
          </tbody>
        </table>
      </div>
    </section>

  ${crmShellEnd()}
  </html>`;
  res.send(html);
});




/* =========================
   EMPLOYEES MODULE
========================= */

app.get("/employees", requireAuth, requireModule("employees"), (req, res) => {
  const companyId = Number(req.session.user.company_id || 0);

  const rows = db.prepare(`
    SELECT id, name, email, phone, position, active, created_at
    FROM employees
    WHERE company_id=?
    ORDER BY active DESC, name COLLATE NOCASE ASC
  `).all(companyId);

  const htmlRows = rows.map(r => `
    <tr>
      <td>${escapeHtml(r.name || "")}</td>
      <td>${escapeHtml(r.email || "")}</td>
      <td>${escapeHtml(r.phone || "")}</td>
      <td>${escapeHtml(r.position || "")}</td>
      <td>${Number(r.active) ? `<span class="crm-badge crm-badge-green">activ</span>` : `<span class="crm-badge crm-badge-neutral">inactiv</span>`}</td>
      <td>${escapeHtml(r.created_at || "")}</td>
    </tr>
  `).join("");

  res.type("html").send(`
<!doctype html>
<html>
<head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<meta charset="utf-8">
<title>Angajați</title>
</head>

${crmShellStart("employees","Angajați","Administrare personal și operatori.",req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

<section class="crm-card" style="position:sticky;top:20px;z-index:10">

<div style="margin-bottom:14px">
<h3 style="margin:0;font-size:20px">Adaugă angajat</h3>
</div>

<form method="post" action="/employees/create" class="crm-grid-2" style="overflow:visible" style="margin-bottom:18px">

<div>
<label class="crm-label">Nume</label>
<input class="crm-input" name="name" required>
</div>

<div>
<label class="crm-label">Email</label>
<input class="crm-input" name="email">
</div>

<div>
<label class="crm-label">Telefon</label>
<input class="crm-input" name="phone">
</div>

<div>
<label class="crm-label">Funcție</label>
<input class="crm-input" name="position">
</div>

<div>
<label class="crm-label">Activ</label>
<select class="crm-input" name="active">
<option value="1">DA</option>
<option value="0">NU</option>
</select>
</div>

<div style="grid-column:1/-1">
<button class="crm-btn" type="submit">Adaugă angajat</button>
</div>

</form>

<div style="overflow:auto">

<table class="crm-table">
<thead>
<tr>
<th>Nume</th>
<th>Email</th>
<th>Telefon</th>
<th>Funcție</th>
<th>Status</th>
<th>Creat</th>
</tr>
</thead>

<tbody>
${htmlRows || `<tr><td colspan="6" class="crm-muted">Nu există angajați.</td></tr>`}
</tbody>

</table>

</div>

</section>

${crmShellEnd()}

</html>
`);
});


app.post("/employees/create", requireAuth, requireModule("employees"), (req, res) => {
  const companyId = Number(req.session.user.company_id || 0);

  const name = String(req.body?.name || "").trim();
  const email = String(req.body?.email || "").trim();
  const phone = String(req.body?.phone || "").trim();
  const position = String(req.body?.position || "").trim();
  const active = String(req.body?.active || "1") === "1" ? 1 : 0;

  if(!name){
    return res.status(400).send("Nume obligatoriu");
  }

  db.prepare(`
    INSERT INTO employees (name,email,phone,position,active,company_id)
    VALUES (?,?,?,?,?,?)
  `).run(name,email,phone,position,active,companyId);

  res.redirect("/employees");

});
