import crypto from "crypto";

const DEFAULT_ANAF_REDIRECT_URI = "https://minicrm.qr-lab.ro/oauth/anaf/callback";
const DEFAULT_ANAF_AUTHORIZE_URL = "https://logincert.anaf.ro/anaf-oauth2/v1/authorize";
const DEFAULT_ANAF_TOKEN_URL = "https://logincert.anaf.ro/anaf-oauth2/v1/token";

function buildRedirectUrl(basePath, status, message) {
  const params = new URLSearchParams();
  params.set("oauth", status);
  if (message) params.set("message", message);
  return `${basePath}?${params.toString()}`;
}

function safeJson(value) {
  try {
    return JSON.stringify(value);
  } catch {
    return "";
  }
}

function logOauthEvent(db, companyId, eventType, status, details, query) {
  db.prepare(`
    INSERT INTO anaf_oauth_logs (company_id, event_type, status, details, query_string)
    VALUES (?, ?, ?, ?, ?)
  `).run(
    companyId || null,
    String(eventType || ""),
    String(status || ""),
    typeof details === "string" ? details : safeJson(details),
    typeof query === "string" ? query : safeJson(query)
  );
}

function safeIsoFromNow(seconds) {
  const value = Number(seconds);
  if (!Number.isFinite(value) || value <= 0) return "";
  return new Date(Date.now() + value * 1000).toISOString();
}

function decodeJwtPayload(token) {
  if (!token || typeof token !== "string") return null;
  const parts = token.split(".");
  if (parts.length < 2) return null;

  try {
    const padded = parts[1].replace(/-/g, "+").replace(/_/g, "/");
    const json = Buffer.from(padded, "base64").toString("utf8");
    return JSON.parse(json);
  } catch {
    return null;
  }
}

function extractSerial(payload) {
  if (!payload || typeof payload !== "object") return "";
  return String(
    payload.serial_number ||
    payload.serialNumber ||
    payload.serial ||
    payload.cert_sn ||
    payload.certificate_serial ||
    ""
  ).trim();
}

function upsertAnafConnection(db, companyId, environment, tokenPayload, rawResponse) {
  const accessToken = tokenPayload?.access_token || "";
  const refreshToken = tokenPayload?.refresh_token || "";
  const tokenType = tokenPayload?.token_type || "";
  const scope = tokenPayload?.scope || "";
  const expiresAt = safeIsoFromNow(tokenPayload?.expires_in);
  const refreshExpiresAt = safeIsoFromNow(
    tokenPayload?.refresh_token_expires_in || tokenPayload?.refresh_expires_in
  );
  const jwtPayload = decodeJwtPayload(accessToken);
  const serialCertificate = extractSerial(jwtPayload);
  const existing = db.prepare(`
    SELECT id
    FROM anaf_connections
    WHERE environment = ? AND company_id = ?
    ORDER BY id DESC
    LIMIT 1
  `).get(environment, companyId);

  if (existing?.id) {
    db.prepare(`
      UPDATE anaf_connections
      SET access_token = ?,
          refresh_token = ?,
          token_type = ?,
          scope = ?,
          expires_at = ?,
          refresh_expires_at = ?,
          serial_certificate = ?,
          raw_response = ?,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(
      accessToken,
      refreshToken,
      tokenType,
      scope,
      expiresAt,
      refreshExpiresAt,
      serialCertificate,
      rawResponse,
      existing.id
    );
    return existing.id;
  }

  const result = db.prepare(`
    INSERT INTO anaf_connections (
      company_id,
      environment,
      access_token,
      refresh_token,
      token_type,
      scope,
      expires_at,
      refresh_expires_at,
      serial_certificate,
      raw_response
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    companyId || null,
    environment,
    accessToken,
    refreshToken,
    tokenType,
    scope,
    expiresAt,
    refreshExpiresAt,
    serialCertificate,
    rawResponse
  );

  return result.lastInsertRowid;
}

export function registerAnafOAuthRoutes(app, { db, getSetting, requireAuth, setSetting }) {
  if (!getSetting("anaf_redirect_uri", "")) {
    setSetting("anaf_redirect_uri", DEFAULT_ANAF_REDIRECT_URI);
  }

  app.get("/oauth/anaf/start", requireAuth, (req, res) => {
    const companyId = Number(req.session?.user?.company_id || 0);
    const clientId = String(getSetting("anaf_client_id", "") || "").trim();
    const clientSecret = String(getSetting("anaf_client_secret", "") || "").trim();
    const authorizeUrl = String(getSetting("anaf_authorize_url", DEFAULT_ANAF_AUTHORIZE_URL) || DEFAULT_ANAF_AUTHORIZE_URL).trim();
    const redirectUri = String(getSetting("anaf_redirect_uri", DEFAULT_ANAF_REDIRECT_URI) || DEFAULT_ANAF_REDIRECT_URI).trim();
    const scope = String(getSetting("anaf_scope", "") || "").trim();

    if (!clientId || !clientSecret) {
      logOauthEvent(db, companyId, "start", "error", "Lipsesc Client ID sau Client Secret pentru ANAF.", req.query);
      return res.redirect(buildRedirectUrl("/anaf/status", "error", "Lipsesc Client ID sau Client Secret pentru ANAF."));
    }

    const state = crypto.randomBytes(24).toString("hex");
    req.session.anafOAuthState = state;
    req.session.anafOAuthStartedAt = Date.now();

    const params = new URLSearchParams({
      response_type: "code",
      client_id: clientId,
      redirect_uri: redirectUri,
      state,
      token_content_type: "jwt"
    });

    if (scope) params.set("scope", scope);
    logOauthEvent(db, companyId, "start", "redirect", {
      environment: String(getSetting("anaf_environment", "test") || "test").trim(),
      redirect_uri: redirectUri,
      authorize_url: authorizeUrl
    }, req.query);

    res.redirect(`${authorizeUrl}?${params.toString()}`);
  });

  app.get("/oauth/anaf/callback", requireAuth, async (req, res) => {
    const companyId = Number(req.session?.user?.company_id || 0);
    const expectedState = req.session.anafOAuthState;
    delete req.session.anafOAuthState;
    delete req.session.anafOAuthStartedAt;

    const incomingState = String(req.query.state || "");
    const authCode = String(req.query.code || "");
    const authError = String(req.query.error || "");
    const authErrorDescription = String(req.query.error_description || "");

    if (authError) {
      logOauthEvent(db, companyId, "callback", "error", {
        error: authError,
        error_description: authErrorDescription
      }, req.query);
      return res.redirect(buildRedirectUrl("/anaf/status", "error", authErrorDescription || authError));
    }

    if (!expectedState || !incomingState || expectedState !== incomingState) {
      logOauthEvent(db, companyId, "callback", "error", "State OAuth invalid sau expirat.", req.query);
      return res.redirect(buildRedirectUrl("/anaf/status", "error", "State OAuth invalid sau expirat."));
    }

    if (!authCode) {
      logOauthEvent(db, companyId, "callback", "error", "ANAF nu a returnat codul de autorizare.", req.query);
      return res.redirect(buildRedirectUrl("/anaf/status", "error", "ANAF nu a returnat codul de autorizare."));
    }

    const clientId = String(getSetting("anaf_client_id", "") || "").trim();
    const clientSecret = String(getSetting("anaf_client_secret", "") || "").trim();
    const tokenUrl = String(getSetting("anaf_token_url", DEFAULT_ANAF_TOKEN_URL) || DEFAULT_ANAF_TOKEN_URL).trim();
    const redirectUri = String(getSetting("anaf_redirect_uri", DEFAULT_ANAF_REDIRECT_URI) || DEFAULT_ANAF_REDIRECT_URI).trim();
    const environment = String(getSetting("anaf_environment", "test") || "test").trim();

    if (!clientId || !clientSecret) {
      logOauthEvent(db, companyId, "callback", "error", "Configurația ANAF este incompletă.", req.query);
      return res.redirect(buildRedirectUrl("/anaf/status", "error", "Configurația ANAF este incompletă."));
    }

    try {
      const body = new URLSearchParams({
        grant_type: "authorization_code",
        code: authCode,
        redirect_uri: redirectUri,
        token_content_type: "jwt"
      });

      const response = await fetch(tokenUrl, {
        method: "POST",
        headers: {
          Accept: "application/json",
          Authorization: `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString("base64")}`,
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body
      });

      const rawText = await response.text();
      let tokenPayload = null;

      try {
        tokenPayload = JSON.parse(rawText);
      } catch {
        tokenPayload = { raw_text: rawText };
      }

      if (!response.ok || !tokenPayload?.access_token) {
        const message = tokenPayload?.error_description || tokenPayload?.error || `Token ANAF invalid (${response.status})`;
        logOauthEvent(db, companyId, "token_exchange", "error", {
          message,
          status: response.status,
          body: tokenPayload
        }, req.query);
        return res.redirect(buildRedirectUrl("/anaf/status", "error", message));
      }

      upsertAnafConnection(db, companyId, environment, tokenPayload, rawText);
      logOauthEvent(db, companyId, "token_exchange", "success", {
        environment,
        token_type: tokenPayload?.token_type || "",
        scope: tokenPayload?.scope || ""
      }, req.query);
      return res.redirect(buildRedirectUrl("/anaf/status", "success", "Conexiunea ANAF a fost salvată cu succes."));
    } catch (error) {
      const message = error instanceof Error ? error.message : "Eroare necunoscută la conectarea ANAF.";
      logOauthEvent(db, companyId, "token_exchange", "error", message, req.query);
      return res.redirect(buildRedirectUrl("/anaf/status", "error", message));
    }
  });
}
