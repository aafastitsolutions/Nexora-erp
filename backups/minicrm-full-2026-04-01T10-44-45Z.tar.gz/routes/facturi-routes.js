export function registerFacturiRoutes(app, deps) {
  const {
    COMPANY,
    Mustache,
    __dirname,
    crmShellEnd,
    crmShellStart,
    db,
    escapeHtml,
    ensureFacturaXmlGenerated,
    fetchAnafCompany,
    fmt2,
    fmtMoney,
    fs,
    getInvoiceLogoDataUri,
    getInvoiceTheme,
    getSetting,
    anafCheckUploadStatus,
    anafDownloadMessage,
    anafUploadFactura,
    invoiceTemplateHtml,
    nextFacturaNumber,
    normalizeCui,
    path,
    recalcFacturaTotals,
    renderPdfBuffer,
    requireAuth,
    transporter
  } = deps;

  function facturaStatusBadgeModern(status) {
    const s = String(status || "").toUpperCase();
    if (s === "INCASATA") return `<span class="crm-badge crm-badge-green">INCASATA</span>`;
    if (s === "TRIMISA") return `<span class="crm-badge crm-badge-blue">TRIMISA</span>`;
    if (s === "TRIMIS_CLIENT") return `<span class="crm-badge crm-badge-green">TRIMIS CLIENT</span>`;
    if (s === "INTARZIATA") return `<span class="crm-badge crm-badge-red">INTARZIATA</span>`;
    if (s === "ANULATA") return `<span class="crm-badge crm-badge-neutral">ANULATA</span>`;
    if (s === "FACTURA_GENERATA") return `<span class="crm-badge crm-badge-blue">FACTURA GENERATA</span>`;
    if (s === "TRIMIS_EFACTURA") return `<span class="crm-badge crm-badge-green">TRIMIS E-FACTURA</span>`;
    if (s === "RECEPTIONATA_SPV") return `<span class="crm-badge crm-badge-green">RECEPTIONATA SPV</span>`;
    return `<span class="crm-badge crm-badge-amber">CIORNA</span>`;
  }

  function efacturaStatusBadge(status) {
    const s = String(status || "").toUpperCase();
    if (!s) return `<span class="crm-badge crm-badge-neutral">NEINITIALIZAT</span>`;
    if (s === "TRIMIS") return `<span class="crm-badge crm-badge-blue">TRIMIS LA ANAF</span>`;
    if (s === "IN_PROCESARE") return `<span class="crm-badge crm-badge-amber">IN PROCESARE</span>`;
    if (s === "RASPUNS_DISPONIBIL") return `<span class="crm-badge crm-badge-green">AJUNSA IN ANAF</span>`;
    if (s === "RECEPTIONATA_SPV") return `<span class="crm-badge crm-badge-green">CONFIRMATA SPV</span>`;
    if (s === "EROARE_UPLOAD" || s === "EROARE") return `<span class="crm-badge crm-badge-red">EROARE ANAF</span>`;
    if (s === "FARA_CONEXIUNE") return `<span class="crm-badge crm-badge-red">NECONECTAT SPV</span>`;
    if (s === "GENERAT") return `<span class="crm-badge crm-badge-neutral">XML GENERAT</span>`;
    return `<span class="crm-badge crm-badge-neutral">${escapeHtml(status || "—")}</span>`;
  }

  app.post("/factura/:id/linie", requireAuth, (req, res) => {
    const companyId = Number(req.session.user.company_id || 0);
    const factura_id = Number(req.params.id);
    if (!Number.isFinite(factura_id)) return res.status(400).send("Bad id");

    const factura = db.prepare("SELECT status FROM facturi WHERE id=? AND company_id=?").get(factura_id, companyId);
    const lockedStatuses = new Set(["TRIMIS_EFACTURA", "RECEPTIONATA_SPV"]);
    if (factura && lockedStatuses.has(String(factura.status || "").toUpperCase())) {
      return res.redirect("/factura/" + factura_id + "?err=factura_blocata");
    }

    const denumire = String(req.body?.denumire || "").trim();
    const cantitate = Number(String(req.body?.cantitate || "1").replace(",", "."));
    const unitate = String(req.body?.unitate || "").trim();
    const pret_unitar = Number(String(req.body?.pret_unitar || "0").replace(",", "."));

    if (!denumire) return res.status(400).send("Denumire required");
    if (!Number.isFinite(cantitate) || cantitate <= 0) return res.status(400).send("Cantitate invalida");
    if (!Number.isFinite(pret_unitar) || pret_unitar < 0) return res.status(400).send("Pret invalid");

    const lt = Math.round((cantitate * pret_unitar) * 100) / 100;
    const mx = db.prepare("SELECT COALESCE(MAX(sort_order),0) AS m FROM facturi_linii WHERE factura_id=? AND company_id=?").get(factura_id, companyId);
    const sort_order = (mx?.m || 0) + 1;

    db.prepare(`
      INSERT INTO facturi_linii (factura_id, denumire, cantitate, unitate, pret_unitar, total_linie, sort_order, company_id)
      VALUES (?,?,?,?,?,?,?,?)
    `).run(factura_id, denumire, cantitate, unitate || null, pret_unitar, lt, sort_order, companyId);

    recalcFacturaTotals(factura_id);
    return res.redirect("/factura/" + factura_id);
  });

  app.post("/factura/:id/linie/:lid/sterge", requireAuth, (req, res) => {
    const companyId = Number(req.session.user.company_id || 0);
    const factura_id = Number(req.params.id);
    const lid = Number(req.params.lid);
    if (!Number.isFinite(factura_id) || !Number.isFinite(lid)) return res.status(400).send("Bad id");

    const factura = db.prepare("SELECT status FROM facturi WHERE id=? AND company_id=?").get(factura_id, companyId);
    const lockedStatuses = new Set(["TRIMIS_EFACTURA", "RECEPTIONATA_SPV"]);
    if (factura && lockedStatuses.has(String(factura.status || "").toUpperCase())) {
      return res.redirect("/factura/" + factura_id + "?err=factura_blocata");
    }

    db.prepare("DELETE FROM facturi_linii WHERE id=? AND factura_id=? AND company_id=?").run(lid, factura_id, companyId);
    recalcFacturaTotals(factura_id);
    return res.redirect("/factura/" + factura_id);
  });

  app.post("/factura/:id/status", requireAuth, (req, res) => {
    const companyId = Number(req.session.user.company_id || 0);
    const factura_id = Number(req.params.id);
    if (!Number.isFinite(factura_id)) return res.status(400).send("Bad id");

    const status = String(req.body?.status || "CIORNA").trim().toUpperCase();
    const allowed = new Set(["CIORNA", "TRIMISA", "INCASATA", "INTARZIATA", "ANULATA"]);
    if (!allowed.has(status)) return res.status(400).send("Status invalid");

    db.prepare("UPDATE facturi SET status=? WHERE id=? AND company_id=?").run(status, factura_id, companyId);
    return res.redirect("/factura/" + factura_id + "?ok=anulata");
  });

  app.get("/facturi", requireAuth, (req, res) => {
    const companyId = Number(req.session.user.company_id || 0);
    const facturi = db.prepare(`
      SELECT f.id, f.factura_nr, f.data_emitere, f.total, f.status,
             c.name AS client_name, c.cui AS client_cui
      FROM facturi f
      JOIN clients c ON c.id = f.client_id
      WHERE f.company_id=?
      ORDER BY f.id DESC
      LIMIT 300
    `).all(companyId);

    const userEmail = req.session.user.email;
    const rows = facturi.map((f) => `
      <tr>
        <td><a href="/factura/${f.id}">${escapeHtml(f.factura_nr || "")}</a></td>
        <td>
          <div style="font-weight:800">${escapeHtml(f.client_name || "")}</div>
          <div class="crm-muted" style="margin-top:4px">${escapeHtml(f.client_cui || "")}</div>
        </td>
        <td>${escapeHtml(String(f.data_emitere || "").slice(0, 10))}</td>
        <td class="crm-right">${escapeHtml(fmtMoney(f.total))}</td>
        <td>${facturaStatusBadgeModern(f.status)}</td>
      </tr>`).join("");

    res.type("html").send(`
<!doctype html>
<html>
<head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<meta charset="utf8">
<title>Facturi</title>
</head>

${crmShellStart("facturi", "Facturi", "Creare rapida de facturi si urmarirea statusului de incasare.", userEmail, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

  <div class="crm-grid-2" style="overflow:visible" style="margin-bottom:18px">
    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <div style="margin-bottom:14px">
        <h3 style="margin:0;font-size:20px">Creeaza factura</h3>
        <div class="crm-muted" style="margin-top:6px">Introdu CUI-ul clientului si genereaza rapid o factura noua.</div>
      </div>

      <form method="post" action="/facturi" class="crm-stack">
        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">CUI Client</label>
            <input class="crm-input" name="cui" required placeholder="Ex: 47446760">
          </div>
          <div>
            <label class="crm-label">Scadenta</label>
            <input class="crm-input" name="scadenta" type="date">
          </div>
        </div>

        <div>
          <label class="crm-label" style="display:flex;align-items:center;gap:10px;margin:0">
            <input type="checkbox" name="aplica_tva" value="1" checked style="width:auto">
            Aplic TVA
          </label>
        </div>

        <div>
          <button class="crm-btn" type="submit">Creeaza factura</button>
        </div>
      </form>
    </section>

    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <div style="margin-bottom:14px">
        <h3 style="margin:0;font-size:20px">Sumar</h3>
        <div class="crm-muted" style="margin-top:6px">Vedere rapida asupra facturilor generate.</div>
      </div>

      <div class="crm-kpis" style="grid-template-columns:repeat(2,minmax(0,1fr));gap:14px">
        <div class="crm-kpi">
          <div class="crm-kpi-label">Total facturi</div>
          <div class="crm-kpi-value">${escapeHtml(String(facturi.length))}</div>
        </div>
        <div class="crm-kpi">
          <div class="crm-kpi-label">Neincasate</div>
          <div class="crm-kpi-value">${escapeHtml(String(facturi.filter((x) => ["CIORNA", "TRIMISA", "INTARZIATA"].includes(String(x.status || "").toUpperCase())).length))}</div>
        </div>
      </div>
    </section>
  </div>

  <section class="crm-card" style="position:sticky;top:20px;z-index:10">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;margin-bottom:14px">
      <div>
        <h3 style="margin:0;font-size:20px">Lista facturi</h3>
        <div class="crm-muted" style="margin-top:6px">Ultimele 300 de facturi din sistem.</div>
      </div>
    </div>

    <div class="crm-table-wrap">
      <table class="crm-table">
        <thead>
          <tr>
            <th>Factura</th>
            <th>Client</th>
            <th>Data</th>
            <th class="crm-right">Total</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          ${rows || `<tr><td colspan="5"><i>Nu exista facturi</i></td></tr>`}
        </tbody>
      </table>
    </div>
  </section>

${crmShellEnd()}
</html>`);
  });

  app.post("/facturi", requireAuth, async (req, res) => {
    const companyId = Number(req.session.user.company_id || 0);
    const cui = normalizeCui(req.body.cui || "");
    const scadenta = req.body.scadenta || null;
    const aplica_tva = String(req.body?.aplica_tva || "") === "1";

    if (!cui) return res.status(400).send("CUI required");

    let anaf = null;
    try {
      anaf = await fetchAnafCompany(cui);
    } catch (e) {
      console.warn("ANAF client refresh failed:", String(e?.message ?? e));
    }

    let client = db.prepare("SELECT id, vat FROM clients WHERE cui=? AND company_id=?").get(cui, companyId);
    if (!client) {
      if (anaf) {
        db.prepare(`
          INSERT INTO clients (cui,name,address,reg_com,caen,vat,inactive,company_id)
          VALUES (?,?,?,?,?,?,?,?)
        `).run(anaf.cui, anaf.name || ("Client " + cui), anaf.address || null, anaf.reg_com || null, anaf.caen || null, anaf.vat || 0, anaf.inactive || 0, companyId);
      } else {
        db.prepare("INSERT INTO clients (cui,name,vat,inactive,company_id) VALUES (?,?,0,0,?)").run(cui, "Client " + cui, companyId);
      }
      client = db.prepare("SELECT id, vat FROM clients WHERE cui=? AND company_id=?").get(cui, companyId);
    } else if (anaf) {
      db.prepare(`
        UPDATE clients
        SET name=?, address=?, reg_com=?, caen=?, vat=?, inactive=?
        WHERE cui=? AND company_id=?
      `).run(anaf.name || ("Client " + cui), anaf.address || null, anaf.reg_com || null, anaf.caen || null, anaf.vat || 0, anaf.inactive || 0, cui, companyId);
      client = db.prepare("SELECT id, vat FROM clients WHERE cui=? AND company_id=?").get(cui, companyId);
    }

    const client_id = client?.id;
    if (!client_id) return res.status(400).send("Client negasit/creat");

    const defaultRate = Number(process.env.VAT_RATE_DEFAULT || "0.19");
    const tva_procent = aplica_tva ? defaultRate : 0;
    const n = nextFacturaNumber();

    const r = db.prepare(`
      INSERT INTO facturi
      (factura_nr, an, seq, client_id, scadenta, tva_procent, company_id)
      VALUES (?,?,?,?,?,?,?)
    `).run(n.factura_nr, n.an, n.seq, client_id, scadenta, tva_procent, companyId);

    res.redirect("/factura/" + r.lastInsertRowid);
  });

  app.get("/factura/:id", requireAuth, (req, res) => {
    const companyId = Number(req.session.user.company_id || 0);
    const id = Number(req.params.id);
    const ok = String(req.query.ok || "");
    const err = String(req.query.err || "");

    const f = db.prepare(`
      SELECT f.*, c.name AS client
      FROM facturi f
      JOIN clients c ON c.id=f.client_id
      WHERE f.id=? AND f.company_id=?
    `).get(id, companyId);

    if (!f) return res.status(404).send("Factura nu exista");

    const clientEmail = db.prepare(`
      SELECT email
      FROM contacts
      WHERE client_id=? AND company_id=? AND email IS NOT NULL AND TRIM(email) <> ''
      ORDER BY is_primary DESC, id ASC
      LIMIT 1
    `).get(f.client_id, companyId)?.email || "";

    const linii = db.prepare(`
      SELECT id, denumire, cantitate, unitate, pret_unitar, total_linie
      FROM facturi_linii
      WHERE factura_id=? AND company_id=?
      ORDER BY sort_order ASC, id ASC
    `).all(id, companyId);

    const totals = recalcFacturaTotals(id);
    const products = db.prepare(`
      SELECT id, code, name, unit, price, tva_percent, kind
      FROM products
      WHERE active=1 AND company_id=?
      ORDER BY name COLLATE NOCASE ASC, id DESC
      LIMIT 500
    `).all(companyId);

    const productOptions = (products || []).map((p) => `
      <option
        value="${p.id}"
        data-name="${escapeHtml(p.name || "")}"
        data-unit="${escapeHtml(p.unit || "")}"
        data-price="${escapeHtml(String(p.price ?? 0))}"
        data-code="${escapeHtml(p.code || "")}"
      >${escapeHtml((p.code ? "[" + p.code + "] " : "") + (p.name || ""))}</option>
    `).join("");

    const liniiRows = (linii || []).map((l) => `
      <tr>
        <td>${escapeHtml(l.denumire || "")}</td>
        <td class="crm-right">${escapeHtml(String(l.cantitate ?? ""))}</td>
        <td>${escapeHtml(l.unitate || "")}</td>
        <td class="crm-right">${escapeHtml(fmtMoney(l.pret_unitar))}</td>
        <td class="crm-right">${escapeHtml(fmtMoney(l.total_linie))}</td>
        <td class="crm-right">
          <form method="post" action="/factura/${id}/linie/${l.id}/sterge" style="margin:0">
            <button class="crm-btn crm-btn-danger" type="submit">Sterge</button>
          </form>
        </td>
      </tr>`).join("");

    res.type("html").send(`
<!doctype html>
<html>
<head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<meta charset="utf8">
<title>${escapeHtml(f.factura_nr)}</title>
</head>

${crmShellStart("facturi", `Factura ${f.factura_nr || ""}`, "Administrare linii, totaluri si generare PDF.", req.session.user.email, req.session.user.module_permissions, req.session.user.subscription?.status || "", req.session.user.company_name || "")}

  ${ok ? `<div class="crm-card" style="margin-bottom:18px;border:1px solid #bbf7d0;background:#f0fdf4">
    <div style="font-weight:800;color:#166534;margin-bottom:6px">Operatiune reusita</div>
    <div class="crm-muted">${
      ok === "xml_generat" ? "XML-ul e-Factura a fost generat cu succes."
      : ok === "trimis_anaf" ? "Factura a fost transmisa catre ANAF si a primit index de incarcare."
      : ok === "stare_actualizata" ? "Statusul ANAF a fost actualizat."
      : ok === "stare_actualizata_cu_zip" ? "Factura a fost confirmata de ANAF, iar raspunsul SPV a fost descarcat."
      : ok === "trimis_local" ? "Factura a fost marcata ca pregatita pentru trimitere catre ANAF."
      : ok === "anulata" ? "Factura a fost anulata."
      : "Operatiunea a fost finalizata cu succes."
    }</div>
  </div>` : ``}

  ${err ? `<div class="crm-card" style="margin-bottom:18px;border:1px solid #fecaca;background:#fef2f2">
    <div style="font-weight:800;color:#991b1b;margin-bottom:6px">Operatiune esuata</div>
    <div class="crm-muted">${
      err === "nu_exista_xml" ? "Nu exista XML generat pentru aceasta factura."
      : err === "xml_lipsa_pe_server" ? "Fisierul XML lipseste de pe server."
      : err === "factura_blocata" ? "Factura nu poate fi modificata, este deja trimisa in e-Factura."
      : err === "fara_conexiune_anaf" ? "Nu exista o conexiune ANAF activa. Conecteaza mai intai contul SPV."
      : err === "fara_index_incarcare" ? "Factura nu are index de incarcare ANAF. Trimite-o mai intai."
      : err === "eroare_anaf" ? escapeHtml(String(f.efactura_last_error || "ANAF a returnat o eroare."))
      : "A aparut o eroare la procesarea e-Factura."
    }</div>
  </div>` : ``}

  <div class="crm-grid-2" style="overflow:visible" style="margin-bottom:18px">
    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap">
        <div>
          <h3 style="margin:0 0 10px 0;font-size:20px">Detalii factura</h3>
          <div class="crm-muted">Informatii principale despre document.</div>
        </div>
        <div>${facturaStatusBadgeModern(f.status)}</div>
      </div>

      <div class="crm-stack" style="margin-top:16px;gap:10px">
        <div><b>Client:</b> ${escapeHtml(f.client || "")}</div>
        <div><b>Data emitere:</b> ${escapeHtml(String(f.data_emitere || "").slice(0,10))}</div>
        <div><b>Scadenta:</b> ${escapeHtml(String(f.scadenta || "").slice(0,10)) || `<span class="crm-muted">-</span>`}</div>
        <div><b>Total:</b> ${escapeHtml(fmtMoney(f.total))}</div>
        <div><b>Status e-Factura:</b> ${efacturaStatusBadge(f.efactura_status)}</div>
        <div><b>Index incarcare:</b> ${escapeHtml(f.efactura_upload_index || f.efactura_message_id || "—")}</div>
        <div><b>ID descarcare:</b> ${escapeHtml(f.efactura_download_id || "—")}</div>
        <div><b>Ultima verificare:</b> ${escapeHtml(f.efactura_last_checked_at || "—")}</div>
        <div><b>Ultima eroare:</b> ${escapeHtml(f.efactura_last_error || "—")}</div>
        ${f.efactura_response_zip_path
          ? `<div><b>Raspuns SPV:</b> <a href="/${encodeURI(f.efactura_response_zip_path)}" target="_blank">Descarca arhiva ANAF</a></div>`
          : ``}
      </div>
    </section>

    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <div style="margin-bottom:14px">
        <h3 style="margin:0;font-size:20px">Actiuni document</h3>
        <div class="crm-muted" style="margin-top:6px">Flux recomandat: Trimite e-Factura, genereaza PDF si trimite clientului documentul final.</div>
      </div>

      <div class="crm-stack" style="gap:10px">
        <form method="post" action="/factura/${id}/efactura/trimite" style="margin:0">
          <button class="crm-btn" type="submit">Trimite e-Factura</button>
        </form>

        <form method="post" action="/factura/${id}/genereaza-pdf" style="margin:0">
          <button class="crm-btn crm-btn-secondary" type="submit">Genereaza PDF</button>
        </form>

        <a href="/factura/${id}/preview-pdf2" target="_blank" class="crm-btn crm-btn-secondary" style="text-decoration:none">
          Deschide preview
        </a>

        ${clientEmail
          ? `<form method="post" action="/factura/${id}/trimite-client" style="margin:0">
              <button class="crm-btn crm-btn-secondary" type="submit">Trimite email clientului</button>
            </form>`
          : `<a href="/client/${f.client_id}" class="crm-btn crm-btn-secondary" style="text-decoration:none">Adauga email client</a>`}

        <form method="post" action="/factura/${id}/status" style="margin:0" onsubmit="return confirm('Esti sigur ca vrei sa anulezi factura?');">
          <input type="hidden" name="status" value="ANULATA">
          <button class="crm-btn crm-btn-danger" type="submit">Anuleaza factura</button>
        </form>

        ${f.pdf_path
          ? `<a href="/${encodeURI(f.pdf_path)}" target="_blank" class="crm-btn crm-btn-secondary" style="text-decoration:none">Deschide PDF</a>`
          : `<span class="crm-muted">Fara PDF generat inca</span>`}
      </div>

      <div style="margin-top:16px;padding:14px 16px;border:1px dashed #cbd5e1;border-radius:14px;background:#f8fafc">
        <div style="font-weight:800;margin-bottom:6px">Flux recomandat</div>
        <div class="crm-muted">1. Verifici preview-ul de mai jos · 2. Generezi PDF · 3. Trimiti e-Factura · 4. Verifici statusul SPV pana apare confirmarea · 5. Trimiti email clientului.</div>
      </div>
    </section>
  </div>

  <section class="crm-card" style="margin-bottom:18px">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;margin-bottom:14px">
      <div>
        <h3 style="margin:0;font-size:20px">Linii factura</h3>
        <div class="crm-muted" style="margin-top:6px">Produse si servicii adaugate pe document.</div>
      </div>
    </div>

    <div class="crm-table-wrap">
      <table class="crm-table">
        <thead>
          <tr>
            <th>Denumire</th>
            <th class="crm-right">Cant</th>
            <th>UM</th>
            <th class="crm-right">Pret</th>
            <th class="crm-right">Total</th>
            <th class="crm-right">Actiuni</th>
          </tr>
        </thead>
        <tbody>
          ${liniiRows || `<tr><td colspan="6"><i>Nu exista linii</i></td></tr>`}
        </tbody>
      </table>
    </div>

    <div style="margin-top:16px;display:flex;justify-content:flex-end">
      <div class="crm-card" style="padding:0;min-width:340px;max-width:420px;width:100%">
        <table class="crm-table">
          <tbody>
            <tr>
              <th style="width:60%">Subtotal</th>
              <td class="crm-right">${escapeHtml(fmtMoney(totals.subtotal))}</td>
            </tr>
            <tr>
              <th>TVA (${escapeHtml(String(Math.round(totals.tva_procent * 100))) }%)</th>
              <td class="crm-right">${escapeHtml(fmtMoney(totals.tva_valoare))}</td>
            </tr>
            <tr>
              <th>TOTAL</th>
              <td class="crm-right"><b>${escapeHtml(fmtMoney(totals.total))}</b></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </section>

  <div style="margin-bottom:18px">
    <section class="crm-card" style="position:sticky;top:20px;z-index:10">
      <div style="margin-bottom:14px">
        <h3 style="margin:0;font-size:20px">Adauga linie</h3>
        <div class="crm-muted" style="margin-top:6px">Poti porni de la un produs activ sau poti completa manual.</div>
      </div>

      <form method="post" action="/factura/${id}/linie" class="crm-stack">
        <div>
          <label class="crm-label">Produs / serviciu</label>
          <select class="crm-select" id="product_select">
            <option value="">-- alege produs --</option>
            ${productOptions}
          </select>
        </div>

        <div>
          <label class="crm-label">Denumire</label>
          <input class="crm-input" id="denumire_input" name="denumire" required>
        </div>

        <div class="crm-grid-2" style="overflow:visible">
          <div>
            <label class="crm-label">Cantitate</label>
            <input class="crm-input" name="cantitate" value="1">
          </div>
          <div>
            <label class="crm-label">UM</label>
            <input class="crm-input" id="unitate_input" name="unitate" placeholder="buc">
          </div>
        </div>

        <div>
          <label class="crm-label">Pret unitar</label>
          <input class="crm-input" id="pret_input" name="pret_unitar" value="0">
        </div>

        <div>
          <button class="crm-btn" type="submit">Adauga linie</button>
        </div>
      </form>

      <div style="margin-top:18px">
        <a href="/facturi">← Inapoi la facturi</a> · <a href="/setari">Setari</a>
      </div>
    </section>
  </div>

  <section class="crm-card" style="margin-bottom:18px">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap;margin-bottom:14px">
      <div>
        <h3 style="margin:0;font-size:20px">e-Factura ANAF</h3>
        <div class="crm-muted" style="margin-top:6px">Dupa verificarea PDF-ului, poti trimite direct e-Factura.</div>
      </div>
      <div>${efacturaStatusBadge(f.efactura_status)}</div>
    </div>

    <div class="crm-row" style="margin-top:4px">
      <form method="post" action="/factura/${id}/efactura/trimite" style="margin:0">
        <button class="crm-btn" type="submit">Trimite e-Factura</button>
      </form>
      <form method="post" action="/factura/${id}/efactura/genereaza-xml" style="margin:0">
        <button class="crm-btn crm-btn-secondary" type="submit">Regenereaza XML</button>
      </form>
      ${(f.efactura_upload_index || f.efactura_message_id || String(f.status || "").toUpperCase() === "TRIMIS_EFACTURA") ? `
      <form method="post" action="/factura/${id}/efactura/confirma-spv" style="margin:0">
        <button class="crm-btn crm-btn-secondary" type="submit">Verifica status SPV</button>
      </form>` : ``}
    </div>
  </section>

  <script>
  function toggleFacturaPreview(forceState){
    const wrap = document.getElementById("factura-preview-wrap");
    const frame = document.getElementById("factura-preview-frame");
    const btnText = document.getElementById("factura-preview-toggle-text");
    const btnIcon = document.getElementById("factura-preview-toggle-icon");

    if(!wrap || !frame) return;

    const frameBox = frame.parentElement;
    const isHidden = !frameBox || frameBox.style.display === "none";
    const willShow = typeof forceState === "boolean" ? forceState : isHidden;

    if(willShow){
      if(frameBox) frameBox.style.display = "block";
      if(!frame.src){
        frame.src = frame.dataset.src || "";
      }
      if(btnText) btnText.textContent = "Ascunde preview";
      if(btnIcon) btnIcon.textContent = "▾";

      setTimeout(() => {
        wrap.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 50);
    } else {
      if(frameBox) frameBox.style.display = "none";
      if(btnText) btnText.textContent = "Afiseaza preview";
      if(btnIcon) btnIcon.textContent = "▸";
    }
  }
  </script>

  <script>
  (function(){
    const sel = document.getElementById("product_select");
    const den = document.getElementById("denumire_input");
    const um  = document.getElementById("unitate_input");
    const pre = document.getElementById("pret_input");
    if(!sel || !den || !um || !pre) return;

    sel.addEventListener("change", function(){
      const opt = sel.options[sel.selectedIndex];
      if(!opt || !opt.value) return;
      den.value = opt.getAttribute("data-name") || "";
      um.value = opt.getAttribute("data-unit") || "";
      pre.value = opt.getAttribute("data-price") || "0";
    });
  })();
  </script>

${crmShellEnd()}
</html>`);
  });

  app.get("/factura/:id/preview-pdf", requireAuth, async (req, res) => {
    const companyId = Number(req.session.user.company_id || 0);
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) return res.status(400).send("Bad id");

    const embed = String(req.query?.embed || "") === "1";
    const f = db.prepare(`
      SELECT f.*, c.name AS client, c.address AS client_address, c.cui AS client_cui, c.reg_com AS client_reg_com
      FROM facturi f
      JOIN clients c ON c.id = f.client_id
      WHERE f.id=? AND f.company_id=?
    `).get(id, companyId);

    if (!f) return res.status(404).send("Factura nu exista");

    const lines = db.prepare(`
      SELECT denumire, cantitate, unitate, pret_unitar, total_linie
      FROM facturi_linii
      WHERE factura_id=? AND company_id=?
      ORDER BY sort_order ASC, id ASC
    `).all(id, companyId);

    const totals = recalcFacturaTotals(id);
    const company = {
      name: getSetting("company_name", COMPANY.name),
      cui: getSetting("company_cui", COMPANY.cui),
      rc: getSetting("company_rc", COMPANY.rc),
      address: getSetting("company_address", COMPANY.address),
      iban: getSetting("company_iban", COMPANY.iban),
      bank: getSetting("company_bank", COMPANY.bank),
      rep: getSetting("company_rep", COMPANY.rep)
    };

    const rowsHtml = (lines || []).map((l, idx) => `
      <tr>
        <td style="padding:10px;border-bottom:1px solid #e5e7eb">${idx + 1}</td>
        <td style="padding:10px;border-bottom:1px solid #e5e7eb">${escapeHtml(l.denumire || "")}</td>
        <td style="padding:10px;border-bottom:1px solid #e5e7eb;text-align:right">${escapeHtml(String(l.cantitate || ""))}</td>
        <td style="padding:10px;border-bottom:1px solid #e5e7eb">${escapeHtml(l.unitate || "")}</td>
        <td style="padding:10px;border-bottom:1px solid #e5e7eb;text-align:right">${escapeHtml(fmtMoney(l.pret_unitar))}</td>
        <td style="padding:10px;border-bottom:1px solid #e5e7eb;text-align:right">${escapeHtml(fmtMoney(l.total_linie))}</td>
      </tr>
    `).join("");

    res.type("html").send(`<!doctype html>
<html>
<head>
<style>
  position:sticky;
  top:10px;
  z-index:20;
  background:#fff;
  padding:10px;
  border-radius:12px;
  box-shadow:0 2px 8px rgba(0,0,0,0.05);
}
</style>
<meta charset="utf-8">
<title>Preview PDF ${escapeHtml(f.factura_nr || "")}</title>
<style>
body{font-family:Arial,sans-serif;background:${embed ? "#ffffff" : "#ecfdf5"};color:#0f172a;margin:0;padding:${embed ? "12px" : "24px"}}
.wrap{max-width:${embed ? "100%" : "1100px"};margin:0 auto}
.card{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:24px;box-shadow:${embed ? "none" : "0 8px 24px rgba(15,23,42,.06)"}}
.top{display:flex;justify-content:space-between;gap:20px;flex-wrap:wrap;margin-bottom:24px}
.muted{color:#64748b}
.kv div{margin-bottom:8px}
h1,h2,h3{margin:0}
table{width:100%;border-collapse:collapse}
.totalbox{margin-left:auto;max-width:360px;width:100%;margin-top:18px}
.totalbox td,.totalbox th{padding:10px;border-bottom:1px solid #e5e7eb}
.actions{display:${embed ? "none" : "flex"};gap:10px;flex-wrap:wrap;margin-bottom:18px}
.btn{display:inline-block;padding:10px 14px;border-radius:10px;border:1px solid #cbd5e1;text-decoration:none;color:#0f172a;background:white;font-weight:700}
.btn-primary{background:#0f172a;color:white;border-color:#0f172a}
</style>
</head>
<body>
<div class="wrap">
  <div class="actions">
    <a class="btn" href="/factura/${id}">Inapoi la factura</a>
    <form method="post" action="/factura/${id}/genereaza-pdf" style="margin:0">
      <button class="btn btn-primary" type="submit">Genereaza PDF</button>
    </form>
  </div>

  <div class="card">
    <div class="top">
      <div>
        <h1>Factura ${escapeHtml(f.factura_nr || "")}</h1>
        <div class="muted" style="margin-top:8px">Preview inainte de generarea PDF-ului.</div>
      </div>
      <div class="kv">
        <div><b>Data emitere:</b> ${escapeHtml(String(f.data_emitere || "").slice(0,10))}</div>
        <div><b>Scadenta:</b> ${escapeHtml(String(f.scadenta || "").slice(0,10)) || "-"}</div>
        <div><b>Moneda:</b> ${escapeHtml(f.moneda || "RON")}</div>
      </div>
    </div>

    <div class="top">
      <div style="min-width:320px;flex:1">
        <h3>Furnizor</h3>
        <div style="margin-top:10px;line-height:1.7">
          <div><b>${escapeHtml(company.name || "")}</b></div>
          <div>CUI: ${escapeHtml(company.cui || "")}</div>
          <div>RC: ${escapeHtml(company.rc || "")}</div>
          <div>${escapeHtml(company.address || "")}</div>
          <div>IBAN: ${escapeHtml(company.iban || "")}</div>
          <div>Banca: ${escapeHtml(company.bank || "")}</div>
          <div>Reprezentant: ${escapeHtml(company.rep || "")}</div>
        </div>
      </div>

      <div style="min-width:320px;flex:1">
        <h3>Client</h3>
        <div style="margin-top:10px;line-height:1.7">
          <div><b>${escapeHtml(f.client || "")}</b></div>
          <div>CUI: ${escapeHtml(f.client_cui || "")}</div>
          <div>Reg. com.: ${escapeHtml(f.client_reg_com || "")}</div>
          <div>${escapeHtml(f.client_address || "")}</div>
        </div>
      </div>
    </div>

    <div style="margin-top:18px">
      <table>
        <tr>
          <th style="width:6%">Nr.</th>
          <th>Denumire</th>
          <th style="text-align:right">Cant</th>
          <th>UM</th>
          <th style="text-align:right">Pret</th>
          <th style="text-align:right">Total</th>
        </tr>
        ${rowsHtml}
      </table>
    </div>

    <table class="totalbox">
      <tbody>
        <tr><th style="text-align:left">Subtotal</th><td style="text-align:right">${escapeHtml(fmtMoney(totals.subtotal))}</td></tr>
        <tr><th style="text-align:left">TVA (${escapeHtml(String(Math.round((totals.tva_procent || 0) * 100))) }%)</th><td style="text-align:right">${escapeHtml(fmtMoney(totals.tva_valoare))}</td></tr>
        <tr><th style="text-align:left">TOTAL</th><td style="text-align:right"><b>${escapeHtml(fmtMoney(totals.total))}</b></td></tr>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>`);
  });

  app.get("/factura/:id/preview-pdf2", requireAuth, async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) return res.status(400).send("Bad id");

    const f = db.prepare(`
      SELECT f.*, c.name AS client_name, c.cui AS client_cui, c.address AS client_address, c.reg_com AS client_reg_com
      FROM facturi f
      JOIN clients c ON c.id=f.client_id
      WHERE f.id=?
    `).get(id);

    if (!f) return res.status(404).send("Factura nu exista");

    const lines = db.prepare(`
      SELECT denumire, cantitate, unitate, pret_unitar, total_linie
      FROM facturi_linii
      WHERE factura_id=?
      ORDER BY sort_order ASC, id ASC
    `).all(id);

    const totals = recalcFacturaTotals(id);
    const theme = getInvoiceTheme();
    const logo_data_uri = getInvoiceLogoDataUri();
    const company_name = getSetting("company_name", COMPANY.name || "QR-LAB SRL");
    const company_cui = getSetting("company_cui", COMPANY.cui || "");
    const company_rc = getSetting("company_rc", COMPANY.rc || "");
    const company_address = getSetting("company_address", COMPANY.address || "");
    const company_iban = getSetting("company_iban", COMPANY.iban || "");
    const company_bank = getSetting("company_bank", COMPANY.bank || "");
    const company_rep = getSetting("company_rep", COMPANY.representative || "");
    const invoice_footer = getSetting("invoice_footer", "Factura este valabila fara semnatura conform legii.");

    const vm = {
      theme_color: theme.theme,
      theme_color_light: theme.light,
      logo_data_uri,
      serie: (String(f.factura_nr || "INV").split("-")[0] || "INV"),
      numar: (String(f.factura_nr || "") || ""),
      factura_nr: f.factura_nr,
      data_emitere: String(f.data_emitere || "").slice(0, 10),
      scadenta: f.scadenta ? String(f.scadenta).slice(0, 10) : "",
      status: f.status || "CIORNA",
      moneda: f.moneda || "RON",
      subtotal: fmt2(totals.subtotal),
      tva_percent: Math.round((Number(totals.tva_procent || 0) * 100)),
      tva_valoare: fmt2(totals.tva_valoare),
      total: fmt2(totals.total),
      observatii: f.observatii || "",
      app_name: "QR-LAB",
      doc_code: "-",
      intocmit_de: company_rep || "-",
      invoice_footer: invoice_footer || "",
      spv_index: f.spv_index || "",
      spv_date: f.spv_date || "",
      show_tva: Number(totals.tva_procent || 0) > 0,
      furnizor: {
        name: company_name,
        cui: company_cui,
        rc: company_rc,
        address: company_address,
        judet: "Prahova",
        iban: company_iban,
        bank: company_bank
      },
      client: {
        name: f.client_name || "",
        cui: f.client_cui || "",
        address: f.client_address || "",
        reg_com: f.client_reg_com || "",
        judet: "-",
        tara: "Romania"
      },
      lines: (lines || []).map((l, i) => ({
        idx: i + 1,
        denumire: l.denumire || "",
        cantitate: String(l.cantitate ?? ""),
        unitate: l.unitate || "",
        pret_unitar: fmt2(l.pret_unitar),
        total_linie: fmt2(l.total_linie)
      }))
    };

    let html = Mustache.render(invoiceTemplateHtml, vm);
    if (String(req.query.embed || "") !== "1") {
      const backBar = `
        <div style="position:sticky;top:0;z-index:9999;background:#ffffff;border-bottom:1px solid #e5e7eb;padding:12px 18px;display:flex;align-items:center;gap:12px">
          <a href="/factura/${id}" style="display:inline-flex;align-items:center;gap:8px;padding:10px 14px;border-radius:999px;background:#eef2ff;color:#1e3a8a;text-decoration:none;font-weight:700">
            ← Inapoi la editare factura
          </a>
          <div style="color:#64748b;font-size:14px">Preview factura</div>
        </div>
      `;
      html = html.replace(/<body([^>]*)>/i, '<body$1>' + backBar);
    }

    return res.type("html").send(html);
  });

  app.post("/factura/:id/genereaza-pdf", requireAuth, async (req, res) => {
    const companyId = Number(req.session.user.company_id || 0);
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) return res.status(400).send("Bad id");

    const f = db.prepare(`
      SELECT f.*, c.name AS client_name, c.cui AS client_cui, c.address AS client_address, c.reg_com AS client_reg_com, c.vat AS client_vat
      FROM facturi f
      JOIN clients c ON c.id=f.client_id
      WHERE f.id=? AND f.company_id=?
    `).get(id, companyId);

    if (!f) return res.status(404).send("Factura nu exista");

    const lines = db.prepare(`
      SELECT denumire, cantitate, unitate, pret_unitar, total_linie
      FROM facturi_linii
      WHERE factura_id=? AND company_id=?
      ORDER BY sort_order ASC, id ASC
    `).all(id, companyId);

    const totals = recalcFacturaTotals(id);
    const year = Number(f.an || new Date().getFullYear());
    const yearDir = path.join(__dirname, "contracts", "invoices", String(year));
    fs.mkdirSync(yearDir, { recursive: true });

    const fileName = `${f.factura_nr}.pdf`;
    const absPath = path.join(yearDir, fileName);
    const pdf_path = `contracts/invoices/${year}/${fileName}`;

    const theme = getInvoiceTheme();
    const logo_data_uri = getInvoiceLogoDataUri();
    const company_name = getSetting("company_name", COMPANY.name || "QR-LAB SRL");
    const company_cui = getSetting("company_cui", COMPANY.cui || "");
    const company_rc = getSetting("company_rc", COMPANY.rc || "");
    const company_address = getSetting("company_address", COMPANY.address || "");
    const company_iban = getSetting("company_iban", COMPANY.iban || "");
    const company_bank = getSetting("company_bank", COMPANY.bank || "");
    const company_rep = getSetting("company_rep", COMPANY.representative || "");
    const capital_social = getSetting("capital_social", "-");
    const invoice_footer = getSetting("invoice_footer", "Factura este valabila fara semnatura conform legii.");

    const vm = {
      theme_color: theme.theme,
      theme_color_light: theme.light,
      logo_data_uri,
      serie: (String(f.factura_nr || "INV").split("-")[0] || "INV"),
      numar: (String(f.factura_nr || "") || ""),
      factura_nr: f.factura_nr,
      data_emitere: String(f.data_emitere || "").slice(0, 10),
      scadenta: f.scadenta ? String(f.scadenta).slice(0, 10) : "",
      status: f.status || "CIORNA",
      moneda: f.moneda || "RON",
      subtotal: fmt2(totals.subtotal),
      tva_percent: Math.round((Number(totals.tva_procent || 0) * 100)),
      tva_valoare: fmt2(totals.tva_valoare),
      total: fmt2(totals.total),
      observatii: f.observatii || "",
      app_name: "QR-LAB",
      doc_code: "-",
      capital_social: capital_social || "-",
      intocmit_de: company_rep || "-",
      invoice_footer: invoice_footer || "",
      spv_index: f.spv_index || "",
      spv_date: f.spv_date || "",
      show_tva: Number(totals.tva_procent || 0) > 0,
      furnizor: {
        name: company_name,
        cui: company_cui,
        rc: company_rc,
        address: company_address,
        judet: "Prahova",
        iban: company_iban,
        bank: company_bank
      },
      client: {
        name: f.client_name || "",
        cui: f.client_cui || "",
        address: f.client_address || "",
        reg_com: f.client_reg_com || "",
        judet: "-",
        tara: "Romania"
      },
      lines: (lines || []).map((l, i) => ({
        idx: i + 1,
        denumire: l.denumire || "",
        cantitate: String(l.cantitate ?? ""),
        unitate: l.unitate || "",
        pret_unitar: fmt2(l.pret_unitar),
        total_linie: fmt2(l.total_linie)
      }))
    };

    const html = Mustache.render(invoiceTemplateHtml, vm);
    const pdf = await renderPdfBuffer(html);

    fs.writeFileSync(absPath, pdf);
    db.prepare("UPDATE facturi SET pdf_path=? WHERE id=? AND company_id=?").run(pdf_path, id, companyId);
    db.prepare("UPDATE facturi SET status=? WHERE id=? AND company_id=? AND status IN (?,?)").run("FACTURA_GENERATA", id, companyId, "CIORNA", "DRAFT");

    return res.redirect("/" + encodeURI(pdf_path));
  });

  app.post("/factura/:id/efactura/genereaza-xml", requireAuth, (req, res) => {
    const companyId = Number(req.session.user.company_id || 0);
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) return res.status(400).send("Bad id");
    const exists = db.prepare("SELECT id FROM facturi WHERE id=? AND company_id=?").get(id, companyId);
    if (!exists) return res.status(404).send("Factura nu exista");

    const r = ensureFacturaXmlGenerated(id);
    if (r.error) return res.status(404).send(r.error);
    return res.redirect("/factura/" + id + "?ok=xml_generat");
  });

  app.post("/factura/:id/efactura/trimite", requireAuth, async (req, res) => {
    const companyId = Number(req.session.user.company_id || 0);
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) return res.status(400).send("Bad id");

    const f = db.prepare(`
      SELECT id, factura_nr, efactura_xml_path
      FROM facturi
      WHERE id=? AND company_id=?
    `).get(id, companyId);

    if (!f) return res.status(404).send("Factura nu exista");

    let xmlPath = f.efactura_xml_path;
    let absXmlPath = xmlPath ? path.join(__dirname, String(xmlPath || "")) : null;

    if (!xmlPath || !absXmlPath || !fs.existsSync(absXmlPath)) {
      const r = ensureFacturaXmlGenerated(id);
      if (r.error) {
        db.prepare(`
          UPDATE facturi
          SET efactura_last_error=?
          WHERE id=?
        `).run(r.error, id);
        return res.redirect("/factura/" + id + "?err=nu_exista_xml");
      }

      xmlPath = r.xmlPath;
      absXmlPath = r.absPath;
    }

    if (!fs.existsSync(absXmlPath)) {
      db.prepare(`
        UPDATE facturi
        SET efactura_last_error=?
        WHERE id=?
      `).run("Fisierul XML lipseste de pe server.", id);
      return res.redirect("/factura/" + id + "?err=xml_lipsa_pe_server");
    }

    const payload = fs.readFileSync(absXmlPath, "utf8");
    const environment = String(getSetting("anaf_environment", "test") || "test").trim();
    const companyCui = String(getSetting("company_cui", COMPANY.cui || "") || "").replace(/^RO/i, "").trim();

    try {
      const uploaded = await anafUploadFactura({
        cif: companyCui,
        db,
        environment,
        getSetting,
        xml: payload
      });

      if (!uploaded.ok) {
        const errorMessage = uploaded.message || uploaded.rawText || `ANAF upload error (${uploaded.httpStatus})`;
        db.prepare(`
          UPDATE facturi
          SET efactura_status=?,
              efactura_last_error=?,
              efactura_last_checked_at=CURRENT_TIMESTAMP
          WHERE id=? AND company_id=?
        `).run("EROARE_UPLOAD", errorMessage, id, companyId);

        db.prepare(`
          INSERT INTO anaf_messages(company_id, account_id, message_id, factura_id, direction, status, payload, details)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).run(companyId, null, uploaded.uploadIndex || "", id, "OUT", "EROARE", payload, uploaded.rawText || errorMessage);

        return res.redirect("/factura/" + id + "?err=eroare_anaf");
      }

      db.prepare(`
        INSERT INTO anaf_messages(company_id, account_id, message_id, factura_id, direction, status, payload, details)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(companyId, null, uploaded.uploadIndex, id, "OUT", "TRIMIS", payload, uploaded.rawText || "");

      db.prepare(`
        UPDATE facturi
        SET efactura_status=?,
            efactura_message_id=?,
            efactura_upload_index=?,
            efactura_last_error=NULL,
            efactura_last_checked_at=CURRENT_TIMESTAMP
        WHERE id=? AND company_id=?
      `).run("TRIMIS", uploaded.uploadIndex, uploaded.uploadIndex, id, companyId);

      db.prepare("UPDATE facturi SET status=? WHERE id=? AND company_id=?").run("TRIMIS_EFACTURA", id, companyId);
      return res.redirect("/factura/" + id + "?ok=trimis_anaf");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Nu exista conexiune ANAF activa.";
      db.prepare(`
        UPDATE facturi
        SET efactura_status=?,
            efactura_last_error=?,
            efactura_last_checked_at=CURRENT_TIMESTAMP
        WHERE id=? AND company_id=?
      `).run("FARA_CONEXIUNE", message, id, companyId);
      return res.redirect("/factura/" + id + "?err=fara_conexiune_anaf");
    }
  });

  app.post("/factura/:id/efactura/confirma-spv", requireAuth, async (req, res) => {
    const companyId = Number(req.session.user.company_id || 0);
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) return res.status(400).send("Bad id");

    const factura = db.prepare(`
      SELECT id, factura_nr, efactura_upload_index, efactura_message_id
      FROM facturi
      WHERE id=? AND company_id=?
    `).get(id, companyId);

    const uploadIndex = String(factura?.efactura_upload_index || factura?.efactura_message_id || "").trim();
    if (!uploadIndex) return res.redirect("/factura/" + id + "?err=fara_index_incarcare");

    const environment = String(getSetting("anaf_environment", "test") || "test").trim();

    try {
      const checked = await anafCheckUploadStatus({
        db,
        environment,
        getSetting,
        uploadIndex
      });

      const responseMessage = checked.message || checked.rawText || "";
      const nextStatus = checked.downloadId
        ? "RASPUNS_DISPONIBIL"
        : checked.executionStatus
          ? String(checked.executionStatus).toUpperCase()
          : "IN_PROCESARE";

      let responseZipPath = "";
      if (checked.downloadId) {
        const downloaded = await anafDownloadMessage({
          db,
          environment,
          getSetting,
          downloadId: checked.downloadId
        });

        if (downloaded.ok) {
          const zipDir = path.join(__dirname, "efactura_responses");
          fs.mkdirSync(zipDir, { recursive: true });
          const zipFile = `${String(factura.factura_nr || "factura").replace(/[^A-Za-z0-9._-]/g, "_")}-${checked.downloadId}.zip`;
          const absZipPath = path.join(zipDir, zipFile);
          fs.writeFileSync(absZipPath, downloaded.buffer);
          responseZipPath = `efactura_responses/${zipFile}`;
        }
      }

      db.prepare(`
        INSERT INTO anaf_messages(company_id, account_id, message_id, factura_id, direction, status, payload, details)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(companyId, null, checked.downloadId || uploadIndex, id, "OUT", nextStatus, checked.rawText || "", responseMessage);

      db.prepare(`
        UPDATE facturi
        SET status=?,
            efactura_status=?,
            efactura_download_id=COALESCE(?, efactura_download_id),
            efactura_response_zip_path=CASE WHEN ? <> '' THEN ? ELSE efactura_response_zip_path END,
            efactura_last_error=?,
            efactura_last_checked_at=CURRENT_TIMESTAMP
        WHERE id=? AND company_id=?
      `).run(
        checked.downloadId ? "RECEPTIONATA_SPV" : "TRIMIS_EFACTURA",
        nextStatus,
        checked.downloadId || null,
        responseZipPath,
        responseZipPath,
        checked.ok ? null : (responseMessage || `ANAF status error (${checked.httpStatus})`),
        id,
        companyId
      );

      return res.redirect("/factura/" + id + (responseZipPath ? "?ok=stare_actualizata_cu_zip" : "?ok=stare_actualizata"));
    } catch (error) {
      const message = error instanceof Error ? error.message : "Nu exista conexiune ANAF activa.";
      db.prepare(`
        UPDATE facturi
        SET efactura_last_error=?,
            efactura_last_checked_at=CURRENT_TIMESTAMP
        WHERE id=? AND company_id=?
      `).run(message, id, companyId);
      return res.redirect("/factura/" + id + "?err=fara_conexiune_anaf");
    }
  });

  app.post("/factura/:id/trimite-client", requireAuth, async (req, res) => {
    const companyId = Number(req.session.user.company_id || 0);
    const id = Number(req.params.id);
    if (!Number.isFinite(id)) return res.status(400).send("Bad id");

    const f = db.prepare(`
      SELECT f.*, c.name AS client
      FROM facturi f
      JOIN clients c ON c.id=f.client_id
      WHERE f.id=? AND f.company_id=?
    `).get(id, companyId);

    if (!f) return res.status(404).send("Factura nu exista");

    const contact = db.prepare(`
      SELECT email
      FROM contacts
      WHERE client_id=? AND company_id=? AND email IS NOT NULL AND TRIM(email) <> ''
      ORDER BY is_primary DESC, id ASC
      LIMIT 1
    `).get(f.client_id, companyId);

    if (!contact || !contact.email) return res.redirect("/factura/" + id + "?err=fara_email_client");
    if (!f.pdf_path) return res.redirect("/factura/" + id + "?err=fara_pdf");

    const absPath = path.join(__dirname, f.pdf_path);
    if (!fs.existsSync(absPath)) return res.redirect("/factura/" + id + "?err=pdf_lipsa");

    try {
      await transporter.sendMail({
        from: process.env.SMTP_USER,
        to: contact.email,
        subject: "Factura " + (f.factura_nr || ""),
        text: "Buna ziua,\n\nAtasat gasiti factura.\n\nMultumim.",
        attachments: [{ filename: f.factura_nr + ".pdf", path: absPath }]
      });

      db.prepare("UPDATE facturi SET status=? WHERE id=? AND company_id=?").run("TRIMIS_CLIENT", id, companyId);
      return res.redirect("/factura/" + id + "?ok=trimis_client");
    } catch (e) {
      console.error("EMAIL ERROR:", e);
      return res.redirect("/factura/" + id + "?err=eroare_email");
    }
  });
}
