import bcrypt from "bcrypt";

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function slugifyCompanyName(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function ensureUniqueCompanySlug(db, baseName) {
  const baseSlug = slugifyCompanyName(baseName) || "companie";
  let slug = baseSlug;
  let index = 2;

  while (db.prepare("SELECT id FROM companies WHERE slug=?").get(slug)) {
    slug = `${baseSlug}-${index}`;
    index += 1;
  }

  return slug;
}

function buildSessionUser(u) {
  return {
    id: u.id,
    email: u.email,
    role: u.role,
    company_id: u.company_id,
    company_name: u.company_name,
    is_company_admin: u.is_company_admin,
    is_super_admin: u.is_super_admin,
    assigned_module_permissions: u.assigned_module_permissions,
    module_permissions: u.module_permissions,
    effective_module_permissions: u.effective_module_permissions,
    subscription: u.subscription
  };
}

function renderAuthPage({
  title,
  heading,
  description,
  formHtml,
  footerHtml = "",
  accent = "blue"
}) {
  const accentGradient = accent === "emerald"
    ? "linear-gradient(135deg,#052e16,#166534,#34d399)"
    : "linear-gradient(135deg,#0f172a,#1e3a8a,#38bdf8)";
  const buttonGradient = accent === "emerald"
    ? "linear-gradient(135deg,#052e16,#15803d)"
    : "linear-gradient(135deg,#111827,#2563eb)";

  return `
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>${escapeHtml(title)}</title>
<style>
  *{box-sizing:border-box}
  body{
    margin:0;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:40px 20px;
    font-family:system-ui,Arial,sans-serif;
    background:${accentGradient};
    background-size:200% 200%;
    animation:bgShift 10s ease infinite;
  }
  @keyframes bgShift{
    0%{background-position:0% 50%}
    50%{background-position:100% 50%}
    100%{background-position:0% 50%}
  }
  @keyframes cardIn{
    from{opacity:0;transform:translateY(18px) scale(.98)}
    to{opacity:1;transform:translateY(0) scale(1)}
  }
  .auth-shell{
    position:relative;
    width:100%;
    max-width:980px;
    display:grid;
    grid-template-columns:minmax(0, 420px) minmax(0, 1fr);
    gap:26px;
    align-items:stretch;
  }
  .auth-shell::before{
    content:"";
    position:absolute;
    inset:-8% -4% auto -4%;
    height:240px;
    background:radial-gradient(circle, rgba(255,255,255,.16), rgba(255,255,255,0) 70%);
    filter:blur(10px);
    pointer-events:none;
  }
  .auth-brand,
  .auth-card{
    position:relative;
    overflow:hidden;
    border:1px solid rgba(255,255,255,.20);
    border-radius:26px;
    background:rgba(255,255,255,.14);
    backdrop-filter:blur(14px);
    -webkit-backdrop-filter:blur(14px);
    box-shadow:0 24px 80px rgba(2,6,23,.34), inset 0 1px 0 rgba(255,255,255,.10);
    animation:cardIn .55s ease;
  }
  .auth-brand{
    padding:32px;
    color:#fff;
  }
  .auth-brand::before,
  .auth-card::before{
    content:"";
    position:absolute;
    inset:-1px;
    background:linear-gradient(135deg,rgba(255,255,255,.30),rgba(255,255,255,.06),rgba(255,255,255,.18));
    border-radius:26px;
    pointer-events:none;
    opacity:.9;
  }
  .brand-chip{
    display:inline-flex;
    align-items:center;
    gap:10px;
    padding:10px 14px;
    border-radius:999px;
    background:rgba(255,255,255,.12);
    border:1px solid rgba(255,255,255,.16);
    font-size:12px;
    letter-spacing:.08em;
    text-transform:uppercase;
  }
  .brand-title{
    margin:20px 0 0;
    font-size:38px;
    line-height:1.05;
    letter-spacing:.02em;
  }
  .brand-copy{
    margin:14px 0 0;
    color:rgba(255,255,255,.82);
    line-height:1.65;
    max-width:34ch;
  }
  .brand-points{
    margin:28px 0 0;
    display:grid;
    gap:12px;
  }
  .brand-point{
    padding:14px 16px;
    border-radius:18px;
    background:rgba(255,255,255,.10);
    border:1px solid rgba(255,255,255,.12);
  }
  .brand-point strong{
    display:block;
    margin-bottom:4px;
    font-size:14px;
  }
  .brand-point span{
    color:rgba(255,255,255,.76);
    font-size:13px;
    line-height:1.45;
  }
  .auth-card{
    padding:30px;
  }
  h1{
    margin:0;
    color:#fff;
    font-size:32px;
    letter-spacing:.02em;
  }
  .auth-description{
    margin:10px 0 24px;
    color:#e2e8f0;
    line-height:1.6;
  }
  label{
    display:block;
    margin:0 0 6px;
    color:#e5e7eb;
    font-size:13px;
    font-weight:700;
  }
  input, select{
    width:100%;
    padding:13px 14px;
    margin:0 0 14px;
    border:1px solid rgba(255,255,255,.24);
    border-radius:14px;
    background:rgba(255,255,255,.96);
    outline:none;
    font-size:14px;
  }
  input:focus, select:focus{
    border-color:#93c5fd;
    box-shadow:0 0 0 3px rgba(147,197,253,.25);
  }
  .grid-2{
    display:grid;
    grid-template-columns:repeat(2,minmax(0,1fr));
    gap:14px;
  }
  .plan-card{
    display:flex;
    align-items:flex-start;
    gap:10px;
    padding:14px 16px;
    border-radius:18px;
    margin-bottom:10px;
    border:1px solid rgba(255,255,255,.18);
    background:rgba(255,255,255,.10);
    color:#fff;
  }
  .plan-card input{
    width:auto;
    margin:4px 0 0;
  }
  .plan-card strong{
    display:block;
    font-size:15px;
  }
  .plan-card span{
    display:block;
    color:#dbeafe;
    font-size:13px;
    line-height:1.45;
    margin-top:4px;
  }
  button{
    width:100%;
    padding:13px 16px;
    border:0;
    border-radius:14px;
    background:${buttonGradient};
    color:#fff;
    font-weight:800;
    font-size:14px;
    cursor:pointer;
    box-shadow:0 10px 24px rgba(15,23,42,.26);
    transition:transform .15s ease, box-shadow .15s ease, filter .15s ease;
  }
  button:hover{
    transform:translateY(-1px);
    box-shadow:0 14px 28px rgba(15,23,42,.34);
    filter:brightness(1.03);
  }
  .auth-footer{
    margin-top:18px;
    color:#dbeafe;
    font-size:13px;
    line-height:1.55;
  }
  .auth-footer a{
    color:#fff;
    font-weight:700;
    text-decoration:none;
  }
  .bg-logo{
    position:fixed;
    inset:0;
    display:flex;
    align-items:center;
    justify-content:center;
    pointer-events:none;
    user-select:none;
    font-size:clamp(72px,16vw,220px);
    font-weight:800;
    letter-spacing:4px;
    color:rgba(255,255,255,.10);
    text-transform:uppercase;
    text-shadow:0 10px 34px rgba(15,23,42,.18);
    animation:bgLogoFloat 7s ease-in-out infinite;
  }
  @keyframes bgLogoFloat{
    0%{transform:translateY(0);opacity:.08}
    50%{transform:translateY(10px);opacity:.12}
    100%{transform:translateY(0);opacity:.08}
  }
  @media (max-width: 920px){
    .auth-shell{grid-template-columns:1fr}
  }
  @media (max-width: 640px){
    .grid-2{grid-template-columns:1fr}
    .auth-card, .auth-brand{padding:24px}
    h1{font-size:28px}
  }
</style>
</head>
<body>
  <div class="bg-logo" id="bgLogo">MiniCRM</div>
  <div class="auth-shell">
    <section class="auth-brand">
      <div class="brand-chip">MiniCRM Cloud Ready</div>
      <h2 class="brand-title">CRM și ERP modular pentru companii pe abonament.</h2>
      <p class="brand-copy">Activezi compania, alegi planul lunar și intri direct într-un workspace propriu, cu utilizatori și module controlate pe rol.</p>
      <div class="brand-points">
        <div class="brand-point">
          <strong>Companii separate</strong>
          <span>Date și acces izolate pe fiecare companie.</span>
        </div>
        <div class="brand-point">
          <strong>Planuri predefinite</strong>
          <span>Activezi modulele CRM și ERP în funcție de abonament.</span>
        </div>
        <div class="brand-point">
          <strong>Drepturi pe utilizator</strong>
          <span>Fiecare companie își controlează echipa și vizibilitatea pe module.</span>
        </div>
      </div>
    </section>

    <section class="auth-card">
      <h1>${escapeHtml(heading)}</h1>
      <div class="auth-description">${escapeHtml(description)}</div>
      ${formHtml}
      ${footerHtml ? `<div class="auth-footer">${footerHtml}</div>` : ""}
    </section>
  </div>
<script>
  const bgLogo = document.getElementById("bgLogo");
  document.addEventListener("mousemove", (e) => {
    const x = (e.clientX / window.innerWidth - 0.5) * 18;
    const y = (e.clientY / window.innerHeight - 0.5) * 12;
    bgLogo.style.transform = "translate(" + x + "px," + (y + 4) + "px)";
  });
</script>
</body>
</html>
`;
}

function loginErrorMessage(code, companyName) {
  if (code === "company_suspended") {
    return companyName
      ? `Compania ${companyName} este suspendată momentan. Contactează administratorul platformei.`
      : "Compania asociată contului este suspendată momentan. Contactează administratorul platformei.";
  }
  if (code === "company_suspended_with_reason") {
    return companyName
      ? `Compania ${companyName} este suspendată momentan. Verifică mesajul afișat sau contactează administratorul platformei.`
      : "Compania asociată contului este suspendată momentan. Verifică mesajul afișat sau contactează administratorul platformei.";
  }
  if (code === "user_inactive") {
    return "Contul tău este inactiv. Contactează administratorul companiei.";
  }
  if (code === "missing_credentials") {
    return "Email și parola sunt obligatorii.";
  }
  if (code === "session_error") {
    return "A apărut o eroare internă la deschiderea sesiunii.";
  }
  if (code === "invalid_credentials") {
    return "Email sau parolă incorecte.";
  }
  return "";
}

export function registerAuthRoutes(app, { db, verifyUser, verifyUserAttempt }) {
  app.get("/login", (req, res) => {
    if (req.session?.user) return res.redirect("/dashboard");
    const errorCode = String(req.query?.err || "").trim();
    const companyName = String(req.query?.company || "").trim();
    const detail = String(req.query?.detail || "").trim();
    const errorMessage = loginErrorMessage(errorCode, companyName);

    const formHtml = `
      ${errorMessage ? `<div style="margin-bottom:16px;padding:14px 16px;border-radius:16px;border:1px solid rgba(248,113,113,.45);background:rgba(127,29,29,.35);color:#fee2e2;font-size:14px;line-height:1.5">${escapeHtml(errorMessage)}${detail ? `<div style="margin-top:8px;color:#fecaca">${escapeHtml(detail)}</div>` : ""}</div>` : ""}
      <form method="post" action="/login">
        <label>Email</label>
        <input name="email" type="email" required />
        <label>Password</label>
        <input name="password" type="password" required />
        <button type="submit">Login</button>
      </form>
    `;

    res.type("html").send(renderAuthPage({
      title: "Login",
      heading: "MiniCRM Login",
      description: "Intri în compania ta și continui direct în workspace-ul asociat contului.",
      formHtml,
      footerHtml: `Nu ai încă un workspace? <a href="/signup/company">Creează companie nouă</a>.`
    }));
  });

  app.get("/signup/company", (req, res) => {
    if (req.session?.user) return res.redirect("/dashboard");

    const plans = db.prepare(`
      SELECT id, code, name, price_monthly, max_users, module_keys
      FROM plans
      WHERE status='active'
      ORDER BY price_monthly ASC, id ASC
    `).all();

    const planCards = plans.map((plan, index) => {
      let moduleKeys = [];
      try {
        moduleKeys = JSON.parse(plan.module_keys || "[]");
      } catch {
        moduleKeys = [];
      }
      return `
        <label class="plan-card">
          <input type="radio" name="plan_id" value="${plan.id}" ${index === 0 ? "checked" : ""}>
          <span>
            <strong>${escapeHtml(plan.name)}</strong>
            <span>${escapeHtml(String(plan.price_monthly))} EUR / lună • ${escapeHtml(String(plan.max_users))} utilizatori • ${escapeHtml(moduleKeys.join(", "))}</span>
          </span>
        </label>
      `;
    }).join("");

    const formHtml = `
      <form method="post" action="/signup/company">
        <div class="grid-2">
          <div>
            <label>Nume companie</label>
            <input name="company_name" required />
          </div>
          <div>
            <label>CUI</label>
            <input name="company_cui" />
          </div>
        </div>
        <div class="grid-2">
          <div>
            <label>RC</label>
            <input name="company_rc" />
          </div>
          <div>
            <label>Reprezentant</label>
            <input name="company_rep" />
          </div>
        </div>
        <label>Adresă companie</label>
        <input name="company_address" />
        <div class="grid-2">
          <div>
            <label>Email administrator</label>
            <input name="admin_email" type="email" required />
          </div>
          <div>
            <label>Parolă administrator</label>
            <input name="admin_password" type="password" minlength="8" required />
          </div>
        </div>
        <label>Plan inițial</label>
        ${planCards}
        <button type="submit">Creează compania</button>
      </form>
    `;

    res.type("html").send(renderAuthPage({
      title: "Creează companie",
      heading: "Creează companie nouă",
      description: "Deschizi un workspace nou, alegi planul și primești automat primul cont de administrator.",
      formHtml,
      footerHtml: `Ai deja cont? <a href="/login">Mergi la login</a>.`,
      accent: "emerald"
    }));
  });

  app.post("/login", (req, res) => {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const password = String(req.body?.password || "");
    if (!email || !password) {
      return res.redirect("/login?err=missing_credentials");
    }

    const attempt = verifyUserAttempt(email, password);
    if (!attempt?.ok) {
      const params = new URLSearchParams();
      params.set("err", attempt?.reason || "invalid_credentials");
      if (attempt?.company_name) params.set("company", attempt.company_name);
      if (attempt?.detail) params.set("detail", attempt.detail);
      return res.redirect(`/login?${params.toString()}`);
    }
    const u = attempt.user;

    req.session.regenerate((err) => {
      if (err) {
        console.error("Session regenerate failed:", err);
        return res.redirect("/login?err=session_error");
      }

      req.session.user = buildSessionUser(u);
      return res.redirect("/dashboard");
    });
  });

  app.post("/signup/company", (req, res) => {
    const companyName = String(req.body?.company_name || "").trim();
    const companyCui = String(req.body?.company_cui || "").trim();
    const companyRc = String(req.body?.company_rc || "").trim();
    const companyRep = String(req.body?.company_rep || "").trim();
    const companyAddress = String(req.body?.company_address || "").trim();
    const adminEmail = String(req.body?.admin_email || "").trim().toLowerCase();
    const adminPassword = String(req.body?.admin_password || "");
    const planId = Number(req.body?.plan_id);

    if (!companyName || !adminEmail || !adminPassword || !Number.isFinite(planId)) {
      return res.status(400).type("html").send("<p style='font-family:system-ui'>Completează toate câmpurile obligatorii. <a href='/signup/company'>Înapoi</a></p>");
    }

    if (adminPassword.length < 8) {
      return res.status(400).type("html").send("<p style='font-family:system-ui'>Parola trebuie să aibă minim 8 caractere. <a href='/signup/company'>Înapoi</a></p>");
    }

    const existingUser = db.prepare("SELECT id FROM users WHERE email=?").get(adminEmail);
    if (existingUser) {
      return res.status(400).type("html").send("<p style='font-family:system-ui'>Există deja un utilizator cu acest email. <a href='/signup/company'>Înapoi</a></p>");
    }

    const plan = db.prepare(`
      SELECT id, name, code, max_users, module_keys
      FROM plans
      WHERE id=? AND status='active'
    `).get(planId);
    if (!plan) {
      return res.status(404).type("html").send("<p style='font-family:system-ui'>Planul ales nu există. <a href='/signup/company'>Înapoi</a></p>");
    }

    let planModules = [];
    try {
      planModules = JSON.parse(plan.module_keys || "[]");
    } catch {
      planModules = [];
    }

    const companySlug = ensureUniqueCompanySlug(db, companyName);
    const passwordHash = bcrypt.hashSync(adminPassword, 12);

    try {
      const createCompany = db.transaction(() => {
        const companyResult = db.prepare(`
          INSERT INTO companies (name, slug, cui, rc, address, representative, status, max_users, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, 'trial', ?, datetime('now'), datetime('now'))
        `).run(
          companyName,
          companySlug,
          companyCui,
          companyRc,
          companyAddress,
          companyRep,
          Math.max(Number(plan.max_users || 1), 1)
        );

        const companyId = Number(companyResult.lastInsertRowid);

        db.prepare(`
          INSERT INTO company_subscriptions (company_id, plan_id, status, seats_included, seats_used, module_overrides, starts_at, created_at, updated_at)
          VALUES (?, ?, 'trial', ?, 1, ?, datetime('now'), datetime('now'), datetime('now'))
        `).run(
          companyId,
          plan.id,
          Math.max(Number(plan.max_users || 1), 1),
          JSON.stringify(planModules)
        );

        db.prepare(`
          INSERT INTO users (email, password_hash, role, company_id, status, is_company_admin, module_permissions, created_at)
          VALUES (?, ?, 'admin', ?, 'active', 1, ?, datetime('now'))
        `).run(
          adminEmail,
          passwordHash,
          companyId,
          JSON.stringify(planModules)
        );

        return companyId;
      });

      createCompany();
    } catch (error) {
      console.error("Company signup failed:", error);
      return res.status(500).type("html").send("<p style='font-family:system-ui'>Nu am putut crea compania. <a href='/signup/company'>Înapoi</a></p>");
    }

    const user = verifyUser(adminEmail, adminPassword);
    if (!user) {
      return res.redirect("/login");
    }

    req.session.regenerate((err) => {
      if (err) {
        console.error("Session regenerate after signup failed:", err);
        return res.redirect("/login");
      }

      req.session.user = buildSessionUser(user);
      return res.redirect("/dashboard");
    });
  });

  app.post("/logout", (req, res) => {
    req.session?.destroy(() => {
      res.clearCookie("minicrm.sid");
      res.redirect("/login");
    });
  });
}
